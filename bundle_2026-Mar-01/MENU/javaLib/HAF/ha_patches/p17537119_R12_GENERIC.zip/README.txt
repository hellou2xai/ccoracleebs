# $Header: README.txt 120.32 2026/01/21 19:35:50 chrhill noship $ #
For the latest ETCC readme, see My Oracle Support article KA1026, Oracle E-Business Suite Release 12.2: EBS Technology Codelevel Checker (ETCC) Readme.
