#!/bin/sh 
#
# $Header: checkDBpatch.sh 120.142 2026/01/21 19:15:27 chrhill noship $

#
# This script verifies if all the required pre-requisite patches
# exist in an existing ORACLE_HOME. The script is intended for use 
# before starting an Upgrade flow. 

runProcess_1() {
if test "${sqlpatchesonly}" = "y" ; then
  list_already_applied_patches
else
 if test "${GridHome}" = "y"; then
      DB_VERSION="${tsvers}" # For OnPrem
      listvers=${DB_VERSION} # For Cloud
 fi

#Checking mapping for on-prem
  if test "${cloud}" != "y" ; then
     printf "\nChecking Bugfix XML file for tag ${DB_VERSION}.\n" | tee -a $LOGFILE
    # printf "\nDEBUG:Checking Mapping XML file for ${mapvers}\n" | tee -a $LOGFILE
     if test "${isPatchMap}" = "y" ; then
       isMapData=`grep "\"${mapvers}\"" ${MAP_LIST_FILE}`
     fi
     #printf "\n DEBUG: isMapData = ${isMapData}"
     if test "${isMapData}x" = "x" -a "${GridHome}" != "y" ; then
      # Disable patch mapping
      #33783716 Set is19RU = true to not print suggestion to stay on current version
      is19RU="true"
      isPatchMap="n"
      printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
      printf "   The ETCC was run against Oracle Database version ${DB_VERSION}, for which no\n" | tee -a $LOGFILE
      printf "   patch mapping data was found in ${MAP_LIST_FILE}.\n" | tee -a $LOGFILE
      printf "   In order for ETCC to provide a list of missing fixes and patch mappings, you must be\n" | tee -a $LOGFILE
      printf "   running a database release listed in My Support article KA989.\n" | tee -a $LOGFILE
      printf "\n   Refer to My Support article KA989 for the required Oracle E-Business Suite \n" | tee -a $LOGFILE
      printf "\n   and overlay patches. After applying a supported update, rerun the ETCC for any\n" | tee -a $LOGFILE
      printf "\n   additional recommendations.\n" | tee -a $LOGFILE
      printf "\n+---------------------------------------------------------------------------------------+\n\n"| tee -a $LOGFILE
    fi
  fi
  # Check for versions out of Error Correction Support
  checkECS
  BUG_APP_RBK=`${AWK} -F'[<|>]' '/Technology/{t=$2}/platform/{p=$2}/base_bugs/{bb=$3}/bugs_rollback/{br=$3; printf "%s!%s:%s#%s\n",t,p,bb,br}' ${BUG_LIST_FILE}  | grep ${DB_VERSION}\" | grep ${PLAT}` 
  if test "${isRacEnv}" = "y" ; then
    RAC_BUGS_XML=`${AWK} -F'[<|>]' '/Technology/{t=$2}/platform/{p=$2}/rac_bugs/{rb=$3; printf "%s!%s:%s\n",t,p,rb}' ${BUG_LIST_FILE}  | grep ${DB_VERSION}\" | grep ${PLAT}` 
  fi

  if test "${cloud}" = "y" ; then
    #printf "\nDEBUG: BUNDLE APPLIED? = ${bundleapplied}\n"
    #printf "\nDEBUG: PSU APPLIED? = ${psuapplied}\n"
    #printf "\nDEBUG: MAP VERSION = ${mapvers}\n"  
    #printf "\nDEBUG: LIST VERSION = ${listvers}\n"
    printf "\nChecking Bugfix XML file for ${listvers}\n" | tee -a $LOGFILE
     CLOUD_BUGS=`${AWK} -F'[<|>]' '/Technology/{t=$2}/platform/{p=$2}/base_bugs/{bb=$3}/bugs_rollback/{br=$3; printf "%s!%s:%s#%s\n",t,p,bb,br}' ${BUG_LIST_FILE}  | grep ${listvers}\" | grep ${PLAT}`
      #Get N release         
      if test ${relchg} -gt 2325  ; then
        n_release="`grep Technology ${BUG_LIST_FILE} |grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/">//g' | grep ^${DB_REL}\. |sort -t. -k 1,1nr -k 2,2nr -k 3,3nr |${AWK} 'NR==2 {print $0}'`"
        if test "${n_release}x" = "x" ; then 
          n_release="`grep Technology ${BUG_LIST_FILE} |grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/">//g' | grep ^${DB_REL}\. |sort -t. -k 1,1nr -k 2,2nr -k 3,3nr |${AWK} 'NR==1 {print $0}'`"
          n_release="`echo "${n_release}" |awk -F_ '{print $1}'`"
        fi    
      else
        n_release="`grep Technology ${BUG_LIST_FILE} |grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/">//g' | grep ^${DB_REL}\. |sort -t. -k 1,1nr -k 2,2nr |${AWK} 'NR==2 {print $0}'`"
        if test "${n_release}x" = "x" ; then 
          n_release="`grep Technology ${BUG_LIST_FILE} |grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/">//g' | grep ^${DB_REL}\. |sort -t. -k 1,1nr -k 2,2nr |${AWK} 'NR==1 {print $0}'`"
          n_release="`echo "${n_release}" |awk -F_ '{print $1}'`"
        fi    
      fi 
    
   #Change the version into integer for compare
     nRel=`echo "${n_release//.}"`
     nListver=`echo "${listvers//.}"`
        if test "${CLOUD_BUGS}x" != "x" ; then
          printf "\nIdentified ${listvers} bugfixes." | tee -a $LOGFILE
          issupportedtext=`echo ${CLOUD_BUGS}| ${AWK} -F: '{ print $2}' | ${AWK} -F# '{ print $1}'|sed 's/^[ \t]*//;s/[ \t]*$//'`
          #printf "\nDEBUG: IS SUPPORTED = ${issupportedtext}\n"
          # if there is NOT YET SUPPORTED entry then we need to display warning

          if test "${issupportedtext}" = "NOT CURRENTLY SUPPORTED" ; then
            MissRlbkFix="Unable to validate fixes for ${cloudvers} using ${XML_FILE_NAME}. Download latest patch 17537119 and rerun ETCC. Refer to My Oracle Support article ${mosID} for recommended Release Update"
            exit_code="ETCC-0020"
            notcurrentlysupported 
          else
            BUG_APP_RBK="${CLOUD_BUGS}"

           rslt=`echo "if ( $nListver <= $nRel ) 1" | tr -d $'\r' | bc`
            if test "${rslt}x" = "1x" ; then
              isNewer="false"
              CheckForPatchUpdate 
            else 
              PATCH_UPDATE_MISSING="y"
              isNewer="true"
            fi
          fi
        else # Check for patch update only if the PSU or Bundle version installed is not not found in base bugs

          if test "${patch_update_bugid}x" != "x" ; then 
            rslt=`echo "if ( $nListver <= $nRel ) 1" | tr -d $'\r' | bc`
            if test "${rslt}x" = "1x" ; then
              printf "\nChecking required patch update.\n" | tee -a $LOGFILE
              isNewer="false"
              CheckForPatchUpdate
            else 
              PATCH_UPDATE_MISSING="y"
              isNewer="true"
            fi
            PrintCloudConsolPatchMessageFlag="n" # No need to show the consolidated zip as we only check for missing bundle and it's not included in the zip

            if test "${PATCH_UPDATE_MISSING}" != "y"; then
              printf "\nAll the required one-off bugfixes are present in ${hometype} ORACLE_HOME.\n"| tee -a $LOGFILE
              if test ${DB_REL} -lt 19; then
               TCCresult="OK"
              fi
            else  # If Patch Update missing, print warning
              TCCresult="MISSING"
              printf "\nMissing Bugfix: ${patch_update_bugid}  ->  Patch ${patch_update_patchid}\n\n"
              MissRlbkFix="${patch_update_patchid} - ${patch_update_desc}"
              MissingPatchTitle=" ${patch_update_patchid} - ${patch_update_desc}"
              MissingPatchType="patch update"
              printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
              PrintMissingPatchWarning
            fi
            if test "${contextfile}" != "none" ; then
              updateResInDB
            fi
        else
          if test "${myrealm}" = "oc1" ; then
            #If no entry in the base bug file for the database version, then it is not supported by ETCC
            printf "\nFor more information, refer to My Oracle Support article ${mosID}.\n" | tee -a $LOGFILE
          fi
         fi
          MissRlbkFix="No content for Oracle Database Release ${tsvers} found in ${BUG_LIST_FILE}, refer to My Oracle Support article ${mosID}. " 
          exit_code="ETCC-0045"
          notcurrentlysupported

         #cloud_bug != x
        fi 
    mapvers=${cloudvers}
 #end if cloud
  fi

  if test "${bundleapplied}" = "y" -o "${psuapplied}" = "y" ; then
    #printf "\nDEBUG: Checking for ${ojvmbundle} fix in ${BUG_LIST_FILE}\n" | tee -a $LOGFILE
    OJVM_BUGS_XML=`${AWK} -v jvm="${ojvmbundle}" -F '[<|>]' '/Technology/{t=$2}/platform/{p=$2}$0~jvm{j=$3; printf "%s!%s:%s\n",t,p,j}' ${BUG_LIST_FILE}  | grep ${DB_VERSION}\" | grep ${PLAT}` 
    #printf "\nDEBUG: Extracted JVM related metadata ${OJVM_BUGS_XML} \n" | tee -a $LOGFILE
  fi
    #DIFF_LIST=`${AWK} -F'[<|>]' '/Technology/{t=$2}/platform/{p=$2}/base_bugs/{bb=$2}/patch_id/{pi=$3; printf "%s#%s:%s,%s\n",t,p,bb,pi}' ${MAP_LIST_FILE} | grep ${DB_VERSION}\" | grep ${PLAT} |${AWK} -F":" {'print $NF'} |${AWK} -F"=" {'print $NF'}  | tr -d '"' | tr -d ' '`
  if test "${listdiffs}" = "y" ; then
    DIFF_LIST=`${AWK} -F'[<|>]' '/Technology/{t=$2}/platform/{p=$2}/base_bugs/{bb=$2}/merges/{mp=$3}/patch_id/{pi=$3; printf "%s#%s:%s,%s,%s\n",t,p,bb,pi,mp}' ${MAP_LIST_FILE} | grep ${DB_VERSION}\" | grep ${PLAT} |${AWK} -F":" {'print $NF'} |${AWK} -F"=" {'print $NF'}  | tr -d '"' | tr -d ' '`
  fi
    #printf "\n[DEBUG] DIFF_LIST is :\n${DIFF_LIST}\n" | tee -a $LOGFILE
  appsuser=""


   # Patch mapping changes 1
   rm -f ${LOCAL_TEMP}/${TECHNAME}.map
   rm -f ${LOCAL_TEMP}/summary.txt
   touch ${LOCAL_TEMP}/${TECHNAME}.map
   touch ${LOCAL_TEMP}/summary.txt

#If there are no bug missing
   if test "${BUG_APP_RBK}x" = "x" ; then
      if test "${obsolete}" = "y" ; then
            MissRlbkFix="UPGRADE REQUIRED"
            exit_code="ETCC-0000"
            #notcurrentlysupported
      fi 

#Added if here to include 11g/12c
      if test ${DB_REL} -gt 12; then
        if test "${release_update_bugid}x" != "x" ; then
          CheckForReleaseUpdate
          PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
          MissRlbkFix="${release_update_patchid}"
          CheckRUMissing
          exit_code="ETCC-0000"
          notcurrentlysupported
        else 
          if test "${patch_update_bugid}x" != "x" ; then
            CheckForPatchUpdate
            PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
            MissRlbkFix="${patch_update_bugid}"
            CheckPSUMissing
            exit_code="ETCC-0000"
            notcurrentlysupported
          else
            if test "${cloud}" = "y" -a "${serviceRU}x" != "x" -a "${myrealm}" != "oc1"; then
              CheckForPatchUpdate
              PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
              CheckPSUMissing
            fi
          fi
        fi 
      else 
    #Checking for missing bundle and patch updates for 11g/12c

        if test "${psuapplied}" = "y"; then
          if test "${patch_update_bugid}x" != "x" ; then
            CheckForPatchUpdate
            PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
            MissRlbkFix="${patch_update_bugid}"
            CheckPSUMissing
            exit_code="ETCC-0000"
            notcurrentlysupported
          fi
        else 

          if test "${bundleapplied}" = "y"; then
            if test "${bundle_update_bugid}x" != "x" ; then
              CheckForBundleUpdate
              PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
              if test "${BUNDLE_UPDATE_MISSING}" = "y"; then
                  printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
              fi
               MissRlbkFix="${patch_update_bugid}"
              CheckBundleMissing
              exit_code="ETCC-0000"
              notcurrentlysupported
            fi 
          fi
        fi #end of psu applied
     fi #end of gt12 
      MissRlbkFix="No content for Oracle Database Release ${DB_VERSION} found in ${BUG_LIST_FILE}, refer to KA989."
      exit_code="ETCC-0044"
      notcurrentlysupported
   else
      printf "\nObtained list of bugfixes to be applied and list to be rolled back.\n" | tee -a $LOGFILE
   fi #end of if BUG_APP_RBK

   BUG_LIST=`echo ${BUG_APP_RBK}| ${AWK} -F: '{ print $2}' | ${AWK} -F# '{ print $1}'|sed 's/^[ \t]*//;s/[ \t]*$//'`
   BUG_RBK=`echo ${BUG_APP_RBK}| ${AWK} -F# '{ print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
   JVM_BUG=`echo ${OJVM_BUGS_XML}| ${AWK} -F: '{ print $2}' |sed 's/^[ \t]*//;s/[ \t]*$//'` 

   if test "${BUG_LIST}x" != "x" ; then 
	    echo ${BUG_LIST} | tr "," "\012" > ${PATCHES_TOAPPLY}
   fi

   if test "${JVM_BUG}x" != "x" ; then
      echo ${JVM_BUG} | tr "," "\012" >> ${PATCHES_TOAPPLY}
      #printf "\nDEBUG: Added ${JVM_BUG} to ${PATCHES_TOAPPLY}\n" | tee -a $LOGFILE
   fi 

   if test "${BUG_RBK}x" != "x" ; then 
	    echo ${BUG_RBK} | tr "," "\012" > ${PATCHES_TOROLLBACK}
   fi

   if test "${RAC_BUGS_XML}x" != "x" ; then
      #printf "\nDEBUG: RACBUGSML is ${RAC_BUGS_XML}"
      RAC_BUG_LIST=`echo ${RAC_BUGS_XML}| ${AWK} -F: '{ print $2}' |sed 's/^[ \t]*//;s/[ \t]*$//'`     
      #printf "\nDEBUG: RACBUGLIST is ${RAC_BUG_LIST}"
      echo ${RAC_BUG_LIST} | tr "," "\012" > ${RAC_PATCHES_TOAPPLY}
      checkRACfixes="y"
   fi

   # Get the list of one-offs already applied to the Oracle Database Home
   list_already_applied_patches
   if test "${listdiffs}" = "y" ; then
      DIFF_LIST2=`echo ${DIFF_LIST} | sed 's/,/ /g'`
          #printf "\n[DEBUG] DIFF_LIST2 is :\n${DIFF_LIST2}\n" | tee -a $LOGFILE
      echo ${DIFF_LIST2} | tr " " "\012" > ${FIXES_FROMXML}1
      sort ${FIXES_FROMXML}1 | uniq > ${FIXES_FROMXML}
      runDiffsCheck # Run opatch again to a diff patch output
   fi

   # Check if mapping data available in mappings XML file
   if test "${isPatchMap}" = "y" ; then
      printf "\nChecking mapping XML file for tag ${mapvers}.\n" | tee -a $LOGFILE
      isMapData=`grep "\"${mapvers}\"" ${MAP_LIST_FILE}`
      #printf "\nDEBUG: isMapData = ${isMapData}\n"

      if test "${isMapData}x" = "x" ; then

         # Disable patch mapping
         #33783716 Set is19RU = true to not print suggestion to stay on current version
            if test ${DB_REL} -le 12 ; then
              is19RU="true"
            fi
         isPatchMap="n"
         printf "The ETCC was run against DB version ${DB_VERSION}, for which no patch mapping data is available.\n" | tee -a $LOGFILE
         if test "${listdiffs}" = "y" ; then
            # Disable patch diffs as no mapping data available
            listdiffs="n"
            printf "\nPatch mapping not available." | tee -a $LOGFILE
            printf "\nDisabling 'listdiffs' option." | tee -a $LOGFILE
         fi
         # Display correct info according to DB type or options enabled
         if test "${isDBIM}" = "y" ; then
            printf "\nPatch mapping data is not available for ${mapvers}" | tee -a $LOGFILE
            if test "${cloud}" = "y" ; then
              printf "\n" # Bug 25432094  
              printf "\nReview article ${mosid} to idenity latest supported release patching information.\n" | tee -a $LOGFILE
            else
              printf "\nRefer to KA989 for the recommended Bundle Patch versions.\n" | tee -a $LOGFILE
            fi  
         else
            if test "${psuversion}x" != "x" ; then
               printf "\nPatch mapping data is not available for ${mapvers}" | tee -a $LOGFILE
               printf "\nRefer to KA1094 for the required overlay patches for Patch Set Updates and Oracle E-Business Suite\n" | tee -a $LOGFILE
            else
               printf "\n"
               printf "\nPatch mapping data is not available for ${mapvers}" | tee -a $LOGFILE
            fi
         fi
      fi
   # End mapping data check
   fi
 if test "${BUG_LIST}x" != "x" ; then
   # List of patches that are missing in existing Oracle Home
   if test "${PLATFORM}" != "HP_IA" -a "${PLATFORM}" != "Linux_x64" -a "${PLATFORM}" != "IBM_AIX" ; then   #bug14759449
        OHOME_PATCHED=`fgrep -xvf ${PATCHES_APPLIED} ${PATCHES_TOAPPLY}`
        if test "${checkRACfixes}" = "y" ; then
          RACHOME_PATCHED=`fgrep -xvf ${PATCHES_APPLIED} ${RAC_PATCHES_TOAPPLY}`
        fi
        if test "${listdiffs}" = "y" ; then
          OHOME_EXTRAS=`fgrep -xvf ${FIXES_FROMXML} ${DIFF_PATCHES_APPLIED}` # Additional Applied Patch info 
        fi
   else
        OHOME_PATCHED=`grep -Fxvf ${PATCHES_APPLIED} ${PATCHES_TOAPPLY}`
  
        if test "${checkRACfixes}" = "y" ; then
          RACHOME_PATCHED=`grep -Fxvf ${PATCHES_APPLIED} ${RAC_PATCHES_TOAPPLY}`
        fi
        if test "${listdiffs}" = "y" ; then
          OHOME_EXTRAS=`grep -Fxvf ${FIXES_FROMXML} ${DIFF_PATCHES_APPLIED}` # Additional Applied Patch info
        fi
   fi
   MissRlbkFix=${OHOME_PATCHED}
 
   if test "${listdiffs}" = "y" ; then
      OHOME_PATCHED="" # Skip missing bugfix check for this mode
      RACHOME_PATCHED="" # Skip missing bugfix check for this mode
   fi  

   if test "${OHOME_PATCHED}x" != "x" ; then
       #Update TXK table for onprem before testing for mising RU
       if test "${cloud}" != "y" -a "${contextfile}" != "none"  ; then
         updateResInDB
         #Set flag to skip over writting the TXK table
         updatedb="skip"
       fi
       if test "${isPatchMap}" != "y" ; then
          printf "\nSome required one-off bugfixes are missing from the ${hometype} ORACLE_HOME."| tee -a $LOGFILE
          printf "\nThe missing bugfixes are:"| tee -a $LOGFILE
          printf "\n${OHOME_PATCHED}\n"| tee -a $LOGFILE
 

          if test "${cloud}" = "y" ; then
             if test "${isPatchMap}" = "n" ; then
                if test "${PATCH_UPDATE_MISSING}" = "y"; then
                  # If Cloud and Patch Update missing, print warning
                  MissingPatchTitle=" ${patch_update_patchid} - ${patch_update_desc}"
                  MissingPatchType="patch update"
                  printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
                  PrintMissingPatchWarning
                fi
             fi
          else
            printf "\n** ${mosnote} **\n"| tee -a $LOGFILE
            printf "\nApply the missing bugfixes and then rerun the script. \n"| tee -a $LOGFILE
             
            if test ${DB_REL} -gt 12; then
                CheckForReleaseUpdate
                CheckRUMissing
            else
              CheckForBundleUpdate
              CheckBundleMissing
              CheckForPatchUpdate
              CheckPSUMissing
             fi
          fi
          xit="y"
       else

         # Patch mapping enabled
           echo "${OHOME_PATCHED}" | while read bugfixtoapply;
            do

             # Check for DST patch 13417321 and only include if DST < 19
             if test "${bugfixtoapply}" = "13417321" ; then          
              if test "${DSTversion}" -lt "19" ; then
              MapBugfixIDtoPatchID 
              fi
             else
              # Call patch mapping function                  
              MapBugfixIDtoPatchID  
             fi

            done

            # Update summary temp file
            printf "\n-----------------------------------------------------------------------------------------">> ${LOCAL_TEMP}/summary.txt
            printf "\nOracle Database Release ${tsvers} ${IMheader} ${DOTheader}">> ${LOCAL_TEMP}/summary.txt
            printf "\n-----------------------------------------------------------------------------------------\n">> ${LOCAL_TEMP}/summary.txt
            cat ${LOCAL_TEMP}/${TECHNAME}.map >> ${LOCAL_TEMP}/summary.txt
            if test -f ${LOCAL_TEMP}/${TECHNAME}.ecs ; then
               cat ${LOCAL_TEMP}/${TECHNAME}.ecs >> ${LOCAL_TEMP}/summary.txt
               printf "+---------------------------------------------------------------------------------------+\n">> ${LOCAL_TEMP}/summary.txt
            fi
       
            # Print Summary
            printf "\n\nGenerating Patch Recommendation Summary." | tee -a $LOGFILE
            printf "\n\n=========================================================================================" | tee -a $LOGFILE
            printf "\nPATCH RECOMMENDATION SUMMARY\n" | tee -a $LOGFILE
            printf "=========================================================================================" | tee -a $LOGFILE
            printf "\nThe default patch recommendations to install these missing bugfixes are:"| tee -a $LOGFILE
            cat ${LOCAL_TEMP}/summary.txt | tee -a $LOGFILE
            if [ $dbup != 0 ] ; then
               printf "\nApply the required patches and rerun this script." | tee -a $LOGFILE
               printf "\n\nYou should check the patch READMEs for minimum OPatch version requirements.\n\n" | tee -a $LOGFILE
            else
               printDBdownWarning
            fi

            # Bug 27484653 - Relaxing InMemory condition so checking for Bundles or PSUs (and display of Consolidated Zip message) should be done regardless of DB status now.
             
            if test "${cloud}" != "y" ; then
                if test "${bundleapplied}" = "y" ; then
                  if test ${DB_REL} -gt 12 ; then
                      CheckForReleaseUpdate
                      CheckRUMissing
                  else
                    CheckForBundleUpdate
                    CheckBundleMissing
                  fi
                else 
                    # check for missing PSU
                      CheckForPatchUpdate
                      CheckPSUMissing
                fi
            else
                if test "${PATCH_UPDATE_MISSING}" = "y" ; then
                  # If Cloud and Patch Update missing, print warning
                  MissingPatchTitle=" ${patch_update_patchid} - ${patch_update_desc}"
                  MissingPatchType="patch update"
                  printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
                  PrintMissingPatchWarning
                fi
              PrintCloudConsolPatchMessage
            fi

            if test "${cloud}" != "y" ; then
               printf "\nSee My Oracle Support article ${mosID} for any special instructions for these patches."| tee -a $LOGFILE
               printf "\nNote: Footnotes in KA989 also apply to corresponding overlay patches.\n" | tee -a $LOGFILE
            fi      
           # End Print Summary
       # End Patch Mapping 
       fi
       if test "${contextfile}" != "none" ; then
          updateResInDB
       fi
   else

       if test "${listdiffs}" != "y" ; then
        printf "\nAll the required one-off bugfixes are present in ${hometype} ORACLE_HOME.\n"| tee -a $LOGFILE
          CheckForReleaseUpdate
          CheckForPatchUpdate
          CheckForBundleUpdate
          PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
          if test "${RELEASE_UPDATE_MISSING}" = "y" -o "${PATCH_UPDATE_MISSING}" = "y" -o "${BUNDLE_UPDATE_MISSING}" = "y"; then
           printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
          else
           TCCresult="OK"
          fi
          if test ${DB_REL} -gt 12  -a "${cloud}" != "y"; then
            CheckRUMissing
          else 
            CheckBundleMissing
            CheckPSUMissing
            if test ${DB_REL} -lt 19; then
                TCCresult="OK"
            fi
          fi

          if test "${contextfile}" != "none" ; then
             updateResInDB
          fi
      fi
       rm -f ${LOCAL_TEMP}/${TECHNAME}.map
   fi
   # Additional Applied Patch info   
   if test "${OHOME_EXTRAS}x" = "x" ; then
     if test "${listdiffs}" = "y" ; then
        printf "\nAll patches applied to this ${hometype} ORACLE_HOME are listed in the XML file.\n"| tee -a $LOGFILE
        listdiffs="n"
     else
        listdiffs="n"
     fi
   fi

   # Additional Bugfix Header
   if test "${RACHOME_PATCHED}x" != "x" -o "${listdiffs}" = "y" ; then
      printf "\n-----------------------------------------------------------------------------------------"| tee -a $LOGFILE
      printf "\nADDITIONAL BUGFIX INFORMATION FOR ORACLE DATABASE ${DB_VERSION}"| tee -a $LOGFILE
      printf "\n-----------------------------------------------------------------------------------------"| tee -a $LOGFILE
   fi

   # RAC fixes
   if test "${RACHOME_PATCHED}x" != "x" ; then
          printf "\nOracle Grid related bugfixes are missing from the ${hometype} ORACLE_HOME."| tee -a $LOGFILE
          printf "\nThe missing bugfixes are:"| tee -a $LOGFILE
          printf "\n${RACHOME_PATCHED}\n"| tee -a $LOGFILE
          printf "\n** Refer to Section 7 of KA989 for further information ** \n"| tee -a $LOGFILE
          #printf "\nApply the missing bugfixes and then rerun the script. \n"| tee -a $LOGFILE   
   fi

   if test "${listdiffs}" = "y" ; then

      printf "\nThere are bugfixes applied to this ${hometype} ORACLE_HOME that are not listed in\nthe XML file:" | tee -a $LOGFILE

      if test "${listdiffs}" = "y" ; then
         echo ${OHOME_EXTRAS} | tr " " "\012:" > ${xlist}
         findDiffsDetails
      fi   
      printf "\n"| tee -a $LOGFILE
   fi
   # End Additional Applied Patch info  

 fi
 if test "${BUG_RBK}x" != "x" ; then
   # List of patches that are to be rolled back from the existing Oracle Home
   if test "${PLATFORM}" != "HP_IA" ; then         #bug14759449
       OHOME_RBK=`fgrep -f ${PATCHES_APPLIED} ${PATCHES_TOROLLBACK}`
   else
       OHOME_RBK=`grep -Fxf ${PATCHES_APPLIED} ${PATCHES_TOROLLBACK}`
   fi
 
   if test "${OHOME_RBK}x" != "x" ; then
       printf "\nRoll back the following bugfixes from ${hometype} ORACLE_HOME: "| tee -a $LOGFILE
       printf "\n${OHOME_RBK}\n"| tee -a $LOGFILE
       xit="y";
       TCCresult="ROLLBACK"
       MissRlbkFix=${OHOME_RBK}
       if test "${contextfile}" != "none" ; then
          updateResInDB
       fi
   fi
 fi
 
 TCCresult="OK"
 #Added to support releases that have no patches in the xml files. 
  BUG_LIST_EMPTY=`echo ${BUG_APP_RBK}| ${AWK} -F: '{ print $2}'`
  if test "${BUG_LIST_EMPTY}" = "#" ; then
    MissRlbkFix="No patches for ${DB_VERSION}"
   if test "${release_update_bugid}x" != "x"; then
      CheckForReleaseUpdate
      PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
      CheckRUMissing
      if test "${RELEASE_UPDATE_MISSING}" = "y"; then
        MissRlbkFix="${release_update_patchid}"
      fi
   fi
   if test "${patch_update_bugid}x" != "x" ; then
      CheckForPatchUpdate
      PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
      CheckPSUMissing
      if test "${PATCH_UPDATE_MISSING}" = "y"; then
        MissRlbkFix="${patch_update_bugid}"
      fi
   else 
      if test "${serviceRU}x" != "x" -a "${myrealm}" != "oc1" -a "${cloud}" = "y"; then
        CheckForPatchUpdate
        PrintConsolPatchMessageFlag="n" # No need to show the consolidated zip because Release Updates are not included.
        CheckPSUMissing
      fi
   fi

 if test ${DB_REL} -gt 19; then
   printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
   printf "\nNo additional patches are currently recommended for this ${DB_VERSION} database ORACLE_HOME."| tee -a $LOGFILE
   printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
 else
   printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
   printf "\nNo additional patches are currently recommended for this ${dbverfull}"| tee -a $LOGFILE
   printf "\ndatabase ORACLE_HOME." | tee -a $LOGFILE
   printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
 fi

 if test "${contextfile}" != "none" ; then
    updateResInDB
 fi 
# end empty bug list check
 fi 
# end SQLpatch check
fi 
   exit_code="ETCC-0000"
} #end of runProcess_1

list_already_applied_patches() {
 oplist="${PTCH_TMP}/opatch_$$.lst"
 oplsinv="${PTCH_TMP}/opatchlsinv.lst"
 plist="${PTCH_TMP}/patch_$$.lst"
 dlist="${PTCH_TMP}/dpatch_$$.lst"
 #xlist="${PTCH_TMP}/xpatch_$$.lst"
 xlist="/tmp/xpatch.lst"

 # get the list of patches
 if test "${sqlpatchesonly}" = "y" ; then
   $OPATCH lsinventory -detail |grep sqlpatch > ${oplist}
   opatch_code=$?
 else
   $OPATCH lspatches -bugs > ${oplist}
   opatch_code=$?
 fi
 

 if test "$opatch_code" != "0" ; then
     #Error running opatch
     exit_code="ETCC-0057"
     exit_script
 fi

 opOut=`grep "no Interim patches" ${oplist}`
printf "\nChecking for applied patch history:" | tee -a $LOGFILE
 if test "${opOut}x" = "x" ; then
   # Patches have been applied
   printf "\nFound patch history in the inventory.\n" | tee -a $LOGFILE
   if test "${sqlpatchesonly}" = "y" ; then
      ListSQLPatches
   else
     #remove all blank spaces and empty lines
     sed '/^$/d;s/ //g' ${oplist} > ${oplist}1  
     mv ${oplist}1 ${oplist}
     for line in `cat ${oplist}`
     do
       patchnum=`echo ${line} | cut -d";" -f1 `
       bugsnum=`echo ${line} | cut -d";" -f3 `

       if test "${bugsnum}x" = "x" ; then
     bugsnum=`echo ${line} | cut -d";" -f2 `
       fi

       if test "${bugsnum}x" = "x" ; then
           #Error reading opatch utility output
           exit_code="ETCC-0059"
           exit_script
       fi
       if test "$patchnum" != "$bugsnum" ; then
           echo "${patchnum}" >>${plist}
     bugsnum=`echo ${bugsnum} | tr "," "\012" `
           echo "${bugsnum}" >> ${plist}
       else
            echo "${patchnum}" >> ${plist}
       fi
     done
    fi     
 else
     # No patches applied to this OH
     printf "\n No patch records found in the inventory.\n"| tee -a $LOGFILE
     echo "" >> ${plist}
     listdiffs="n"
 fi

 # sort the file with the list of applied patches/bug fixes
 sed '/^$/d' ${plist} >> ${plist}1
 mv ${plist}1 ${plist}

 sort ${plist} | uniq > ${PATCHES_APPLIED}

 IFS=$oIFS # Solaris compatibility
 } # End of list_already_applied_patches()

runDiffsCheck(){

  # Read existing opatchlist but remove "Opatchsucceeded." line
  `cat ${oplist} |grep -v OPatch >> ${oplist}1`
  mv ${oplist}1 ${oplist}
  for line in `cat ${oplist}`
   do
       patchnum=`echo ${line} | cut -d";" -f1 `
       bugsnum=$patchnum

       if test "${bugsnum}x" = "x" ; then
          bugsnum=`echo ${line} | cut -d";" -f2 `
       fi
       if test "${bugsnum}x" = "x" ; then
         #Error reading opatch utility output
          exit_code="ETCC-0059"
          exit_script
       fi     
       if test "$patchnum" != "$bugsnum" ; then
          echo "${patchnum}" >>${dlist}
          bugsnum=`echo ${bugsnum} | tr "," "\012" `
          echo "${bugsnum}" >> ${dlist}
       else
          echo "${patchnum}" >> ${dlist}
       fi
   done

  # sort the file with the list of applied patches/bug fixes
  sed '/^$/d' ${dlist} >> ${dlist}1
  mv ${dlist}1 ${dlist}
  sort ${dlist} | uniq > ${DIFF_PATCHES_APPLIED}
  IFS=$oIFS # Solaris compatibility
}

findDiffsDetails(){
  printf '%s\n' "$OHOME_EXTRAS" | while IFS= read -r line
  do
       patchnum=`echo ${line}`
       printf "\n\nPatch ${patchnum} details" | tee -a $LOGFILE
       printf "\n------------------------" | tee -a $LOGFILE
       patchdetails1=`$OPATCH lspatches -id ${patchnum}`
       patchdetails=`echo ${patchdetails1} | sed 's/OPatch succeeded.//g'`
       printf "\n${patchdetails}" | tee -a $LOGFILE
       patchsqldetails=`$OPATCH lsinventory -detail |grep sqlpatch |grep ${patchnum}`
       if test "${patchsqldetails}x" != "x" ; then
          printf "\nsql files:\n${patchsqldetails}" | tee -a $LOGFILE
       fi
  done
  printf "\n-----------------------------------------------------------------------------------------"| tee -a $LOGFILE

}

setSQLplusenv(){

ORACLE_HOME=$ORACLE_HOME
export ORACLE_HOME
ORACLE_SID=$ORACLE_SID
export ORACLE_SID
# Check for multitenant and set temp env vars accordingly
# The following was removed for Bug 26940382
#if test "${isMultiTenant}" = "true" ; then
   #printf "\nMulti-tenant identified."
#   oracle_sid_org=${ORACLE_SID}  
#   ORACLE_SID=${ORACLE_CDB_SID}
#   export ORACLE_SID
   #printf "\nMultitenant: Temporarily setting ORACLE_SID=${ORACLE_SID}."
#fi
}

checkDSTversion(){
  # Check version of DST and retrieve from Database if it's running
  if [ $dbup != 0 ] ; then
    setSQLplusenv
 
    getDSTversion=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOSDST
    set head off feedback off verify off pagesize 0
    ${altersession}
    select version from v\\\$timezone_file;
    exit;
EOSDST
`
    DSTversion=`echo ${getDSTversion} | sed 's/^$//g'`
 
    if test "${DSTversion}x" = "x" ; then
      printf "\nUnable to identify database DST version.\n" | tee -a $LOGFILE
    else
      printf "\nIdentified database DST version: ${DSTversion}\n" | tee -a $LOGFILE
    fi
  else
  # Check version from the file system
    if test -f ${ORACLE_HOME}/oracore/zoneinfo/readme.txt ; then
      DSTversion="`grep 'Current Content Version' ${ORACLE_HOME}/oracore/zoneinfo/readme.txt |${AWK} NR==1 |sed -e 's/.*://'`"
      printf "\nInstalled DST version under \$ORACLE_HOME/oracore/zoneinfo is DST ${DSTversion}.\n" >> $LOGFILE
    fi
  fi
}

checkDB() {
# check DB connectivity
setSQLplusenv

printf "\nConnecting to database. "  | tee -a $LOGFILE
dbconn=`$ORACLE_HOME/bin/sqlplus / as sysdba <<EOS
exit
EOS
`

#need the : at the end else idle instance connection will return success
dbstat=`echo $dbconn | grep "Connected to:"`
result=$?

if [ $result -eq 0 ]
then
   printf "\nDatabase connection successful. \n" | tee -a $LOGFILE
   dbup=1
   storeresults="y"
else
   dbup=0
   storeresults="n"
fi

}
# Bug 21073382
identifyAPPS(){
setSQLplusenv
printf "\nIdentifying APPS and APPLSYS schema names. " | tee -a $LOGFILE
schemaname=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS1
set head off feedback off verify off pagesize 0
${altersession}
select oracle_username from ebs_system.fnd_oracle_userid where read_only_flag ='U';
exit;
EOS1
`

sqlerror=`echo ${schemaname} | grep "ORA-"`
result=$?

if [ $result -eq 0 ] # If result contains ORA- then check failed
  then
  #printf "\n[DEBUG] SQL output is :\n${schemaname}\n" | tee -a $LOGFILE
  schemaname=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS1
    set head off feedback off verify off pagesize 0
    ${altersession}
    select oracle_username from system.fnd_oracle_userid where read_only_flag ='U';
    exit;
EOS1
`
    sqlerror=`echo ${schemaname} | grep "ORA-"`
    result=$?
    if [ $result -eq 0 ]; then # If result contains ORA- then check failed
      appsuser=""
      #printf "\n[DEBUG] SQL output is :\n${schemaname}\n" | tee -a $LOGFILE
    else
      appsuser=`echo ${schemaname} | sed 's/^$//g'`
    fi
else
  appsuser=`echo ${schemaname} | sed 's/^$//g'`
fi

if test "${appsuser}x" = "x" ; then
  printf "\nFailed to identify APPS schema." | tee -a $LOGFILE
  printf "\nEnter the Applications 'APPS' user: "
  read appsuser
fi

printf "\n - APPS schema: ${appsuser}" | tee -a $LOGFILE
identifyAPPLSYS


}
# Bug 21073382
identifyAPPLSYS(){
setSQLplusenv
schemaname=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS1
set head off feedback off verify off pagesize 0
${altersession}
select oracle_username from ebs_system.fnd_oracle_userid where read_only_flag ='E';
exit;
EOS1
`
sqlerror=`echo ${schemaname} | grep "ORA-"`
result=$?

if [ $result -eq 0 ] # If result contains ORA- then check failed
  then
  #printf "\n[DEBUG] SQL output is :\n${schemaname}\n" | tee -a $LOGFILE
 schemaname=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS1
     set head off feedback off verify off pagesize 0
     ${altersession}
     select oracle_username from system.fnd_oracle_userid where read_only_flag ='E';
     exit;
EOS1
`
   sqlerror=`echo ${schemaname} | grep "ORA-"`
   result=$?
    if [ $result -eq 0 ] # If result contains ORA- then check failed
     then
       #printf "\n[DEBUG] SQL output is :\n${schemaname}\n" | tee -a $LOGFILE
       applsysuser=""
    else
       applsysuser=`echo ${schemaname} | sed 's/^$//g'`
    fi
else
  applsysuser=`echo ${schemaname} | sed 's/^$//g'`
fi


if test "${applsysuser}x" = "x" ; then
  printf "\nFailed to identify APPLSYS schema." | tee -a $LOGFILE
  printf "\nEnter the Applications 'APPLSYS' user: "
  read applsysuser
fi

printf "\n - APPLSYS schema: ${applsysuser}\n" | tee -a $LOGFILE


}
checkForEtccTable(){
setSQLplusenv
printf "\nChecking for existence DB-ETCC results table. " | tee -a $LOGFILE
# check for TXK_TCC_RESULTS table existence

# Check for multitenant and set temp env vars accordingly
# The following was removed for Bug 26940382
#if test "${isMultiTenant}" = "true" ; then
   #printf "\nMulti-tenant identified."
#   oracle_sid_org=${ORACLE_SID}  
#   ORACLE_SID=${ORACLE_CDB_SID}
#   export ORACLE_SID
   #printf "\nMultitenant: Temporarily setting ORACLE_SID=${ORACLE_CDB_SID}."
#fi

tblExists=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS1
set head off feedback off verify off pagesize 0
${altersession}
select 1 from all_tables where table_name='TXK_TCC_RESULTS' and owner='${applsysuser}';
exit;
EOS1
`

tblExists=`echo ${tblExists} | sed 's/^$//g'`
if test "${tblExists}x" = "x" ; then
  tblExists=0
fi

if test "${tblExists}" != "1" ; then
	if test "${DBmode}" != "0" ; then
       printf "\nCreating DB-ETCC results table. " | tee -a $LOGFILE
	   $ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS2
           whenever sqlerror exit sql.sqlcode;
    	  set head off feedback off verify off pagesize 0
        ${altersession}
	      CREATE TABLE ${applsysuser}.TXK_TCC_RESULTS
	      ( tcc_version   VARCHAR2(20) NOT NULL,
    	    bugfix_xml_version VARCHAR2(20) NOT NULL,
	       node_name  VARCHAR2(100) NOT NULL,
		database_name  VARCHAR2(64) NOT NULL,
	        component_name  VARCHAR2(10) NOT NULL,
    	    component_version VARCHAR2(20) NOT NULL,
	        component_home   VARCHAR2(600),
		check_date	DATE,
		check_result  VARCHAR2(10) NOT NULL,
    	  	check_message VARCHAR2(4000)
	      );
	      GRANT select on ${applsysuser}.TXK_TCC_RESULTS to ${appsuser};
	    exit;
EOS2
 	    create_code=$?
    	if test "$create_code" != "0" ; then
          printf "\n[WARNING]\n Could not create database table to store DB-ETCC results." | tee -a $LOGFILE
    	  printf "\nUnable to store results in the database.\n" | tee -a $LOGFILE
	  printf "\nEnsure the database is available, and then rerun DB-ETCC.\n" | tee -a $LOGFILE
        else
          tblExists="1"
	  printf "\nCreated the table to store DB-ETCC results.\n" | tee -a $LOGFILE
    	 fi
      else
          printf "\n[WARNING] DB-ETCC: \n"| tee -a $LOGFILE
	  printf "  The database is not open in READ-WRITE mode.\n" | tee -a $LOGFILE
	  printf "  Could not create table to store DB-ETCC results.\n" | tee -a $LOGFILE
      fi
else
     printf "\nTable to store DB-ETCC results already exists in the database.\n" | tee -a $LOGFILE
fi
# Bug 24007644 - Create synonym
$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS3
set head off feedback off verify off pagesize 0
${altersession}
CREATE OR REPLACE SYNONYM ${appsuser}.TXK_TCC_RESULTS FOR ${applsysuser}.TXK_TCC_RESULTS;
exit;
EOS3
}

checkGrid() {

  invreport=${LOCAL_TEMP}/lsinventory.txt

  if test "${ORACLE_HOME}x" = "x" ; then
    printf "\nCannot determine ORACLE_HOME from environment."
    printf "\nEnter the ORACLE_HOME: "
    read ORACLE_HOME
  fi
  $ORACLE_HOME/OPatch/opatch lsinventory > ${invreport}
  opatch_code=$?

  if test "$opatch_code" != "0" ; then
    #Error running opatch
    exit_code="ETCC-0057"
    exit_script
  fi

  gridvers="`grep 'Oracle Grid Infrastructure' ${invreport} |${AWK} NR==1{'print $5'}`"
  #printf "\nDEBUG: gridvers is ${gridvers}."| tee -a $LOGFILE

  if test "${gridvers}x" != "x" ; then
    GridHome="y"
    contextfile="none"
    #RAC DB ETCC code not relevant for GRID
    isRacEnv="n"
    racornot="false" # RAC DB ETCC code not relevant for GRID
    isPatchMap="n" # Patch mapping currently not supported for GRID
    hometype="Grid Infrastructure"
    DB_VERSION=`echo ${gridvers} | ${AWK} -F\. '{
    if ($3 == "") t="0";
       else t=$3;
    if ($4 == "") f="0";
       else f=$4;
    printf "%s.%s.%s.%s",$1,$2,t,f }'`
    tsvers=$DB_VERSION
  if test "${cloud}" = "y"; then
    if test "${cloudService}x" = "x"; then
      AutomationMode
    else
      MatchCloudXMLtags
    fi
  fi
    printf "\n\nOracle Grid Infrastructure ${tsvers} identified.\n" | tee -a $LOGFILE
    mapvers=${DB_VERSION}
    listvers=${DB_VERSION}
    DB_REL=`echo ${gridvers} |${AWK} -F\. '{print $1}'`
    TECHNAME="GRID_HOME"
  else
    GridHome="n"
    hometype="database"
    printf "\nOracle Grid Infrastructure not identified.\n" | tee -a $LOGFILE
  fi 
 
  #Grid on cloud not supported 
  if test "${cloud}" = "y" ; then
   #There are currently no recommended one-off bugfixes for Oracle Grid Infrastructure.
    exit_code="ETCC-0022"  
    exit_script
  fi
} # end checkGrid

checkContext() {
    printf "\nValidating context file: ${contextfile}\n" | tee -a $LOGFILE
    ORACLE_HOME=`grep s_db_oh ${contextfile} | sed 's/^.*s_db_oh[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
     

  if test "${ORACLE_HOME}x" = "x" ; then
   #Unable to read the value of s_db_oh from the context file.
    exit_code="ETCC-0033" 
    exit_script
  fi
} #end checkContext

checkInMemory() {
printf "\nChecking if InMemory option is enabled. " | tee -a $LOGFILE
inmemsize=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS3
set head off verify off feedback off pagesize 0
${altersession}
select value from v\\\$parameter where name = 'inmemory_size';
exit;
EOS3
`

if test "${inmemsize}x" != "x" -a "${inmemsize}" != "0" ; then
    isDBIM="y"
    printf "\nInMemory option is enabled in the database.\n"| tee -a $LOGFILE	
    #printf "InMemory size: ${inmemsize} \n"
    IMheader="- InMemory"
else
    isDBIM="n"
    printf "\nInMemory option is not enabled in the database.\n"| tee -a $LOGFILE

fi
}


checkASM(){ # ASM is only enabled on OCI DBaaS SI and not OCI DBCS
if [ $dbup != 0 ] ; then

setSQLplusenv
asmdisks=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS1
set head off feedback off verify off pagesize 0
${altersession}
select count(*) from v\\\$asm_disk;
exit;
EOS1
`
 sqlerror=`echo ${askdisks} | grep "ORA-"`
 result=$?

 if [ $result -eq 0 ] ; then # If result contains ORA- then check failed
  #printf "\n[DEBUG] SQL output is :\n${asmdisks}\n" | tee -a $LOGFILE
  asmdisks=""
 else
  askdisks=`echo ${asmdisks} | sed 's/^$//g'`
 fi

#printf "\n[DEBUG] ASMDISKS value is now :\n${asmdisks}\n" | tee -a $LOGFILE


 if test "${asmdisks}x" = "x" ; then
  printf "\n[ERROR] Failed to identify if ASM is in use" | tee -a $LOGFILE
  printf "\nMake sure the database is up and connectivity exists, and re-run the Technology Codelevel Checker." | tee -a $LOGFILE
 else
  if [ $asmdisks -eq 0 ] ; then
    isASMenabled="n"
    isDBSI="n"
  else
    printf "\nASM storage identified.\n" | tee -a $LOGFILE
    isASMenabled="y"
    isDBSI="y"
  fi
 fi
else # DB is down
  if test -f /opt/oracle/dcs/bin/odacli -o -f /opt/oracle/dcs/bin/dbcli ; then
    # These utilities only exist on OCI DBaaS SI (so we use BMCS_ASM tag)
    isASMenabled="y"
    isDBSI="y"
  else
    # Revert to OCI DBCS (BMCS tag)
    isASMenabled="n"
    isDBSI="n"
  fi
fi

}
#This subroutine is never called kepted for history
checkOPC() {
if test -f /usr/bin/platforminfo ; then
  cloud="y"
  ocitoolexists="y"
  checkPlatformInfo
else
  if test -f /usr/bin/dbaascli -o -f /opt/oracle/dcs/client/bin/raccli ; then
    printf "\nOracle Database Cloud Service utilities found.\n"| tee -a $LOGFILE
    cloud="y"
  else 
    if test -f /opt/oracle/dcs/bin/odacli -o -f /opt/oracle/dcs/bin/dbcli ; then
       printf "\nOracle Cloud Infrastructure utilities found.\n"| tee -a $LOGFILE
       cloud="y"
    fi
  fi
fi
}

checkExaData() {
   if test -d /etc/oracle/cell -o -f /opt/oracle.cellos/ORACLE_CELL_OS_IS_SETUP ; then
        if test "${cloud}" != "y" ; then
          printf "\nRunning on an Engineered System.\n"| tee -a $LOGFILE
        fi
        if test ${DB_REL} -ge 12 ; then
           isDBIM="y"
           IMheader="- Engineered Systems"
        else
           DB_VERSION="${tsvers}_ES"
        fi
        if test "${GridHome}" = "y"; then
           DB_VERSION="${tsvers}_ES"
        fi

        isExa="y"
        isRacEnv="y"
        if test "${cloud}" != "y" ; then
          if test ${DB_REL} -lt 19; then
           mosID="KB811383"
          else
           mosID="KB157201"
          fi

        fi
        mosnote="Refer to My Oracle Support article ${mosID} to find the recommended combination of patches.\n"
    fi
}


updateResInDB(){
# Update the results into DB

#Check for supported database version
 if test "${isNewer}" = "true" ; then
  TCCresult="MISSING"
  if test "${cloud}" = "y" ; then
    if test "${myrealm}" = "oc1"; then
     MissRlbkFix="${patch_update_patchid}"
    else
      MissRlbkFix="${tsvers} not supported by ETCC, review ${mosID} for supported releases"
    fi
  else
   #On prem
   MissRlbkFix="${release_update_patchid}"
  fi
 fi

InsCmd="INSERT INTO ${applsysuser}.TXK_TCC_RESULTS (tcc_version,bugfix_xml_version,node_name, database_name,component_name,component_version,component_home,check_date,check_result, check_message) values"
tccversion=$progver
tccexectime=$execdate
tccresult=$TCCresult
xmlversion=$xmlver
#handle for test case contextfile = none, this is not supported in production
if test "${contextfile}" != "none"; then
  server=`grep s_dbhost ${contextfile} | sed 's/^.*s_dbhost[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g' | cut -d"." -f1`
  physserver=`grep s_hostname ${contextfile} | sed 's/^.*s_hostname[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g' | cut -d"." -f1`
else 
  server="unknown"
  physserver="unknown"
fi

dbname=$DBNAME
compver=$DB_VERSION
compname="RDBMS"
comphome=$ORACLE_HOME
chkmesg1=`echo ${MissRlbkFix}| tr "\012" "," `
chkmesg=`echo ${chkmesg1}| sed 's/.$//'`

if [ $dbup -eq 1 ] 
then
   dbname=`$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOSR
    set head off feedback off verify off pagesize 0
    ${altersession}
    select SYS_CONTEXT('USERENV','DB_NAME') from dual;
    exit;
EOSR`

DelCmd="DELETE from ${applsysuser}.TXK_TCC_RESULTS where component_name='$compname' and (lower(node_name)=lower('$server') or lower(node_name)=lower('$physserver'));"
  
  # Bugs 23023865 / 24301355 / 20795308/34059603 - Use Physical Server server name for all 
   InsCmd="${InsCmd} ('$tccversion', '$xmlversion', '$physserver', '$dbname', '$compname', '$compver', '$comphome', to_date('$tccexectime','dd-mm-yyyy HH24:MI:SS'), '$tccresult', '$chkmesg'); "

  # Bug 28792363 - For VMDB RAC we also need to store value of s_hostname, not s_dbhost

  if test "${cloud}" = "y" -a "${cloudService}" = "vmdbrac" ; then
    InsCmd="INSERT INTO ${applsysuser}.TXK_TCC_RESULTS (tcc_version,bugfix_xml_version,node_name, database_name,component_name,component_version,component_home,check_date,check_result, check_message) values"
    InsCmd="${InsCmd} ('$tccversion', '$xmlversion', '$physserver', '$dbname', '$compname', '$compver', '$comphome', to_date('$tccexectime','dd-mm-yyyy HH24:MI:SS'), '$tccresult', '$chkmesg'); "
  fi

	if test "${DBmode}" != "0" ; then
            #printf "\n[DEBUG] DELETE SQL:\n${DelCmd}\n" >> $LOGFILE
            #printf "\n[DEBUG] INSERT SQL:\n${InsCmd}\n" >> $LOGFILE
           if test ${updatedb} != "skip";  then
		$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" <<EOS3
                 whenever sqlerror exit sql.sqlcode;
	     set head off feedback off verify off pagesize 0
       ${altersession}
	     ${DelCmd}
	     ${InsCmd}
	     commit;
	     exit;
EOS3
		 sqlstmt_code=$?
		 if test "$sqlstmt_code" != "0" ; then
		      printf "\nUnable to insert Technology Codelevel Checker result in the database." | tee -a $LOGFILE
		      printf "\nMake sure the database is up and connectivity exists, and re-run the Technology Codelevel Checker." | tee -a $LOGFILE
		 else
		      printf "\n\nSuccessfully stored results of ETCC run in database ${dbname}.\n" >> $LOGFILE
		 fi
          fi #updatedb skip
	else
		printf "\n[WARNING] Database mode is ${DBmode}:\n" | tee -a $LOGFILE
		if test "${tblExists}" = "1" ; then
			printf "To store the results of DB-ETCC, open the database in READ-WRITE\n" | tee -a $LOGFILE
			printf "mode and run the following SQL statements using SQL*Plus in the order shown.\n" | tee -a $LOGFILE
    	                printf "\n1. ${DelCmd}\n" | tee -a $LOGFILE
			printf "2. ${InsCmd}\n" | tee -a $LOGFILE
    		        printf "3. commit;\n" | tee -a $LOGFILE
			printf "4. exit;\n\n" | tee -a $LOGFILE
		else
			printf "Open the database in READ-WRITE mode and then rerun DB-ETCC." | tee -a $LOGFILE
			printf "Otherwise the results will \nnot be stored in the database.\n" | tee -a $LOGFILE
		fi
	fi
else
   printf "\n[WARNING] Database not available. DB-ETCC results cannot be stored.\n" | tee -a $LOGFILE
fi
  updatedb="y"
}

checkRAC() {
DBNAME=`$ORACLE_HOME/bin/sqlplus  -s "/ as sysdba" <<EOSR
    set head off feedback off verify off pagesize 0
    ${altersession}
    select SYS_CONTEXT('USERENV','DB_NAME') from dual;
    exit;
EOSR`
export DBNAME
}

checkDBmode(){
# check if DB is open in READ WRITE mode

if test "${isMultiTenant}" = "true" ; then
  dbmode=`$ORACLE_HOME/bin/sqlplus  -s "/ as sysdba" <<EOSM
  set head off feedback off verify off pagesize 0
  SELECT open_mode FROM v\\\$pdbs where upper(name) = upper('${oracle_pdb}');
  exit;
EOSM
`
else
  dbmode=`$ORACLE_HOME/bin/sqlplus  -s "/ as sysdba" <<EOSM
  set head off feedback off verify off pagesize 0
  select open_mode from v\\\$database;
  exit;
EOSM
`
fi


printf "\nDatabase ${DBNAME} is in ${dbmode} mode.\n" | tee -a $LOGFILE
if test "${dbmode}x" != "x" -a "${dbmode}" = "READ WRITE" ; then
	DBmode="1"
else
	DBmode="0"
    export DBmode
fi

# check if pdb is open
if test "${isMultiTenant}" = "true" -a "${dbmode}" = "MOUNTED"; then
    printDBdownWarning
    #Pluggable database is not open
    exit_code="ETCC-0088"
    exit_script
fi

}

checkECS() {

# Check for Error Correction Support
rm -f ${LOCAL_TEMP}/${TECHNAME}.ecs
if test "${tsvers}" = "11.2.0.3" -o  "${tsvers}" = "12.1.0.1" ; then
   obsolete="y"
   touch ${LOCAL_TEMP}/${TECHNAME}.ecs
   # Store part of the warning in a temp ECS file for the patch recommendation summary
   printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
   printf "\n[ERROR] ETCC cannot list required fixes:\n"| tee -a $LOGFILE
   printf "${hometype} ${DB_VERSION} is no longer covered by Error Correction Support\n" | tee -a $LOGFILE
   printf "or compatible with ETCC. For ETCC to be able to provide a list of missing bug\n" | tee -a $LOGFILE
   printf "fixes and patch mappings, upgrade to an Oracle database version listed in article KA989.\n"| tee -a $LOGFILE
   printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE  
   printf "  Upgrade Required\n" >> ${LOCAL_TEMP}/${TECHNAME}.ecs   
fi
# End check

}

checkBundleversion() {
bundleapplied="n"
if test ${DB_REL} -gt 12 ; then
   # Check for RUR first as ETCC does not support them
   bundlevers="`$OPATCH lspatches|grep -i 'Database Release Update Revision :' |${AWK} NR==1{'print $6'}`"
   if test "${bundlevers}" = ":" ; then
      bundlevers="`$OPATCH lspatches|grep -i 'Database Release Update Revision :' |${AWK} NR==1{'print $7'}`"
   fi

   if test "${bundlevers}x" != "x" ; then
      getBPversion
      bpheader="RELEASE UPDATE REVISION"
      patchmapID="DBRUR"
      patchheader="DBRUR"

      printf "\nDatabase Release Update Revision ${bundlevers} has been applied.\n" | tee -a $LOGFILE
      isPatchMap="n" # Patch mapping not supported for RURs
      printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
      printf "\n[WARNING] Patch mapping disabled." | tee -a $LOGFILE 
      printf "\nDatabase Release Update Revision ${bundlevers} has been applied." | tee -a $LOGFILE
      printf "\nETCC only provides patch mappings for Database Release Updates." | tee -a $LOGFILE       
      printf "\nDatabase Release ${dbverfull} will use ${tsvers}_RU bugfixes from ${BUG_LIST_FILE}\n" | tee -a $LOGFILE       
      printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
   # Check for Release Update
   else 

     bundlevers="`$OPATCH lspatches|grep -i 'Database Release Update :' |${AWK} NR==1{'print $5'}`"
     if test "${bundlevers}" = ":" ; then
        bundlevers="`$OPATCH lspatches|grep -i 'Database Release Update :' |${AWK} NR==1{'print $6'}`"
     fi

      getBPversion
      bpheader="RELEASE UPDATE"
      patchmapID="DBRU"
      patchheader="DBRU"

   fi
fi
if test "${relnum}" = "12" ; then
   bundlevers="`$OPATCH lspatches|grep -i 'DATABASE BUNDLE PATCH' |${AWK} NR==1{'print $4'}`"
   if test "${bundlevers}" = ":" ; then
      bundlevers="`$OPATCH lspatches|grep -i 'DATABASE BUNDLE PATCH' |${AWK} NR==1{'print $5'}`"
   fi

   getBPversion
   bpheader="BUNDLE PATCH"
   patchmapID="ProactiveBP"
   patchheader=" ProactiveBP"
fi
if test "${relnum}" = "11" ; then

   bundlevers="`$OPATCH lspatches|grep 'DATABASE PATCH FOR EXADATA' |${AWK} NR==1{'print $7'} | sed 's/)//g'`"
   if test "${bundlevers}" = "-" ; then
      bundlevers="`$OPATCH lspatches|grep 'DATABASE PATCH FOR EXADATA' |${AWK} NR==1{'print $8'} | sed 's/)//g'`"
   fi
   getBPversion
   bpheader="EXADATA BUNDLE PATCH"
   patchmapID="ExadataDatabase"
   patchheader=" ExadataDatabase"
fi

if test "${bpversion}x" != "x" ; then
   bundleapplied="y"
   PrintMissingPatchMessageFlag="y"
   #DOTheader="(${bpheader} ${tsvers}.${bpversion})"
   #printf "\n[DEBUG] DOTheader=${bpheader} ${tsvers}.${bpversion}"

   if test ${DB_REL} -gt 19 ; then
      patchrelease="${tsvers}"
      DOTheader="(${bpheader} ${tsvers})"
    else
     if test ${DB_REL} -gt 12; then
      patchrelease="${tsvers}.0 ${patchheader}"
     else
      patchrelease="${tsvers}.${bpversion}${patchheader}"
     fi
   fi
   if test "${relnum}" = "11" ; then
      TAGID="ES"
   fi
else
    DOTheader="(No Bundle Patch applied)"
    patchrelease="${tsvers}.0"
fi

if test "${bundleapplied}" = "y" ; then
  if test ${DB_REL} -gt 19 ; then
    mapvers="${tsvers}${patchmapID}"
    listvers="${tsvers}"
    ojvmbundle="ojvm_${bpversion}"
    #printf "\nDEBUG  mapvers = ${mapvers}"
    #printf "\nDEBUG BP ojvmbundle = ${ojvmbundle}"
  else
    mapvers="${tsvers}.${bpversion}${patchmapID}"
    listvers="${tsvers}.${bpversion}"
    ojvmbundle="ojvm_${bpversion}"
    #printf "\nDEBUG  mapvers = ${mapvers}"
    #printf "\nDEBUG BP ojvmbundle = ${ojvmbundle}"
  fi
else 
#DB23ai version 23.5 does not have an RU in inventory
 if test ${DB_REL} -eq 23; then
  relresult=`echo "if ( $DB_VERSION == 23.5 ) 1" | bc`
  if test "${relresult}x" = "1x" ; then
    mapvers="${tsvers}${patchmapID}"
    listvers="${tsvers}"
    ojvmbundle="ojvm_${bpversion}"
    bundleapplied="y"
    #printf "\nDEBUG 23.5 mapvers = ${mapvers}"
    #printf "\nDEBUG BP ojvmbundle = ${ojvmbundle}"
  fi 
 fi
fi   
}

getBPversion () {
   bpversion=`echo ${bundlevers} | ${AWK} -F\. '{
    t=$5;
   printf t}'`
}

checkPSUversion () {
   psuapplied="n"
   psuvers="`$OPATCH lspatches|grep 'Database Patch Set Update' |${AWK} NR==1{'print $6'}`"
   psuversion=`echo ${psuvers} | ${AWK} -F\. '{
    t=$5;
        printf t}'`

   if test "${psuversion}x" != "x" ; then
     psuapplied="y"
     mapvers="${tsvers}.${psuversion}"
     listvers="${tsvers}.${psuversion}"
     patchrelease=${mapvers}
     DOTheader="(PATCHSET UPDATE ${tsvers}.${psuversion})"
     TAGID="PSU"
     PrintMissingPatchMessageFlag="y"
     if test "${cloud}" != "y" ; then
        mosID="KA1094"
     fi
     mosnote="Refer to My Oracle Support article ${mosID} to find the corresponding overlay patch that delivers the bugfix."
     ojvmbundle="ojvm_${psuversion}"
     #printf "\nDEBUG PSU ojvmbundle = ${ojvmbundle}"
   else
     if test "${bundleapplied}" = "n"; then
      DOTheader="\n\n[WARNING] No BP or PSU has been applied. You should apply the latest recommended BP\nor PSU as appropriate. For a BP, refer to My Oracle Support article KA989. For a PSU,\nrefer to My Oracle Support article KA1094.\n"
     else
       DOTheader="(No PSU applied)"
     fi
     psuapplied="n"
     patchrelease="${tsvers}.0"
   fi 
}
MapBugfixIDtoPatchID() {
	# Patch Mappings
	# To avoid Bug 21557632 - 3,000 bytes AWK limit on HP, using sed as alternative for all platforms 
	sed -n "/EBS release/,/EBS> / p" ${MAP_LIST_FILE} > ${LOCAL_TEMP}/mappings.out
	cat ${LOCAL_TEMP}/mappings.out | sed -n "/${TECHNAME}/,/<\/Technology>/p" > ${LOCAL_TEMP}/mappings0.out
	cat ${LOCAL_TEMP}/mappings0.out | sed -n -e "/\"${mapvers}\"/,/<\/Technology>/p" > ${LOCAL_TEMP}/mappings1.out
	cat ${LOCAL_TEMP}/mappings1.out | sed -n -e "/${bugfixtoapply}/,/<\/base_bugs>/p" > ${LOCAL_TEMP}/mappings2.out
	cat ${LOCAL_TEMP}/mappings2.out | sed -n -e "/${PLAT}/,/<\/platform>/p" > ${LOCAL_TEMP}/mappings3.out
	cat ${LOCAL_TEMP}/mappings3.out | sed -n 's/^.*<\(patch_id\)>\([^<]*\)<\/.*$/\2/p' |sed 's/^[ \t]*//;s/[ \t]*$//'| tr ',' '\n' > ${LOCAL_TEMP}/missingpatch.out
  cat ${LOCAL_TEMP}/mappings3.out | sed -n 's/^.*<\(notes\)>\([^<]*\)<\/.*$/\2/p' |sed 's/^[ \t]*//;s/[ \t]*$//'| tr ',' '\n' > ${LOCAL_TEMP}/missingpatchnotes.out
  cat ${LOCAL_TEMP}/mappings3.out | sed -n 's/^.*<\(file_name\)>\([^<]*\)<\/.*$/\2/p' |sed 's/^[ \t]*//;s/[ \t]*$//'| tr ',' '\n' > ${LOCAL_TEMP}/missingpatchfile.out

    mappedpatchid="`cat ${LOCAL_TEMP}/missingpatch.out`"
    mappedpatchnotes="`cat ${LOCAL_TEMP}/missingpatchnotes.out`"
    mappedpatchfilename="`cat ${LOCAL_TEMP}/missingpatchfile.out`"
    if test "${mappedpatchnotes}x" != "x" ; then
       mappedpatchnotes=" [${mappedpatchnotes}]"
    fi
    if test "${mappedpatchfilename}x" != "x" ; then
       mappedpatchfiletitle="    - Filename: ${mappedpatchfilename}"
    fi

   if test "${mappedpatchid}x" = "x" ; then
      if test "${cloud}" = "y" -a "${bugfixtoapply}" != "${patch_update_bugid}" ; then
        printf "  Bugfix ${bugfixtoapply} [Warning: No patch mapping data found.]\n    - Use My Oracle Support article ${mosID} to find the patch that delivers this bugfix.\n\n" >> ${LOCAL_TEMP}/${TECHNAME}.map
        mappedpatchid="data missing for bugfix ${bugfixtoapply}"
      fi
    else
        # Store mapped patch IDs in a temp file so we can print them as a summary
        checkforduplicate=`grep "${mappedpatchid}" ${LOCAL_TEMP}/${TECHNAME}.map`
        if test "${checkforduplicate}x" = "x" ; then
           printf "  Patch ${mappedpatchid}${mappedpatchnotes}\n${mappedpatchfiletitle}\n\n" >> ${LOCAL_TEMP}/${TECHNAME}.map
           printf "${mappedpatchfilename}\n" >> ${LOCAL_TEMP}/${TECHNAME}.files
           if test "${PLATFORM}" != "Solaris" ; then   #bug 26641323
              patchcount=`echo $(($patchcount + 1))`
           else
              patchcount=`expr $patchcount + 1`
           fi
        fi
    fi
    printf "\n  Missing Bugfix: $bugfixtoapply" | tee -a $LOGFILE
    printf "  ->  Patch ${mappedpatchid}" | tee -a $LOGFILE
    
    echo $patchcount > ${PATCHCOUNTER}
    # End Patch Mappings
}

printDBdownWarning() {

    printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
    printf "\n[WARNING] DB-ETCC: Could not connect to database, so unable to check:"| tee -a $LOGFILE
    printf "\n  - Whether database is in READ-WRITE mode. " | tee -a $LOGFILE 
    printf "\n  - Existence of table needed to store DB-ETCC results. " | tee -a $LOGFILE 
    if test ${DB_REL} -ge 12 ; then
        printf "\n  - Enablement of database In-Memory option. \n    If this feature is enabled, additional fixes need to be verified."|tee -a $LOGFILE 
        IMheader="- InMemory status unknown"
    fi
    if test "${cloudinfrastructure}" = "oci" -a "${isExa}" != "y" -a "${isRacEnv}" != "y" ; then
        printf "\n  - ASM storage\n    If ASM is in use, additional fixes need to be verified."|tee -a $LOGFILE 
    fi
    printf "\n\nResolve the database connectivity issue, and then rerun DB-ETCC." | tee -a $LOGFILE  
    printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE 
}

CheckBundleMissing() { 
BundleMissing=`grep "${bpheader}" ${LOCAL_TEMP}/${TECHNAME}.map`
 if test "${BundleMissing}x" != "x" -o "${BUNDLE_UPDATE_MISSING}" = "y" -a "${bundleapplied}" = "y" ; then
    if test "${BUNDLE_UPDATE_MISSING}" = "y" ; then
      MissingPatchTitle=" ${bundle_update_patchid} - ${bundle_update_desc}"
      missingfilename="${bundle_update_filename}"
    else
      MissingPatchTitle="${BundleMissing}"
    fi

    TCCresult="MISSING"
    MissRlbkFix="${MissingPatchTitle}"
    MissingPatchType="bundle patch"
    PrintConsolPatchMessage
    PrintMissingPatchWarning
 else
    PrintConsolPatchMessage

 fi
}

checkPlatformInfo() {
  # Identify Cloud PAAS
  if test -f /usr/bin/platforminfo ; then
     ocitoolexists="y"
     cmdresult=`/usr/bin/platforminfo`
     #printf "\nDEBUG: Platforminfo result is: ${cmdresult}" | tee -a $LOGFILE 

     case $cmdresult in
            "DBAAS") 
                cloudService="dbcs"
                cloudinfrastructure="classic"
              ;;
            "DBAASRAC") 
                cloudService="dbcsrac"
                cloudinfrastructure="classic"
                isRacEnv="y"
              ;;              
            "EXACS")
                cloudService="exacs"
                cloudinfrastructure="classic"
              ;;         
            "DBAASBM") 
                cloudService="dbcs"
                cloudinfrastructure="oci"
              ;;
            "DBAASRACBM") 
                cloudService="dbcs"
                cloudinfrastructure="oci"
                isRacEnv="y"
              ;;              
            "DBSIBM") 
                cloudService="dbsi"
                cloudinfrastructure="oci"
              ;;              
            "EXABM")
                cloudService="exabm"
                cloudinfrastructure="oci"
                isRacEnv="y"
              ;;               
            "EXACC")
                cloudService="exacc"
                cloudinfrastructure="oci"
                isRacEnv="y"
              ;;
      esac
  else
    ocitoolexists="n"
  fi

# For EXA, print warning regarding Cloud at Customer
  #Check and validate the target realm 
  if test "${realmdm}" != "gov" ; then
    if test "${cmdresult}" = "EXACS" -o "${cmdresult}" = "EXABM" -a "${exascale}" = "n" ; then
      printf "\nNote: If you are running on Oracle Exadata Database Service on Cloud@Customer, you must\n" | tee -a $LOGFILE
      printf "use the parameter service=exacc.\n" | tee -a $LOGFILE
    fi
  fi

  if test "${ocitoolexists}" = "n" -o "${cloudService}x" = "x" ; then

    # Check for RAC
    if test "${contextfile}" != "none" ; then
      racornot=`grep "s_dbCluster\"" ${contextfile} | sed 's/^.*s_dbCluster[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
      if test "${racornot}" = "true" -o "${racornot}" = "TRUE"; then
        isRacEnv="y"
      else
        isRacEnv="n"
      fi
    fi
   # Check for DBCS & DBCS RAC
    if test -f /usr/bin/dbaascli -o -f /opt/oracle/dcs/client/bin/raccli ; then
        
        if test -f /opt/oracle/dcs/client/bin/raccli ; then
          cloudService="dbcsrac"
          isRacEnv="y"
          #printf "\nRunning Oracle Database Cloud Services RAC.\n"| tee -a $LOGFILE
          if test "${isBMCS}" = "y" ; then
            cloudinfrastructure="oci"
          else
            cloudinfrastructure="classic"
          fi
        else
          cloudService="dbcs"
          isRacEnv="n"
          #printf "\nRunning Oracle Database Cloud Services Single Instance.\n"| tee -a $LOGFILE
          if test "${isBMCS}" = "y" ; then
            cloudinfrastructure="oci"
          else
            cloudinfrastructure="classic"
          fi
        fi
    fi
   # Check for DB SI
    if test -f /opt/oracle/dcs/bin/odacli -o -f /opt/oracle/dcs/bin/dbcli ; then
      cloudService="dbsi"
      cloudinfrastructure="oci"
      #printf "\nRunning Oracle VM DB System Single Instance."| tee -a $LOGFILE
    fi

    # Check for ExaCS / ExaBM

    if test -d /etc/oracle/cell -o -f /opt/oracle.cellos/ORACLE_CELL_OS_IS_SETUP ; then
      isCloudExa="y"
      if test "${isBMCS}" = "y" ; then
        cloudService="exabm"
        cloudinfrastructure="oci"
        isRacEnv="y"
        #printf "\nRunning Oracle Exadata Cloud Services Instance."| tee -a $LOGFILE
      else
        cloudService="exacs"
        cloudinfrastructure="classic"
        #printf "\nRunning Oracle Exadata Cloud Services OCI-C."| tee -a $LOGFILE
      fi
    fi

    # 
    if test "${cloudService}x" = "x" ; then
     #Unable to identify Oracle Cloud service
     exit_code="ETCC-0099"
     exit_script 
    else
      if test "${isRacEnv}" = "notset"; then
        askRAC
      fi
      MatchCloudXMLtags       
    fi
  else
      if test "${isRacEnv}" = "notset"; then
        askRAC
      fi
     
      MatchCloudXMLtags 
  fi 
}
MatchCloudXMLtags(){
  # Match cloudService to XML tags
  found="TRUE"
  case $cloudService in
      "dbcs")
        srvcsupport="n"
        cloudtag="DBCS"
        cloudServiceTitle="Database Cloud Services Single Instance"
        if test "${isRacEnv}" = "y"; then
          found="FALSE"
        fi
        mosID="2355477.1"
        ;;
      "dbcsrac")
        srvcsupport="n"
        cloudtag="DBCS_RAC"
        cloudServiceTitle="Database Cloud Services Oracle RAC"
        isRacEnv="y"
        mosID="2364423.1"
        ;;        
      "exacs")
        srvcsupport="n"
        cloudtag="EXACS"
        cloudServiceTitle="Exadata Cloud Services OCI-C"
        mosID="2346920.1"
        isExa="y"
        ;;         
      "dbsi")
         cloudServiceTitle="Base Database Service 1-Node DB System in Oracle Cloud"
           cloudtag="DBSI"

           case ${DB_REL} in 
              "11" ) 
               mosID="KB864300"
              ;;
              "12" ) 
               mosID="KB864290"
              ;;
              "19" ) 
               mosID="KA1103"

              ;;
              "23" ) 
               mosID="KA1153"
              ;;
           esac
         cloudinfrastructure="oci"
        if test "${isRacEnv}" = "y"; then
          found="FALSE"
        fi
        ;;
      "vmdbrac") 
         cloudServiceTitle="Base Database Service 2-Node DB System in an Oracle Cloud"
          cloudtag="VMDB_RAC"
           case ${DB_REL} in 
              "11" )
                mosID="KB864317"
              ;;
              "12" )
                mosID="KB864309"
              ;;
              "19" )
                mosID="KA1225"
              ;;
              "23" )
                mosID="KA1152"
              ;;
           esac
        cloudinfrastructure="oci"
        isRacEnv="y"
       ;;
      "exabm")
         cloudtag="OCIEXA"
         case ${DB_REL} in 
              "11" )
                mosID="KB857590"
              ;;
              "12" )
                mosID="KB857653"
              ;;
              "19" )
                mosID="KA1101"
              ;;
              "23" )
                mosID="KA1184"
              ;;
           esac
        
        if test "${exascale}" = "y"; then 
          cloudServiceTitle="Exadata Database Service on Exascale Infrastructure in Oracle Cloud"
          mosID="KA1331" 
        else
          cloudServiceTitle="Exadata Database Service on Dedicated Infrastructure in Oracle Cloud"
        fi
        cloudinfrastructure="oci"
        isRacEnv="y"
        isExa="y"
        ;;               
       "exacc")
        cloudtag="OCIEXA"
        cloudinfrastructure="oci"
        cloudServiceTitle="Exadata Database Service on Cloud@Customer in an Oracle Cloud"
         case ${DB_REL} in
              "11" )
                mosID="KB857590"
              ;;
              "12" )
                mosID="KB857653"
              ;;
              "19" )
                mosID="KA1101"
              ;;
              "23" )
                mosID="KA1184"
              ;;
           esac

        isRacEnv="y"
        isExa="y"
        ;;
        *)
        printf "\n\nCloud service ${cloudService} not valid. Trying to automatically identify service.\n"
        cloudService=""
        checkPlatformInfo
        found="FALSE"
        ;;
  esac

  if test "${found}" = "TRUE"; then
    printf "\n\nRunning on an Oracle ${cloudServiceTitle}." | tee -a $LOGFILE
  fi
}

# Identify realm domain: commercial, oraclecorp or gov, oraclegovcloud
CheckRealmDomain()  {
domain=""
#Exit if curl is not installed 
mycurl="`which curl 2>&1 | ${AWK} {'print $2'}`"
if test "${mycurl}x" != "x" ; then
 exit_code="ETCC-0100"
 exit_script
fi 
if test "${cloudService}" = "exacc" ; then
 domain="oraclecloud.com"
else
 domain="`curl -s -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/instance/ 2>&1 | grep realmDomainComponent | ${AWK} {'print $2'}| sed 's/\"//g' |sed 's/\,//g'`"
 if test "${domain}x" = "x" ; then
   domain="`curl -s http://169.254.169.254/opc/v1/instance/ 2>&1 | grep realmDomainComponent | ${AWK} {'print $2'}| sed 's/\"//g' |sed 's/\,//g'`"
 fi 
fi
# Verify REALM DOMAIN
 case $domain in 
    oraclecloud*.com)
      realmdm="com"
     ;;
    oraclegovcloud*.com) 
      realmdm="gov"
     ;;
    *)
      #ETE valid realm domain found 
      #	37481645
      realmdm="ete"
     ;;
  esac
if test "${domain}x" != "x" ; then
 printf "\nRealm domain validated: ${domain}\n" >> $LOGFILE
else   
 printf "\nError identifying realm domain: ${domain}" >> $LOGFILE
 printf "\nContinued processing...\n" >> $LOGFILE
fi

#printf "\nDEBUG domain = ${realmdm}\n"
} # end of CheckRealmDomain

#Identify current realm 
CheckRealm()  {
if test "${cloudService}" = "exacc" ; then
 #Set default realm for exacc
 myrealm="oc1"
else
 myrealm="`curl -s -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/instance/ 2>&1 | grep realmKey | ${AWK} {'print $2'}| sed 's/\"//g' |sed 's/\,//g'`"
 if test "${myrealm}x" = "x" ; then
   myrealm="`curl -s http://169.254.169.254/opc/v1/instance/ 2>&1 | grep realmKey | ${AWK} {'print $2'}| sed 's/\"//g' |sed 's/\,//g'`"
 fi
fi
if test "${myrealm}x" != "x" ; then
  printf "\nInstance realm: ${myrealm}\n" >> $LOGFILE
else
  printf "\nError identifying instance realm: ${myrealm}" >> $LOGFILE
  printf "\nContinued processing...\n" >> $LOGFILE
fi

#printf "\nDEBUG myrealm = $myrealm\n"
} # end of CheckRealm

# Get the service type
CheckType() {
infraType="`curl -s -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/instance/ | grep dbServiceType | ${AWK} -F":" '{print $2}' | sed 's/"//g; s/,//g; s/^[[:space:]]*//'`"

if test "${infraType}x" = "x"; then
    exascale="n"
else
lower_infraType=`echo "$infraType" | tr '[A-Z]' '[a-z]'`
    case $lower_infraType in
      "exadb-xs")
        exascale="y"
      ;;
      *)
       exascale="n"
      ;;
    esac
fi
} # end of  CheckType

CheckPSUMissing() {
PSUMissing=`grep "DB PATCH SET UPDATE" ${LOCAL_TEMP}/${TECHNAME}.map`
  if test "${PATCH_UPDATE_MISSING}" = "y" ; then
    printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
  fi
  if test "${PSUMissing}x" != "x" -o "${PATCH_UPDATE_MISSING}" = "y" -a "${psuapplied}" = "y"; then
    if test "${PATCH_UPDATE_MISSING}" = "y" ; then
     MissingPatchTitle=" ${patch_update_patchid} - ${patch_update_desc}"
     missingfilename="${patch_update_filename}"
    else
     MissingPatchTitle="${PSUMissing}"
    fi
    MissingPatchType="patch set"
    TCCresult="MISSING" 
    MissRlbkFix="${MissingPatchTitle}"
    PrintConsolPatchMessage
    PrintMissingPatchWarning
 else
    PrintConsolPatchMessage
 fi
 #For 19 onward on cloud
 if test "${PATCH_UPDATE_MISSING}" = "y" -a "${cloud}" = "y"; then
  MissingPatchType="Release Update"
  TCCresult="MISSING" 

  if test "${myrealm}" = "oc1" ; then
     MissingPatchTitle=" ${patch_update_patchid} - ${patch_update_desc}"
     missingfilename="${patch_update_filename}"
     PrintConsolPatchMessage 

  else
    if test "${serviceRU}x" != "x" ; then

     MissingPatchTitle="[WARNING] The database RU that you specified using the serviceRU parameter, ${serviceRU} has\n not yet been applied. Apply this RU by following\n the instructions in My Oracle Support article ${mosID}\n and then rerun checkDBpatch.sh to check for any further recommended patches."
    fi
  fi
  MissRlbkFix="${MissingPatchTitle}"
  PrintMissingPatchWarning
 fi
}

getIdTag() {

 relupdtline=`${AWK} -F'[<|/>]' '/'"$1"'/{u=$2}/platform/{b=$2}/bugid/{br=$3}/patch_id/{p=$3}/file_name/{f=$3}/notes/{n=$3; printf "%s:%s:%s:%s:%s:%s\n",u,b,br,p,f,n}' ${BUG_LIST_FILE} | grep ${PLAT} | grep $1`
}

CheckRUMissing() {
if test "${RELEASE_UPDATE_MISSING}" = "y" ; then
   # If Release Update missing, print warning
   MissingPatchTitle=" ${release_update_patchid} - ${release_update_desc}"
   TCCresult="MISSING" 
   MissRlbkFix="${MissingPatchTitle}"
   missingfilename="${release_update_filename}"
   MissingPatchType="Release Update"
   printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
   Check235Rel
   PrintConsolPatchMessage
   PrintMissingPatchWarning
else
 PrintConsolPatchMessage

fi
}
#Added to process DB123ai version 23.5
Check235Rel() {
 if test ${DB_REL} -eq 23; then
    R23ver=`echo $release_update_desc | ${AWK} {'print $4'} |${AWK} -F\. {'print $1,$2'} |sed 's/ //g'` 
    if test ${R23ver} -gt 235 ; then
     PrintMissingPatchMessageFlag="y"
    fi
 fi
} #end of Check235Rel

#Need to check that this works for 11g and 12c
CheckForPatchUpdate() {
if test "${isNewer}" = "false" ; then
 if test "${patch_update_bugid}x" != "x" ; then
   patchupdateapplied=`${OPATCH} lsinventory | grep ${patch_update_bugid} |grep -i database`
   if test "${patchupdateapplied}x" = "x" ; then
     #printf "\nDEBUG: Patch Update is not applied\n"| tee -a $LOGFILE
     PATCH_UPDATE_MISSING="y"
   else
     PATCH_UPDATE_MISSING="n"
   fi
 else
    #Test for serviceRU, no patch_update_bugid 
    if test "${myrealm}" != "oc1" -a "${cloud}" = "y"; then
     CheckServiceRU
    fi
 fi
fi
}

CheckServiceRU() {
#Test for serviceRU, no patch_update_bugid 
if test "${serviceRU}x" != "x" -a "${myrealm}" != "oc1" -a  "${cloud}" = "y"; then
  if test ${DB_REL} -gt 19; then
   nextRU=`grep Technology ${BUG_LIST_FILE} | grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/"//g' | grep ^${DB_REL}\. |sort -nru |${AWK} 'NR==1 {print $0}'|cut -d ">" -f 1 | sed 's/\.//g'`
   latestRU=`grep Technology ${BUG_LIST_FILE} | grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/"//g' | grep ^${DB_REL}\. |sort -nru |${AWK} 'NR==2 {print $0}'|cut -d ">" -f 1 | sed 's/\.//g'`
   oldestRU=`grep Technology ${BUG_LIST_FILE} | grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/"//g' | grep ^${DB_REL}\. |sort -nu |${AWK} 'NR==1 {print $0}'|cut -d ">" -f 1 | sed 's/\.//g'`
  else
   nextRU=`grep Technology ${BUG_LIST_FILE} | grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/"//g' | grep ^${DB_REL}\. |sort -nru |${AWK} 'NR==1 {print $0}'|cut -d "." -f 1,2 | sed 's/\.//g'`
   latestRU=`grep Technology ${BUG_LIST_FILE} | grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/"//g' | grep ^${DB_REL}\. |sort -nru |${AWK} 'NR==2 {print $0}'|cut -d "." -f 1,2 | sed 's/\.//g'`
   oldestRU=`grep Technology ${BUG_LIST_FILE} | grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/"//g' | grep ^${DB_REL}\. |sort -nu |${AWK} 'NR==1 {print $0}'|cut -d "." -f 1,2 | sed 's/\.//g'`
  fi
   passedRU=`echo ${serviceRU} | cut -d "." -f 1,2 | sed 's/\.//g'`
   currentRU=`echo ${DB_VERSION} | cut -d "." -f 1,2 | sed 's/\.//g'`

#check to ensure it is not greater than the newest supported release
#Instance is on the latest RU, do nothing
 if test ${currentRU} = ${passedRU}; then
   if test "${PrintSerivceMessageFlag}" = "notset" ; then
     printf "\n The database RU ${serviceRU} that you specified using the serviceRU parameter is the same\n as the installed database RU.\n" | tee -a $LOGFILE
     PrintSerivceMessageFlag="n"
   fi
 else
   rsltRU=`echo "if ( $currentRU < $passedRU && $passedRU < $nextRU && $oldestRU <= $passedRU ) 1" | tr -d $'\r' | bc`
   # Test for N-   
   if test "${rsltRU}x" = "1x" ; then
     PrintSerivceMessageFlag="y"
     PrintMissingPatchMessageFlag="y"
     PATCH_UPDATE_MISSING="y"

   else
    # Test for N+
    if test ${latestRU} -lt ${currentRU}; then 
      rsltRU=`echo "if ( $passedRU < $currentRU && $passedRU < $nextRU && $oldestRU <= $passedRU) 1" | tr -d $'\r' | bc`

      ##Need to ensure that the passedRU is greater or equal to N+3
      if test "${rsltRU}x" = "1x"; then
        PrintSerivceMessageFlag="y"
        PrintMissingPatchMessageFlag="y"
        PATCH_UPDATE_MISSING="y"
      fi
    fi  #N+
   fi #N-

   if test "${PrintSerivceMessageFlag}" = "notset" ; then
     printf "\n\nThe database RU ${serviceRU} that you specified using the serviceRU parameter is not supported.\nTherefore the results are based on the installed database RU.\n" | tee -a $LOGFILE
     PrintSerivceMessageFlag="n"
   fi
 fi # equal
fi # oc1
} #end of checkserviceru

CheckForReleaseUpdate() {

 if test "${release_update_bugid}x" != "x" ; then
   releaseupdateapplied="`${OPATCH} lsinventory | grep ${release_update_bugid} | grep -i 'Database Release Update'`"
   if test "${releaseupdateapplied}x" = "x" ; then
     #printf "\nDEBUG: Release Update is not applied\n"| tee -a $LOGFILE
     RELEASE_UPDATE_MISSING="y"
   else
     RELEASE_UPDATE_MISSING="n"
   fi
 fi
}

CheckForBundleUpdate() {

if test "${isNewer}" = "false" ; then
 if test "${bundle_update_bugid}x" != "x" ; then
   if test "${relnum}" = "12" ; then
     bundleupdateapplied="`${OPATCH} lspatches | grep -i 'DATABASE BUNDLE PATCH' | grep ${bundle_update_bugid}`"
   else
     bundleupdateapplied="`${OPATCH} lspatches | grep -i 'DATABASE PATCH FOR EXADATA' | grep ${bundle_update_bugid}`"
   fi
   if test "${bundleupdateapplied}x" = "x" ; then
     #printf "\nDEBUG: Bundle Update is not applied\n"| tee -a $LOGFILE
     BUNDLE_UPDATE_MISSING="y"
   else
     BUNDLE_UPDATE_MISSING="n"
   fi
 fi
fi
}

PrintMissingPatchWarning() {

if test "${PrintMissingPatchMessageFlag}" = "y" ; then
  #if test "${automation}" != "y" ; then
    #printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
  #Added check for bundle patch
   if test "${MissingPatchType}" != "bundle patch"; then
     if test ${DB_REL} -gt 12 ; then
      MissingPatchType="Release Update"
     else
      MissingPatchType="patch update"
     fi
   fi
    if test "${cloud}" != "y"; then
        #onprem
        printf "[WARNING]${MissingPatchTitle} is not applied."| tee -a $LOGFILE
        printf "\nThis is the recommended database ${MissingPatchType}. You should install it now"| tee -a $LOGFILE
        printf "\nand then rerun this script to check for any further fixes available." | tee -a $LOGFILE
        printf "\n\n    - Filename: ${missingfilename}" | tee -a $LOGFILE
        printf "\n  "| tee -a $LOGFILE
        if test "${is19RU}" != "true"; then
          printf "\nAlternatively, if you remain on your existing ${MissingPatchType}, you must apply all"| tee -a $LOGFILE  
          printf "\nthe patches listed above from the consolidated zip file, which is only shown"| tee -a $LOGFILE
          printf "\nwhen patches need to be installed."| tee -a $LOGFILE
        fi
    else
      #cloud
     if test "${cloud}" = "y"; then
      if test "${myrealm}" = "oc1"; then
        printf "[WARNING] ${MissingPatchTitle} is not applied."| tee -a $LOGFILE
        printf "\nThis is the recommended database ${MissingPatchType}. You should install it now"| tee -a $LOGFILE
        printf "\nand then rerun this script to check for any further fixes available." | tee -a $LOGFILE
      else
        printf "[WARNING] The database RU ${serviceRU} that you specified using the serviceRU parameter has not"| tee -a $LOGFILE
        printf "\nyet been applied. Apply this RU by following the instructions in My Oracle Support article ${mosID} and"| tee -a $LOGFILE
        printf "\nthen rerun checkDBpatch.sh to check for any further recommended patches." | tee -a $LOGFILE
      fi

      if test ${DB_REL} -le 12 ; then
       printf "\n\n[IMPORTANT] You must use the command line interface (CLI) to install this patch." | tee -a $LOGFILE
       printf "\nRefer to My Oracle Support article ${mosID} for detailed instructions." | tee -a $LOGFILE
      else
       printf "\n\n[IMPORTANT] You must use the command line interface (CLI) or the Oracle Cloud" | tee -a $LOGFILE
       printf "\nInfrastructure Console to install this patch." | tee -a $LOGFILE
       printf "\nRefer to My Oracle Support article ${mosID} for detailed instructions." | tee -a $LOGFILE
      fi
     fi
    fi
    printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
  #fi
fi
}

PrintConsolPatchMessage() {
if test "${PrintConsolPatchMessageFlag}" != "n" -a "${isPrinted}" != "y" ; then
  # Do not print Consolidated Zip availabilty if we do not have a Consolidated Patch ID or if number of missing patches if less than 2
  # Update: if the only missing patch is regressed, we need to display consolidated zip message, so undoing this restriction
  missingpatchcount=`cat ${PATCHCOUNTER}`
  #printf "\n DEBUG: Number of missing patches : ${missingpatchcount}\n" | tee -a $LOGFILE
  if test "${consolpatchid}x" != "x" ; then
    printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
    printf "\nA consolidated zip file with the required patches for database release"| tee -a $LOGFILE
    printf "\n${patchrelease} is available on My Oracle Support via:\n" | tee -a $LOGFILE
    printf "\n  Patch ${consolpatchid} " | tee -a $LOGFILE
    printf "\n    - ${consolpatchdesc}\n" | tee -a $LOGFILE
    printf "\nNote: This zip does not include Release Updates, Bundle Patches or Patch Set Updates.\n" | tee -a $LOGFILE    
    if test "${cloud}" = "y" ; then
      printf "\nOnce this zip is downloaded and extracted, the above patches can be found under\nthe ${mapvers} directory.\n" | tee -a $LOGFILE
    fi
    printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
  fi
fi
isPrinted="y"
}

PrintCloudConsolPatchMessage() {
if test "${PrintCloudConsolPatchMessageFlag}" != "n" ; then   
    printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
    printf "\nA consolidated zip file with the required patches for Oracle"| tee -a $LOGFILE
    printf "\n${cloudServiceTitle} is available on\n" | tee -a $LOGFILE
    printf "\nMy Oracle Support via:\n" | tee -a $LOGFILE
    printf "\nPatch ${consolpatchid}" | tee -a $LOGFILE
    printf "\n  - ${consolpatchdesc}\n" | tee -a $LOGFILE
    printf "\nNote: This zip does not include any database bundle patches or Patch Set Updates." | tee -a $LOGFILE    
    printf "\n\nOnce this zip is downloaded and extracted, the above patches can be found under" | tee -a $LOGFILE
    printf "\nthe directory:\n ./etcc-bundle/Cloud/${cloudtag}/${PLAT}/database/${mapvers}/ \n" | tee -a $LOGFILE  
    printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
fi
}

ListSQLPatches () {

    splist="${PTCH_TMP}/spatch_$$.lst"
    touch ${splist}
    touch ${splist}1

    printf "\n-----------------------------------------------------------------------------------------"| tee -a $LOGFILE
    printf "\nPATCH INFORMATION FOR ORACLE DATABASE ${DB_VERSION}"| tee -a $LOGFILE
    printf "\n-----------------------------------------------------------------------------------------"| tee -a $LOGFILE
    printf "\nThere are patches applied to this database ORACLE_HOME that include SQL files:" | tee -a $LOGFILE

    #remove all blank spaces and empty lines
    sed '/^$/d' ${oplist} > ${oplist}1 
    sort ${oplist}1  | uniq > ${oplist}
    for line in `cat ${oplist}`
    do
       patchnum=`echo ${line} | sed -n 's:.*ORACLE_HOME\/sqlpatch\/\(.*\)\/.*:\1:p' | cut -d"/" -f1`
       if test "${patchnum}x" != "x" ; then
          printf "\n${patchnum}" >> ${splist}1 
       fi
    done

    sort ${splist}1 | uniq > ${splist}

    for line in `cat ${splist}`
    do
      patchnum=`echo ${line}`
      if test "${patchnum}x" != "x" ; then
         sqldetails=`cat ${oplist} | grep ${patchnum}`
         printf "\n\nPatch ${patchnum}:\n---------------\n${sqldetails}" | tee -a $LOGFILE
      fi
    done
    printf "\n" | tee -a $LOGFILE
    exit_code="ETCC-0000"
    exit_script
}

printUsage() {
      printf "\n\nUsage: \n" | tee -a $LOGFILE
      printf " checkDBpatch.sh [help] contextfile=<file> [cloud=y service=<service>]\n\n" | tee -a $LOGFILE
      printf "Valid arguments for checkDBpatch.sh:\n\n"  | tee -a $LOGFILE
      printf " help              : get usage information\n"  | tee -a $LOGFILE
      printf " contextfile       : provide database context file name\n"  | tee -a $LOGFILE
      printf " cloud=y           : for use by Oracle Cloud Infrastructure (OCI & Classic)\n"  | tee -a $LOGFILE
      printCloudUsage       
      #printf "\tbaremetal=[y/n]  : for use by Oracle Cloud Infrastructure \n";
      exit_code="ETCC-0000"
      exit_script
}

printCloudUsage(){
      printf "\n Oracle Cloud Infrastructure [cloud=y] has an additional manual parameter:\n\n"  | tee -a $LOGFILE
      printf "     Note: If you are running on an Oracle Exadata Database Service on Cloud@Customer, ETCC requires the\n"| tee -a $LOGFILE
      printf "     additional parameter service=exacc.\n\n"| tee -a $LOGFILE
      printf "      service=[exacc]   : Oracle Exadata Database Service on Cloud@Customer in an Oracle cloud\n\n" | tee -a $LOGFILE
}

AutomationMode(){

       # printf "\n[ERROR]" |tee -a $LOGFILE
      printf "\nIdentifying Oracle Cloud service."|tee -a $LOGFILE
      automation="y"
      
      # Try to identify service
      checkPlatformInfo
}
notcurrentlysupported(){
 TCCresult="MISSING"
 if test "${contextfile}" != "none" -a "${updatedb}" != "y" ; then
   updateResInDB
 fi
 if test "${cloud}" = "y"; then
    printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
    printf "   [WARNING] ETCC does not recommend fixes for Oracle Database version\n" |tee -a $LOGFILE
    printf "   ${cloudvers}. For more information, refer to My Oracle Support article ${mosID}." | tee -a $LOGFILE
    printf "\n+---------------------------------------------------------------------------------------+\n\n"| tee -a $LOGFILE
    if test "${myrealm}" != "oc1" ; then
       CheckServiceRU
        if test "${PATCH_UPDATE_MISSING}" = "y" -a "${serviceRU}x" != "x"; then
         PrintMissingPatchWarning
        fi
    fi
 fi
      exit_script
}

exit_script() {

unset PLATFORM
unset PLATFORM_LOWER
unset CMDDIR

# clean up of temp files
rm -rf ${LOCAL_TEMP}
printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
getErrorMsg
if test "${exit_code}" != "ETCC-0000"; then
 printf "\n+---------------------------------------------------------------------------------------+\n"| tee -a $LOGFILE
fi
printf "\nFinished checking fixes for ${hometype} ${dbname}: " | tee -a $LOGFILE
date | tee -a $LOGFILE
printf "\nLog file for this session:\n ${LOGFILE}\n" | tee -a $LOGFILE
printf "This file should be reviewed for errors after the ETCC run.\n" | tee -a $LOGFILE
printf "\n=========================================================================================\n" | tee -a $LOGFILE
#printf "\n DEBUG: isPatchMap = ${isPatchMap}\n" | tee -a $LOGFILE
exit
}

#Added to group error messages
getErrorMsg() {

case $exit_code in
"ETCC-0000")
 #printf "\nDEBUG: Exiting without issue\n" >> $LOGFILE
;; 
"ETCC-0020")
 printf " Unable to validate fixes for ${cloudvers} using\n ${XML_FILE_NAME}.\n\n Download latest patch 17537119 and rerun ETCC.\n"
;; 
"ETCC-0022")
 printf " There are currently no recommended one-off bugfixes for\n Oracle Grid Infrastructure.\n" | tee -a $LOGFILE
;; 
"ETCC-0030")
 printf " The 'oracle' binary could not be found in ${ORACLE_HOME}.\n" | tee -a $LOGFILE
 printf " Provide the correct \$ORACLE_HOME location.\n" | tee -a $LOGFILE
;; 
"ETCC-0031")
 printf " The directory ${ORACLE_HOME} does not exist. \n" | tee -a $LOGFILE
;; 
"ETCC-0032")
 printf " ${BUG_LIST_FILE} does not exist. \n Extract it from the" | tee -a $LOGFILE
 printf " patch zip file to this script execution\n directory and then rerun DB-ETCC.\n" | tee -a $LOGFILE
;; 
"ETCC-0033")
 printf " Unable to read the value of s_db_oh from the context file.\n" | tee -a $LOGFILE
 printf " Verify location and rerun DB-ETCC.\n" | tee -a $LOGFILE
;; 
"ETCC-0035")
 printf " Unable to locate context file $contextfile.\n" | tee -a $LOGFILE
 printf " Verify location and then rerun DB-ETCC.\n" | tee -a $LOGFILE
;; 
"ETCC-0044")
 printf " Could not get list of bugfixes from\n" | tee -a $LOGFILE
 printf " ${BUG_LIST_FILE} for ${hometype} version ${DB_VERSION}.\n" | tee -a $LOGFILE
;; 
"ETCC-0045")
 printf " Could not get list of bugfixes from\n" | tee -a $LOGFILE
 printf " ${BUG_LIST_FILE} for version ${listvers}.\n" | tee -a $LOGFILE 
;;
"ETCC-0052")
 printf " Could not find OPatch utility in database ORACLE_HOME. \n Cannot confirm bugfixes applied.\n"| tee -a $LOGFILE
;; 
"ETCC-0057")
 printf " Error running OPatch. Error code: ${opatch_code}\n"| tee -a $LOGFILE
 printf " Cannot confirm bugfixes applied to the ${hometype} ORACLE_HOME.\n"| tee -a $LOGFILE
;; 
"ETCC-0059")
 printf " Error reading OPatch utility output.\n" | tee -a $LOGFILE
;; 
"ETCC-0088")
 printf " Pluggable database is not open.\n" | tee -a $LOGFILE
;; 
"ETCC-0097")
 printf " Unable to create temp directory $LOCAL_TEMP.\n" | tee -a $LOGFILE
;; 
"ETCC-0099")
 printf " [ERROR] Unable to identify Oracle Cloud service automatically.\n" | tee -a $LOGFILE
 printf "   Usage: \n" | tee -a $LOGFILE
 printf "     checkDBpatch.sh [help] contextfile=<file> [cloud=y service=<service>]\n" | tee -a $LOGFILE
 printCloudUsage
 printf " Rerun DB-ETCC, specify the service manually using [cloud=y service=<service>]\n" | tee -a $LOGFILE
;; 
"ETCC-0100")
 printf "\n Could not find curl on this instance, please check PATH or install curl and rerun\n" | tee -a $LOGFILE
;;
"ETCC-0120")
 printf "\n Not an ETCC supported database version, 11i, 12c, 19c, 23c \n" | tee -a $LOGFILE
;;
*)
 printf " Unknown Error \n" | tee -a $LOGFILE
;;
esac
#printf "\n[DEBUG]: Exit code = ${exit_code}\n"

} #End of getErrorMsg

checkRelease(){
cver=`echo ${tsvers} | sed 's/\.//g'`
 bRel=`grep Technology ${BUG_LIST_FILE} |grep version |${AWK} '{print $3}' | sed 's/version=["]//g; s/">//g; s/[_A-Z*$]//g' | grep "^${DB_REL}\." |sed 's/\.//g' | sort -nru |${AWK} 'NR==1 {print $0}'`
if test ${cver} -le ${bRel} ; then
  isNewer="false"
else
  isNewer="true"
fi
export isNewer
}

GetN1Release(){
if test ${DB_REL} -gt 19; then
  grep RU ${BUG_LIST_FILE} | sed 's/^.*version=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g' | cut -d "_" -f 1 | grep ^${DB_REL} | sort -t. -k 1,1nr -k 2,2nr  -k 3,3nr > ${LOCAL_TEMP}/DBRU_List.out
 else
  grep RU ${BUG_LIST_FILE} | sed 's/^.*version=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g' | cut -d "." -f 1,2 | grep ^${DB_REL} | sort -t. -k 1,1nr -k 2,2nr > ${LOCAL_TEMP}/DBRU_List.out
fi
if test -s ${LOCAL_TEMP}/DBRU_List.out; then
  cnt=1
  while read dbrel; do
     if [ $cnt -eq 1 ]; then
     n_rel=`echo $dbrel| sed 's/\.//g'`
     export n_rel
    elif [ $cnt -eq 2 ]; then
     n1_rel=`echo $dbrel | sed 's/\.//g'`
     export n1_rel
    fi
    if test "${PLATFORM}" != "Solaris" ; then   #bug 31381759 
       cnt=`echo $(($cnt + 1))`
    else
       cnt=`expr $cnt + 1`
    fi

  done < ${LOCAL_TEMP}/DBRU_List.out 

testnull=`echo ${n1_rel}`
if test "${testnull}x" =  "x"; then
     n1_rel=${n_rel}
fi
if test ${DB_REL} -eq 19 ; then
  curVersion=`echo ${tsvers} | cut -d "." -f 1,2 | sed 's/\.//g'`
else
  curVersion=`echo ${tsvers} | cut -d "." -f 1,2,3 | sed 's/\.//g'`
fi

    result=`echo "if ( $curVersion < $n1_rel) 1" | bc`
    if test "${result}x" = "1x" ; then
     is19RU="true"
    else
     is19RU="false";
    fi
else
  is19RU="false"
fi
export is19RU 
# For Debug only DBRU_List.out 
# if test -f ${LOCAL_TEMP}/DBRU_List.out; then
#   cp ${LOCAL_TEMP}/DBRU_List.out ${pwdir}/log
# fi
}

askRAC() {
# Check for RAC
 if test "${contextfile}" != "none" ; then
   racornot=`grep "s_dbCluster\"" ${contextfile} | sed 's/^.*s_dbCluster[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
   if test "${racornot}" = "true" -o "${racornot}" = "TRUE"; then
     isRacEnv="y"
   else
     isRacEnv="n"
   fi
 else
   while true; do
      printf "\nIs this an Oracle RAC environment [y/n]: "
      read yn
      case $yn in
          [Yy] ) isRacEnv="y"; break;;
          [Nn] ) isRacEnv="n"; break;;
          * ) echo "Answer Y or N.";;
      esac
    done
 fi
}

#Get the patchid for the consoldated zips
getConsolidatezip() {
dbv=""
if test "${cloud}" = "y" -a "${GridHome}" != "y" ; then
 if test "srvcsupport" != "n"; then
   case ${DB_REL} in 
      "11")
        dbv="11g"
       ;;
      "12")
        dbv="12c"
       ;;
      "19")
        dbv="19c"
       ;;
      "23")
        dbv="23ai"
       ;;
      *)
       #Not a ETCC supported DB version 
       #printf "\nDEBUG DB_REL = ${DB_REL}\n"
       exit_code="ETCC-0120"
       exit_script
      ;;
  esac

  consolpatchid=`${AWK} -F'[<|>]' '/consolidated_cloud_patch/{c=$2}/database/{d=$2}/patch_id/{pi=$3}/notes/{n=$3; printf "%s:%s:%s\n",d,pi,n}' ${MAP_LIST_FILE} | grep CONSOLIDATED | grep $dbv | ${AWK} -F: '{print $2}'`
  consolpatchdesc=`${AWK} -F'[<|>]' '/consolidated_cloud_patch/{c=$2}/database/{d=$2}/patch_id/{pi=$3}/notes/{n=$3; printf "%s:%s:%s\n",d,pi,n}' ${MAP_LIST_FILE} | grep CONSOLIDATED | grep $dbv | ${AWK} -F: '{print $3}'`

 else
        #this only for dbcs, dbcsrac, and exacs
        consolpatchid=`grep consolidated_patch ${MAP_LIST_FILE} | sed 's/^.*id=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g'`
        consolpatchdesc=`grep consolidated_patch ${MAP_LIST_FILE} | sed 's/^.*name=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g'`
 fi

else
  #this is for on-prem processing
 if test ${DB_REL} -gt 12 ; then
    dbv=${DB_REL}
 else
    dbv=$DB_VERSION
 fi

  if test "${cloud}" != "y" ; then
    consolpatchid=`${AWK} -F'[<|>]' '/consolidated_patch/{c=$2}/database/{d=$2}/platform/{p=$2}/patch_id/{pi=$3}/notes/{n=$3; printf "%s:%s:%s:%s\n",d,p,pi,n}' ${MAP_LIST_FILE} |grep ${PLAT} | grep CONSOLIDATED | grep $dbv |${AWK} -F: 'NR==1 { print $3}'`
    consolpatchdesc=`${AWK} -F'[<|>]' '/consolidated_patch/{c=$2}/database/{d=$2}/platform/{p=$2}/patch_id/{pi=$3}/notes/{n=$3; printf "%s:%s:%s:%s\n",d,p,pi,n}' ${MAP_LIST_FILE} |grep ${PLAT} | grep CONSOLIDATED | grep $dbv |${AWK} -F: 'NR==1 { print $4}'`
  fi
fi

} #end of getConsolidatezip

# begin Main here

prgdir=`dirname $0`
CMDDIR=${prgdir}
export CMDDIR
pwdir=`pwd`
isRacEnv="notset"
PrintMissingPatchMessageFlag="notset"
PrintConsolPatchMessageFlag="notset"
PrintSerivceMessageFlag="notset"
missingfilename="notset"
srvcsupport="y"
isPrinted="n"
isPatchMap="y"
patchcount=0
execdate=`date '+%d-%m-%Y %H:%M:%S'`
TCCresult="MISSING"
TECHNAME="DB_HOME"
obsolete="n"
DSTversion=0
MissRlbkFix=""   # missing fix or fix to be rolled back
updatedb="n"  #update db should only be called once
exit_code="ETCC-0000"
opatch_code="0" 
sqlstmt_code="0"
relnum=""
realmdm="com"
myrealm=""
n_rel=""
relchg=0
exascale="n"
#ER 17588765
prog=`basename $0`
if test ! -d ${pwdir}/log ; then
     mkdir -p ${pwdir}/log
fi

LOGFILE="${pwdir}/log/checkDBpatch_$$.log"
printf "\n +===============================================================+ " | tee -a $LOGFILE
printf "\n |    Copyright (c) 2005, 2026 Oracle and/or its affiliates.     | " | tee -a $LOGFILE
printf "\n |                     All rights reserved.                      | " | tee -a $LOGFILE
printf "\n |             Oracle E-Business Suite Release 12.2              | " | tee -a $LOGFILE
printf "\n |          Database EBS Technology Codelevel Checker            | " | tee -a $LOGFILE
printf "\n +===============================================================+ \n" | tee -a $LOGFILE

LOCAL_TEMP=$CMDDIR/temp_checkDBpatch_$$
  
  if test ! -d "$LOCAL_TEMP" ; then
     mkdir -p $LOCAL_TEMP
     dir_code=$?

     if test "$dir_code" != "0" ; then
     #Unable to create temp directory
         exit_code="ETCC-0097"
         exit_script
     fi
  fi

UNAME=`uname -s`
case $UNAME in
  "HP-UX")  OSTYPE=`uname -m`
            if [ $OSTYPE = "ia64" ] ; then
              PLATFORM=HP_IA
            else
              PLATFORM=HP_UX
            fi
            ;;
  "AIX")    PLATFORM=IBM_AIX
            PLATFORM_LOWER=aix
	    ;;
  "OSF1")   PLATFORM=UNIX_Alpha
            PLATFORM_LOWER=decunix
	    ;;
  "SunOS")  OSTYPE=`uname -m`
	    if [ $OSTYPE = "sun4u" ] ; then
  	      PLATFORM=Solaris
              PLATFORM_LOWER=solaris
            elif [ $OSTYPE = "sun4us" ] ; then 
                  PLATFORM=Solaris 
                  PLATFORM_LOWER=solaris
	    elif [ $OSTYPE = "i86pc" ] ; then
		  PLATFORM=Solaris_x86-64
	  	  PLATFORM_LOWER=solaris_x86-64
	    fi
            PTYPE=`uname -p`
	    if [ $PTYPE = "sparc" ] ; then
	      PLATFORM=Solaris
              PLATFORM_LOWER=solaris
	    fi
	    unset PTYPE
	    unset OSTYPE
	    ;;
  "Linux")  OSTYPE=`uname -m` 
            if [ $OSTYPE = "x86_64" ] ; then
              PLATFORM=Linux_x64
              PLATFORM_LOWER=linux_x64
            elif [ $OSTYPE = "s390x" ] ; then
              PLATFORM=LINUX_ZSER
              PLATFORM_LOWER=linux_zser
            else 
              PLATFORM=Linux
              PLATFORM_LOWER=linux
            fi
            unset OSTYPE
esac
unset UNAME

UNZIP=$CMDDIR/unzip/$PLATFORM/unzip

case $PLATFORM in
  "HP_UX")         if [ x${PATH} != x ] ; then
                     PATH=/usr/bin:${PATH}
                   else
                     PATH=/usr/bin
                   fi
                   export PATH
                   ORATAB_PATH=/etc
		   PLAT="HP_UX_IA64"
            	   AWK="awk"
                   ;;
  "HP_IA")         if [ x${PATH} != x ] ; then
                     PATH=/usr/bin:${PATH}
                   else
                     PATH=/usr/bin
                   fi
                   export PATH 
		   PLAT="HP_UX_IA64"
	           AWK="awk"
		   ;;
  "IBM_AIX")       if [ x${PATH} != x ] ; then
                     PATH=/usr/bin:${PATH}
                   else
                     PATH=/usr/bin
                   fi
                   export PATH
                   ORATAB_PATH=/etc
	           PLAT="IBM_AIX"
		   AWK="awk"
		   ;;
  "UNIX_Alpha")    if [ x${PATH} != x ] ; then
                     PATH=/usr/ccs/bin:${PATH}
                   else
                     PATH=/usr/bin:/usr/ccs/bin
                   fi
                   export PATH
                   ORATAB_PATH=/etc
                   ;;
  "Solaris")       if [ x${PATH} != x ] ; then
                     PATH=/usr/ccs/bin:${PATH}
                   else
                     PATH=/usr/bin:/usr/ccs/bin
                   fi
                   export PATH
                   ORATAB_PATH=/var/opt/oracle
		   PLAT="Solaris_sparc"
                   AWK="nawk"
                   ;;
  "Solaris_x86-64") if [ x${PATH} != x ] ; then
                     PATH=/usr/ccs/bin:${PATH}
                   else
                     PATH=/usr/bin:/usr/ccs/bin
                   fi
                   export PATH
                   ORATAB_PATH=/var/opt/oracle
                   PLAT="Solaris_x86-64"
                   AWK="nawk"
                   ;;

  "Linux")         if [ x${PATH} != x ] ; then
                     PATH=/usr/bin:/bin:${PATH}
                   else
                     PATH=/usr/bin:/bin
                   fi
                   export PATH
                   ORATAB_PATH=/etc
		   PLAT="Linux_32bit"
	           AWK="awk"
                   ;;
  "Linux_x64")    if [ x${PATH} != x ] ; then
                     PATH=/usr/bin:/bin:${PATH}
                   else
                     PATH=/usr/bin:/bin
                   fi
                   export PATH
                   ORATAB_PATH=/etc
		   PLAT="LINUX_X86-64"
	           AWK="awk"
                   ;;
  "LINUX_ZSER")   if [ x${PATH} != x ] ; then
                      PATH=/usr/bin:/bin:${PATH}
                    else
                      PATH=/usr/bin:/bin
                    fi
                    ORATAB_PATH=/etc
		    AWK="awk"
		    PLAT="LINUX_ZSER"

esac

#Set PATH for uzip executable
PATH=$PATH:$CMDDIR/unzip/$PLATFORM
export PATH

ctxfilesource="currently set database environment:"
contextfile="${CONTEXT_FILE}"
listdiffs="n"
hometype="database"
input_arg=$*
printf "\n+---------------------------------------------------------------------------------------+\n" >> $LOGFILE
printf "Input parameters used: ${prog} ${input_arg}\n" >> $LOGFILE
printf "+---------------------------------------------------------------------------------------+\n\n" >> $LOGFILE


for myarg in $*
do
    arg=`echo $myarg| sed 's/^-//'`
    case $arg in
        contextfile=*)
                contextfile=`echo $arg | sed 's/contextfile=//g'`
                shift
                ;;               
        cloud=*)
                cloud=`echo $arg | sed 's/cloud=//g'`
                shift
                ;;                  
        baremetal=*)
                isBMCS=`echo $arg | sed 's/baremetal=//g'`
                shift
                ;;  
        serviceRU=*)
                serviceRU=`echo $arg | sed 's/serviceRU=//g' |cut -d "." -f 1,2`
                shift
                ;;  
        service=*)
                ServiceParam=`echo $arg | sed 's/service=//g'`
                cloudService=`echo "$ServiceParam" | tr '[A-Z]' '[a-z]'`
                cloud="y"
                if test "${cloudService}" = "dbsi" -o "${cloudService}" = "entdbvg"; then
                  isRacEnv="n"
                fi
                shift
                ;;                                           
        listdiffs)
                listdiffs="y"
                ;;                 
        listsqlpatches)
                listdiffs="n"
                sqlpatchesonly="y"
                isPatchMap="n"
                ;;
        help)
                printUsage
                ;;                               
    esac
    CONTEXT_FILE=$contextfile
    export CONTEXT_FILE
    ctxfilesource="command line argument:"
done

if test "${contextfile}x" = "x" ; then
  printf "\nDatabase environment not set, going to check for GridHome.\n" | tee -a $LOGFILE
  checkGrid
  if test "${GridHome}" != "y" ; then
    printf "\nDatabase environment not set and no Grid home found, so context file must be specified.\n" | tee -a $LOGFILE
    printf "Enter full path to database context file: "
    read contextfile
    CONTEXT_FILE=$contextfile
    export CONTEXT_FILE
    ctxfilesource="user input:"
  fi
fi

if test "${contextfile}" != "none" ; then

  if [ ! -f $contextfile ]; then
    #Unable to locate context file $contextfile.
    exit_code="ETCC-0035"
    exit_script
  else
    checkContext
    printf "\nUsing context file from $ctxfilesource" | tee -a $LOGFILE
    printf "\n${CONTEXT_FILE}" | tee -a $LOGFILE
  fi
else
  if test "${GridHome}" != "y" ; then
     printf "\nUser requested processing without reference to context file." | tee -a $LOGFILE
  fi
  printf "\nWith this option, results will not be stored in the database." | tee -a $LOGFILE

fi

if test "${isBMCS}" = "y" ; then
  cloud="y"
fi

progver=`grep Header ${prgdir}/${prog} | grep ${prog} |  ${AWK} '{ print $4 }'`
printf "\n\nStarting Database EBS Technology Codelevel Checker, Version ${progver} \n" |tee -a $LOGFILE
date | tee -a $LOGFILE

printf "Log file for this session:\n ${LOGFILE}\n" | tee -a $LOGFILE


if test "${contextfile}" != "none" ; then
    ORACLE_HOME=`grep s_db_oh ${contextfile} | sed 's/^.*s_db_oh[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
fi

if test "${ORACLE_HOME}x" = "x" ; then
    printf "\nCannot determine ORACLE_HOME from database environment."  | tee -a $LOGFILE
    printf "\nEnter the ORACLE_HOME: "
    read ORACLE_HOME
fi


if test ! -d "$ORACLE_HOME" ; then
   #The directory ${ORACLE_HOME} does not exist.
   exit_code="ETCC-0031"
   exit_script
fi

if test "${contextfile}" != "none" ; then
    racornot=`grep "s_dbCluster\"" ${contextfile} | sed 's/^.*s_dbCluster[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
    perlprg=`grep "s_adperlprg\"" ${contextfile} | sed 's/^.*s_adperlprg[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
    export perlprg

    perlpath=`grep "s_perl5lib\"" ${contextfile} | sed 's/^.*s_perl5lib[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`

    PERL5LIB=$perlpath
    export PERL5LIB
else
    perlprg=${ORACLE_HOME}/perl/bin/perl
fi

if test "${GridHome}" != "y" ; then
  # Get DB version
  printf "\nIdentifying database release. " | tee -a $LOGFILE
  if test -f "${ORACLE_HOME}/bin/oracle" ; then
   dbver=`strings -a ${ORACLE_HOME}/bin/oracle | grep ^NLSRTL | ${AWK} '!f{ print $3; f=1 }'`
   if test "${dbver}x" = "x" ; then
       dbver=`strings -a ${ORACLE_HOME}/bin/oracle | grep NLSRTL | ${AWK} '!f{ print $3; f=1 }'`
   fi
   DB_REL=`echo ${dbver} | cut -d"." -f1`
      # if 18c or higher then we can use oraversion
      if test ${DB_REL} -gt 12 ; then
       dbverfull=`${ORACLE_HOME}/bin/oraversion -compositeVersion`
       if test ${DB_REL} -gt 19 ; then
         relchg=`echo ${dbverfull} | cut -d"." -f1,2 | sed 's/\.//g'`
         if test ${relchg} -gt 2325  ; then
           DB_VERSION=`echo ${dbverfull} | cut -d"." -f1,2,3`
         else
           DB_VERSION=`echo ${dbverfull} | cut -d"." -f1,2`
         fi 
        else
          # Where DB release_full contains RUR version, we need to replace 3rd and 4th digits with 0 in order to share the base_bugs
          DB_VERSION=`echo ${dbverfull} | ${AWK} -F\. '{
            if ($3 >= 1) t="0";
              else t=$3;
            if ($4 >= 1) f="0";
              else f=$4;
            printf "%s.%s.%s.%s",$1,$2,t,f }'`
        fi
        tsvers=$DB_VERSION
        mapvers=${DB_VERSION}
        listvers=${DB_VERSION}
      else
        #for 11g and 12c
        DB_VERSION=`echo ${dbver} | ${AWK} -F\. '{
        if ($3 == "") t="0";
                    else t=$3;
        if ($4 == "") f="0";
                    else f=$4;
        printf "%s.%s.%s.%s",$1,$2,t,f }'`
        tsvers=$DB_VERSION
        mapvers=${DB_VERSION}
        listvers=${DB_VERSION}
      fi        
      #Set release number for 12c/11g
      relnum="`echo ${tsvers} | ${AWK} -F\. {'print $1'}`"
      printf "\nDatabase release set to ${DB_VERSION}.\n" | tee -a $LOGFILE

      # Patch Mappings
      rm -f ${LOCAL_TEMP}/${TECHNAME}.ecs
      # End Patch Mappings
  else
      #The 'oracle' binary could not be found in ORACLE_HOME.
      exit_code="ETCC-0030"
      exit_script
  fi
fi

if test "${cloud}" = "y" ; then
    #Get realm and domain
    CheckRealmDomain
    CheckRealm
 
    #Check Service Type 
    CheckType

    # Try to identify Cloud service and platform    
    if test "${cloudService}x" = "x" ; then
      AutomationMode
    else
      MatchCloudXMLtags       
    fi
else
  # Check for Exadata / Engineered Systems
   checkExaData
fi

#Check for RAC
if test "${racornot}x" = "x" -a "${isRacEnv}" = "notset"; then
   askRAC
fi
if test "${racornot}" = "true" -o "${racornot}" = "TRUE" -o "${isRacEnv}" = "y"; then
    isRacEnv="y";
    printf "\nNOTE: This is an Oracle Real Application Cluster (RAC) database." | tee -a $LOGFILE
    printf "\n   - Run this tool on all RAC nodes. \n"  | tee -a $LOGFILE
else
    isRacEnv="n";
fi
unset JAVA_HOME

altersession=""

if test "${contextfile}" != "none" ; then
      isMultiTenant=`grep s_pluggable_database ${contextfile} | sed 's/^.*s_pluggable_database[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
      isMultiTenant=`echo "${isMultiTenant}" | tr '[A-Z]' '[a-z]'`
fi

# Set MultiTenant to true
if test "${GridHome}" != "y" ; then
  if test "${cloud}" = "y" -a ${DB_REL} -ge 12 ; then
    isMultiTenant="true"
  else
    if test "${contextfile}" = "none" -a ${DB_REL} -gt 12 ; then
      while true; do
        printf "\nIs this a Multitenant environment [y/n]: " 
        read yn
        case $yn in
          [Yy] ) isMultiTenant="true"; break;;
          [Nn] ) isMultiTenant="false"; break;;
          * ) echo "Answer Y or N.";;
        esac
      done
    fi
  fi
fi #end of grid check


if test "${isMultiTenant}" = "true" ; then
  printf "\nMultitenant identified.\n"  | tee -a $LOGFILE

  # Retrieve values from ctx file
  if test "${contextfile}" != "none" ; then
    oracle_cdb=`grep s_cdb_name ${contextfile} | sed 's/^.*s_cdb_name[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`    
    oracle_pdb=`grep s_pdb_name ${contextfile} | sed 's/^.*s_pdb_name[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
  fi
 
  # Prompt for value if not set
  if test "${oracle_cdb}x" = "x" ; then
    #printf "\nCannot identify name of container database (CDB)."
    printf " - Enter the name of the container database (CDB): "
    read oracle_cdb
  else
    printf " - Container database (CDB) identified via s_cdb_name is ${oracle_cdb}\n" | tee -a $LOGFILE
  fi 

  # Prompt for value if not set
  if test "${oracle_pdb}x" = "x" ; then
    #printf "\nCannot identify name of pluggable database (PDB)."
      printf " - Enter the name of the pluggable database (PDB): "
      read oracle_pdb
  else
    printf " - Pluggable database (PDB) identified via s_pdb_name is ${oracle_pdb}\n" | tee -a $LOGFILE
  fi
  
  if test "${isRacEnv}" = "n" ; then
      ORACLE_SID=${oracle_cdb}
  fi
  altersession="alter session set container = \"${oracle_pdb}\";"
   
fi #end of isMulitenant

if test "${contextfile}" != "none" ; then
    ORACLE_SID=`grep s_instName ${contextfile} | sed 's/^.*s_instName[^>.]*>[ ]*\([^<]*\)<.*/\1/g; s/ *$//g'`
else
  if test "${isRacEnv}" = "y" ; then
      #printf "\n[DEBUG] This is a Real Applications Clusters environment.\n"  | tee -a $LOGFILE
      if test "${isMultiTenant}" = "true" ; then
         printf "\nDB-ETCC must establish a connection to the container database."  | tee -a $LOGFILE
         printf "\n - Enter ORACLE_SID of the RAC CDB Instance [eg: ${oracle_cdb}1]: "  | tee -a $LOGFILE
         read ORACLE_SID
      else
         printf "\n - Enter ORACLE_SID of this RAC Instance [eg: PROD1]: "
         read ORACLE_SID
      fi
  else
    if test "${GridHome}" != "y" ; then
      if test "${ORACLE_SID}x" = "x" ; then
        printf "\nCannot determine ORACLE_SID from database environment.\n"  | tee -a $LOGFILE
        printf " - Enter the ORACLE_SID: "
        read ORACLE_SID
      fi
    fi
  fi
fi #end of contextfile check

bpheader="BUNDLE PATCH"
if test "${cloud}" != "y" ; then
     mosID="KA989"
fi
mosnote="** Refer to My Oracle Support article ${mosID} to find the corresponding patch that delivers the bugfix.\n** If an overlay patch is needed for any particular patch listed, the footnote for\n** that patch also applies to the overlay patch."
#DB up-down flag
dbup=1  # assuming DB is up
if test "${GridHome}" != "y" ; then
  checkDB
  isDBIM=""
  DBmode="1" # read write 
else
  dbup=0
fi

if [ $dbup != 0 ] ; then
    etcctable=0
    checkRAC
    checkDBmode
    if test "${contextfile}" != "none" ; then
      # Bug 21073382
      identifyAPPS
      checkForEtccTable
    fi
    
    if test "${DB_REL}" = "12" ; then
       checkInMemory
    fi
else
    if test "${GridHome}" != "y" ; then
       printf "\n"
       printDBdownWarning
    fi
fi

if test "${cloud}" != "y" ; then
  BUG_LIST_FILE="${CMDDIR}/db/onprem/txk_R1220_DB_base_bugs.xml"
  MAP_LIST_FILE="${CMDDIR}/db/onprem/txk_R1220_DB_mappings.xml" 
  if test "${GridHome}" = "y" ; then
    BUG_LIST_FILE="${CMDDIR}/db/onprem/txk_R1220_GRID_base_bugs.xml"
    MAP_LIST_FILE="${CMDDIR}/db/onprem/txk_R1220_GRID_mappings.xml" 
  fi 
else # Cloud 
   if test "${cloudService}" = "dbcs" -a "${isRacEnv}" = "y" ; then
      cloudtag="DBCS_RAC"
   fi
   if test "${cloudService}" = "dbsi" -a "${isRacEnv}" = "y" ; then
       cloudServiceTitle="Base Database Service 2-Node DB System in an Oracle cloud"
       if test "${realmdm}" != "gov" ; then
         cloudService="vmdbrac"
         cloudtag="VMDB_RAC"
         case ${DB_REL} in
              "11" )
                mosID="KB864317"
              ;;
              "12" )
                mosID="KB864309"
              ;;
              "19" )
                mosID="KA1225"

              ;;
              "23" )
                mosID="KA1152"
              ;;
           esac
       else
         cloudService="entdbvracg"
         cloudtag="VMDB_RAC"
         mosID="KA1225"
       fi 
       cloudinfrastructure="oci"
       printf "\nRunning on an Oracle ${cloudServiceTitle}.\n" | tee -a $LOGFILE
   fi

   BUG_LIST_FILE="${CMDDIR}/db/cloud/txk_R1220_${cloudtag}_base_bugs.xml"
   MAP_LIST_FILE="${CMDDIR}/db/cloud/txk_R1220_${cloudtag}_mappings.xml"
   XML_FILE_NAME="txk_R1220_${cloudtag}_base_bugs.xml"
fi #end if cloud

if test ! -f ${BUG_LIST_FILE} ; then 
 # BUG_LIST_FILE does not exist. 
  exit_code="ETCC-0032"
  exit_script
else
    xmlver=`grep Header ${BUG_LIST_FILE} | ${AWK} '{ print $4 }'`
    printf "\nBugfix file ${BUG_LIST_FILE}: ${xmlver}" | tee -a $LOGFILE
    printf "\nThis file will be used for identifying missing bugfixes. \n"| tee -a $LOGFILE
fi


if test ! -f ${MAP_LIST_FILE} ; then
    if test "${GridHome}" = "y" ; then 
      printf "\nPatch mapping disabled for Oracle Grid Infrastructure.\n" | tee -a $LOGFILE 
    else
      printf "\nPatch mapping disabled because ${MAP_LIST_FILE} is missing.\n" | tee -a $LOGFILE  
    fi
    isPatchMap="n"
else
    mapxmlver=`grep Header ${MAP_LIST_FILE} | ${AWK} '{ print $4 }'`
    printf "\nMapping file ${MAP_LIST_FILE}: ${mapxmlver}\n" | tee -a $LOGFILE
    printf "This file will be used for mapping bugfixes to patches.\n" | tee -a $LOGFILE
fi

xmlfiledate=`grep Header ${BUG_LIST_FILE} | ${AWK} '{ printf "%s %s \n", $5,$6 }'`
epochxfdate=`echo $xmlfiledate | ${perlprg} -MPOSIX -pwe 's{(\d{4})/(\d{2})/(\d{2}) (\d{2}):(\d{2}):(\d{2})}{mktime($6,$5,$4,$3,$2-1,$1-1900)}e;'`

curdate=`${perlprg} -e 'print time'`

xmldays=`expr  $curdate - $epochxfdate `
xmldays=`expr $xmldays / 86400`

if test $xmldays -gt 30 ; then
   printf "\n\n[WARNING] DB-ETCC: Bugfix XML file (${BUG_LIST_FILE}) is \nmore than 30 days old.\n " |tee -a $LOGFILE
fi

#Always suggest that the latest version of ETCC is used
printf "\n+---------------------------------------------------------------------------------------+"| tee -a $LOGFILE
printf "\n  Always use the latest version of ETCC available in patch 17537119," | tee -a $LOGFILE
printf "\n  as new bugfixes will not be checked by older versions of the utility." |tee -a $LOGFILE
printf "\n\n  You should apply the latest recommended RU, BP, or PSU as appropriate." |tee -a $LOGFILE
printf "\n+---------------------------------------------------------------------------------------+\n\n"| tee -a $LOGFILE

# create a temp dir
   PTCH_TMP=${LOCAL_TEMP}
 

   PATCHES_TOAPPLY="${PTCH_TMP}/PAPPLY.lst"
   PATCHES_TOROLLBACK="${PTCH_TMP}/PRLBK.lst"

   PATCHES_APPLIED="${PTCH_TMP}/patchesApplied.lst"
   DIFF_PATCHES_APPLIED="${PTCH_TMP}/diffpatchesApplied.lst"
   FIXES_FROMXML="${PTCH_TMP}/patchesFromXML.lst" 
   RAC_PATCHES_TOAPPLY="${PTCH_TMP}/RACPAPPLY.lst"
   PATCHCOUNTER="${PTCH_TMP}/PATCHCOUNTER.lst"
   if test "${cloud}" = "y" ; then
    cloud_patch_update="${PTCH_TMP}/CLOUDPATCHUPDATE.lst"
    touch ${cloud_patch_update}
   fi

   touch ${PATCHES_TOAPPLY}
   touch ${PATCHES_TOROLLBACK}
   touch ${PATCHES_APPLIED}
   touch ${DIFF_PATCHES_APPLIED}
   touch ${FIXES_FROMXML}
   touch ${RAC_PATCHES_TOAPPLY}
   touch ${PATCHCOUNTER}
   # Check if opatch exists in the Oracle Database Home
   OPATCH=${ORACLE_HOME}/OPatch/opatch
   if test ! -f ${OPATCH} ; then
       #Could not find opatch utility in database ORACLE_HOME. \nCannot confirm bugfixes applied.
       exit_code="ETCC-0052"
       exit_script
   fi

if test "${isDBIM}" = "y" ; then
    if test ${DB_REL} -gt 19 ; then
       DB_VERSION="${DB_VERSION}_RU"
    else
      if test ${DB_REL} -gt 12 ; then
       DB_VERSION="${tsvers}_RU"
      else
       DB_VERSION="${tsvers}_BP"
      fi
    fi

fi
#Get DST version
checkDSTversion
if test "${cloud}" != "y" ; then
  checkRelease

 # Get N1 release
  if test ${DB_REL} -ge 19 ; then
    GetN1Release
  else
    is19RU="false"
    export is19RU
  fi
  if test "${GridHome}" != "y" ; then
    # if InMemory enabled or Exadata check for Bundle Patch
      # Customers on 12c may have DBBP applied, so we need to check for Bundle
      if test ${DB_REL} -ge 12 ; then
        checkBundleversion
        # If no DBBP is applied, then check for PSU
        if test "${bundleapplied}" = "y" ; then
              if test ${DB_REL} -gt 19 ; then
                DB_VERSION="${DB_VERSION}_RU" 
              else
                if test ${DB_REL} -gt 12 ; then
                  DB_VERSION="${tsvers}_RU"
                else
                  DB_VERSION="${tsvers}_BP"
                fi
             fi

        else  
          checkPSUversion  
        fi

      else

        # check for a bundle version 11g
        checkBundleversion

        # check for a PSU version
        checkPSUversion  
      fi #if ge 12c
  fi # if not Grid
else # Cloud 
  # ExaCS check for Bundle
  if test "${isExa}" = "y" ; then
      checkBundleversion
  else # Non=EXA
    if test ${DB_REL} -ge 12 ; then
      if test "${isRacEnv}" != "y" ; then
        if test "${cloudinfrastructure}" = "oci" ; then
          checkBundleversion   # OCI non-RAC is DBBP
          # If no DBBP is applied, then check for PSU
            if test "${bundleapplied}" != "y" ; then
              checkPSUversion  
            fi          
        else
          checkPSUversion # Classic non-RAC is PSU
        fi
      else  # RAC for 12c on BMC and OPC is DBBP
        checkBundleversion
      fi
    else # 11g non-Exa or non-RAC is PSU

       checkPSUversion   
    fi 
  fi # End ExaCS check
fi # End Bundle or PSU patch checks


# End Bundle or PSU patch checks
if test "${TAGID}x" != "x" ; then
   DB_VERSION="${tsvers}_${TAGID}"  # <version>_PSU or <version>_ES (11g Exadata)
fi

#Get consolidated zip by platform/release for on prem or by db release for OCI 
if test -f ${MAP_LIST_FILE} ; then
 getConsolidatezip
fi
      
if test "${cloud}" = "y" -a "${GridHome}" != "y" ; then
  if test "${myrealm}" = "oc1"; then
    case ${DB_REL} in 
         "11")
           updateidtag="db11gR2_patch_update" 
         ;;
         "12")
           updateidtag="db12cR1_patch_update" 
         ;;
         "19")
           updateidtag="db19c_patch_update_oc1" 
         ;;
         "23")
           updateidtag="db23ai_patch_update_oc1" 
         ;;
         *)
          #not a supported database release
          exit_code="ETCC-0120"
          exit_script
         ;;
     esac
     
     patch_update_bugid=`grep ${updateidtag} ${BUG_LIST_FILE} | sed 's/^.*bugid=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g'`
     patch_update_patchid=`grep ${updateidtag} ${BUG_LIST_FILE} | sed 's/^.*patchid=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g'`
     patch_update_desc=`grep ${updateidtag} ${BUG_LIST_FILE} | sed 's/^.*description=[^".]*"[ ]*\([^"]*\)".*/\1/g; s/ *$//g'`
     echo ${patch_update_bugid} > ${cloud_patch_update}

    if test "${serviceRU}x" != "x" ; then
       printf "\nSpecifying a database RU is not supported when running on commercial cloud (OC1)\n or on-premises, so the serviceRU parameter will be ignored. \n" >> $LOGFILE
    fi
  else

    if test "${serviceRU}x" != "x" ; then
     printf "\nYou have specified database RU: ${serviceRU} using the serviceRU parameter. \n" >> $LOGFILE
    else
     printf "\nYou have not specified a database RU using the serviceRU parameter. \n" >> $LOGFILE
    fi
   # end of myrealm
  fi 
   DB_VERSION="${tsvers}"
   cloudvers="${mapvers}"  # e.g 11.2.0.4.160419,  12.1.0.2.160419ProactiveBP
   mapvers=$cloudvers

  else
     #On-Prem
     #Test for DB rel and then update updateidtag

    if test "${cloud}" != "y" -a "${GridHome}" != "y"; then
    case ${DB_REL} in 
         "11")
            updateidtagbp="db11g_latest_es"
            updateidtagpsu="db11g_latest_psu"
         ;;
         "12")
              updateidtagbp="db12c_latest_bp"
              updateidtagpsu="db12c_latest_psu"
         ;;
         "19")
           updateidtag="db19c_latest_ru"
         ;;
         "23")
           updateidtag="db23ai_latest_ru"
         ;;
         *)
          #not a supported database release
          exit_code="ETCC-0120"
          exit_script
         ;;
     esac
  
     if test "${serviceRU}x" != "x" ; then
       printf "\nSpecifying a database RU is not supported when running on commercial cloud (OC1)\n or on-premises, so the serviceRU parameter will be ignored. \n" >> $LOGFILE
     fi 

       if test ${DB_REL} -gt 12 ; then
          getIdTag ${updateidtag}     
          release_update_bugid=`echo ${relupdtline} | ${AWK} -F: '{printf $3}' `
          release_update_patchid=`echo ${relupdtline} | ${AWK} -F: '{printf $4}' `
          release_update_desc=`echo ${relupdtline} | ${AWK} -F: '{printf $6}' `
          release_update_filename=`echo ${relupdtline} | ${AWK} -F: '{printf $5}' `
       fi
    
     #Need to do the same for 11g and 12c
      if test "${updateidtagpsu}x" != "x" ; then
       getIdTag ${updateidtagpsu}     
       patch_update_bugid=`echo ${relupdtline} | ${AWK} -F: '{printf $3}' `
       patch_update_patchid=`echo ${relupdtline} | ${AWK} -F: '{printf $4}' `
       patch_update_desc=`echo ${relupdtline} | ${AWK} -F: '{printf $6}' `
       patch_update_filename=`echo ${relupdtline} | ${AWK} -F: '{printf $5}' `
      fi
      if test "${updateidtagbp}x" != "x"; then
       getIdTag ${updateidtagbp}     
       bundle_update_bugid=`echo ${relupdtline} | ${AWK} -F: '{printf $3}' `
       bundle_update_patchid=`echo ${relupdtline} | ${AWK} -F: '{printf $4}' `
       bundle_update_desc=`echo ${relupdtline} | ${AWK} -F: '{printf $6}' `
       bundle_update_filename=`echo ${relupdtline} | ${AWK} -F: '{printf $5}'`
      fi

   fi 
fi
#
#Setting the default exit code
#
exit_code="ETCC-0000";

#listdiffs="y" # Additional Applied Patch info 
runProcess_1
exit_script
