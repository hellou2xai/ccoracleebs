# $Id: WSLD.pl 200.10 14:00 PM 03/07/2023 amlepe gbellot kjharris $
# *===========================================================================+
# |  Copyright (c) 2019 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services
# +===========================================================================+
# | See end of file for complete details / history
# +===========================================================================+

$main::version = '200.10';
BEGIN
{
  require 5.8.0;
  #Check for apps environment variables which should generally indicate we have an apps env file sourced 
  die "\n\n   ERROR: Apps Environment Required\n\n\n" if ! $ENV{EBS_DOMAIN_HOME} && ! $ENV{ORACLE_HOME} && ! $ENV{FWM_HOME};
  $libdir = './perlLib';
  push @INC, "$libdir";
  mkdir ".tmp"; 
}

use POSIX;
use POSIX qw(strftime);
use Term::ANSIColor qw(:constants);
 $Term::ANSIColor::AUTORESET='1';
use Carp qw(cluck);

use Cwd;
use File::Find;
use File::stat;
use File::Copy;
use File::Basename;
use Data::Dumper;

# +-------------+ 
# | WLSD Libs 
# +-------------+ 
 
use CorePSD::RunSQL;
use CorePSD::CorePSD;
require CorePSD::WriteHTML;
use WLSU::WLSU; 

  cls(); 
  #kill any old zip manifest (should not exist) 
  unlink(".tmp/zipManifest.lst"); 
  
# +-------------+
# Process args 
#  3:08 PM 3/8/2017: supported arg is 'target' to allow the user to override 
#   the default behavior of using the last 72 hours as the target time window
#   in which to gather logs. 
# +-------------+
$main::searchDir; 
$main::OS = $^O; 
%main::globals = bless {};
%main::globalCmds = bless {};
%main::globalValues = bless {};
%main::conditions = bless {};

$main::mtime_max = 2*86400; #to collect files modified in last 48 hours

foreach my $cla ( @ARGV )
  {
    if ($cla =~ /target/i) 
    {
      ($main::min, $main::max) = timeMachine('target');
      $main::target = 'y';
    }
    elsif ($cla =~ /support/i) 
    {
      $main::searchDir = getDir(); 
    }
    else 
    {
      usage();
    }
  
  }
if (scalar @ARGV == 0) 
{
  ($main::min, $main::max) = timeMachine('default');
  
  if (! -f '.tmp/dontshow')
  {
    print qq(\n\n  ); 
    print BOLD WHITE ON_BLUE "NOTE:"; 
    print qq( The default time window that $0 uses to search logs 
        is the last 12 hours.\n\n  ); 
    print BOLD WHITE ON_BLUE "TIP:"; 
    print qq( Use \"$0 target\" to specify a 6 hour time window on a specific date. 

  See: E-Business Suite: WLS (WebLogic Server) Utility (Doc ID 2230225.1)\n\n  ); 
  print BOLD WHITE ON_GREEN "[[D]on't", RESET, "Show This Again]\n\n"; 
  print qq(  Press ); 
  print BOLD WHITE ON_GREEN "[Enter]";  
  print qq( or ); 
  print BOLD WHITE ON_GREEN "[D]"; 
  print qq( to Continue: ); 
    my $us; 
    chomp ($us = <STDIN>); 
    if ($us =~ /^d/i) 
    {
      open (my $fh, '>', '.tmp/dontshow' ); 
      close($fh); 
    }
    cls(); 
  } 
}

# 12:51 PM 8/14/2017 logging for WLSU 
$main::Log = 'output/WLSU_' . (strftime "%Y-%m-%d_%H%M%S", localtime) . '.log';
open (my $LOG, '>', $main::Log ) || die cluck "  main(): Cannot open \"$main::Log\": $! \n";  
close $LOG; 

# +--------------+ 
# 
# Sand Box 
# +--------------+ 

# +--------------+ 

# +-------------+ 
# | Enter main() 
# +-------------+ 

main();
# +-------------------------------------+
# | sub: main() 
# +-------------------------------------+
# | Desc: main prog entry 
# | 
# | Flow: 
# | => open zip manifest to write all found logs 
# | => start a new HTML output file 
# | => Run WLST to generate status & thread dumps 
# +-------------------------------------+
# | Args:  nebytiye 
# +-------------------------------------+
# | Returns: nada  
# +-------------------------------------+
sub main
{
  #create zip manifest 
  open (my $fh, '>', '.tmp/zipManifest.lst' ) || die cluck "  main(): Cannot open \".tmp/zipManifest.lst\": $! \n"; 
  close $fh; 

  #1 create HTML output file with header 
  # HOF = HTML OUT FILE 
  my ($HOF) = startNewHTML('WLSU', '2230225.1', "WebLogic Server Utility", "wls_latest_version.gif", "The WebLogic Server Utility is a self-service utility created by Oracle Support Proactive Services. The utility is meant to make WLS logs and errors easier to find and read, as well as providing an all-in-one snap shot of the WLS environment and configuration."); 
  
  #2 Make Logs available. 
  # ==> Run wslt first to generate: Thread Dumps, Status file (WLS-status.log)
  if (! $main::searchDir) 
  { 
    logger('Main() Calling runWLST');
    my $status = runWLST('ebsWLS.py');
    logger("Main() runWLST exited with: $status");
    
    #we will stil write the HOF even if WLST failed.. we 
    # can still get logs. 
    # the subs which gather the specific types of outputs 
    # will write failure messages to the HOF if those 
    # subs cannot find the logs they are looking for 
  }
  writeHTMLFile($HOF); 

  my $zipOutputFile = processZip('open');
  my $aFile = $ENV{CONTEXT_FILE};
  processZip('add',$zipOutputFile,$aFile);

  $aFile = $ENV{EBS_DOMAIN_HOME};
  $aFile = $aFile . '/config/config.xml';
  processZip('add',$zipOutputFile,$aFile);

  zipLogs($zipOutputFile) if (! $main::searchDir);
  processZip('close',$zipOutputFile);

  #clean up tmp files 
  unlink(".tmp/runWLST.sh");
  unlink(".tmp/zipManifest.lst");
  unlink(".tmp/checkSigs.tmp");
  
  my $du; my $units; 
  if ($^O eq 'linux') 
  { $du = "du -h"; } 
  else 
  { 
    $du = "du -m";  
    $units = "M"; 
   } 
 
  my $size = qx($du $HOF);
  $size = $+ if $size =~ /(.+?)\s/; 
  print BOLD WHITE ON_BLUE "   HTML Report: $HOF [$size$units]", RESET;
  print "\n\n  $0 Done.\n";
}#:END main 

sub usage
{
  cls(); 
  print "\n\n\n"; 
  print BOLD WHITE ON_BLUE "  WLSU Usage  \n"; 
  print qq(
  o Supported command line arguments: "$0 target", "$0 support" 
  o "target" evokes a date selection option 
  o By default, $0 looks for log entries created in the last 12 hours 
  o The "target" option will look +/- 6 hours from the selected time and date
    --I.e., Entering "17-Jan-2017 12:00" would effectively select logs from: 
            15-Jan-2017, 11:00(am) to 15-Jan-2017 17:00(pm)
  o "support" option will prompt for log location to search. 
     -- Can combine with "target"   \n\n);

exit 1; 
}#END usage()


__END__ 

+============================================================================+
| Version History, Notes 
| ----------------------------------------------------------------------------
| 200.0: Beta 
| 200.1: Initial Release [8:21 AM 3/30/2017] 
| 200.2: Development Full Review 
|       => Changed target option to be a 6 hour window 
|       => default run is now last 12 hours 
|       => Only gathing access_log errors (400 or 500 series), instead of 
|          entire log 
|       => various changes to WLST (runWLST sub)
| 200.3: 
|       => "support" option: "wlsu.pl support" allows user to process 
|           logs in a given directory 
|       => Changes to ebsWLS.py for HTML formatting 
|       => tool logging: WLSU Tool log created under:
|           "output/WLSU_YYYY_MM_DD_HHMMSS.log"
| 200.4: logs not zipping, fixed with "searchDirX" in WLSU.pm
| 200.5: CSS Formatting Fixes (tables overflowing) 
|       => Delete .tmp/* files after run 
|       => Log Summary: Table Split into 3 tables, added log mod. time
| 200.6: 
|       => Updated python output for better OS formatting in "getGII" function 
| 200.7: 
|       => Add new JVM signature 
|       => Updated Signature.pm for looping bug 
|       => Updated handling of access_log, including rotated logs 
|          and always showing them (if 400/500 series errs) 
| 200.8: 
| 	=> Added some HTML comments into the .py script to get picked up 
|          by SR Automation 
|
| 200.9:
|   => Added WLS config file, and EBS context file to the zip of collected 
|      files. Andres.
| 200.10:
|       => Added changes to collect more log files, and adr/*/instance files
|          (for performance issues). Also changed signature template.
+============================================================================+
