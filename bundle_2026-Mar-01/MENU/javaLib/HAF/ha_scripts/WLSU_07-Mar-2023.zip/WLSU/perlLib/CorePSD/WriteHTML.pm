# $Id: WriteHTML.pm 200.2 3:18 PM 9/29/2017 kjharris $
# *===========================================================================+
# |  Copyright (c) 2016 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# | See end of file for complete details / history 
# +===========================================================================+

# +-------------------------------------+
# | sub: startNewHTML
# +-------------------------------------+
# | Desc: copies template/template.html 
# |  to start a new HTML output 
# +-------------------------------------+
# | Args: 
# | 1 outFile = the BASE name you want the HTML File to be 
# | EX: outFile = "PatchParser" creates" 
# |     PatchParser_YYYY-MM-DD_HHMMSS.html 
# | 2 DocID For the tool 
# | 3 title for the tool 
# | 4 latest version gif 
# | 5 blurb: info about your tool for the execution details part 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub startNewHTML 
{
  my ($outFile, $docID, $title, $gif, $blurb) = @_; 
  $outFile = 'output/' . $outFile . '_' . (strftime "%Y-%m-%d_%H%M%S", localtime) . '.html';
  my $qDocID = quotemeta($docID); 
  my $href = quotemeta('<a href="https://support.oracle.com/rs?type=doc\&id=########" target="_blank">########"</a>');
  $href =~ s/$href/$qDocID/g; 
  my $toolVer = getToolVer(); 
  
  #copy template header
  copy("template/template.html", "$outFile") or die "  ERROR: startNewHTML(): Unable to copy file: $! \n";

  #open file, write title
  open (my $fh, '>>', $outFile ) || die "  ERROR: startNewHTML(): Cannot open $outFile $! \n";

  printTitle($title, $toolVer, $fh, $docID, $gif);

  #report information / exec summary / params / Execution details
  printDiv($fh, 'divSection');

  printReportInfo($fh, getRelVer(), $blurb , $toolVer);
  
  printDiv($fh,'end');

  printTabCtrl($fh); #needs printEndDiv

  close $fh;
  return($outFile); 
  
}#END: startNewHTML


# +-------------------------------------+
# | sub: printHiddenTable 
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: lexical FH, class of div 
# | valid classes: 
# | 
# | divItemTitle
# | divSection 
# | printDivItem
# | 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printHiddenTable
{
  my ($fh, $ID, $mode) = @_; 

  if ($mode eq 'start') 
  { 
    print $fh qq( 
   <table class="table1" id="$ID" style="display:none">\n<tbody>\n); 
  }
  #if mode eq 'end' then close off the table tags. 
  if ($mode eq 'end') 
  {
    print $fh qq(
   </tbody> 
   </table>
    );
  }

}#END: printHiddenTable 

# +-------------------------------------+
# | sub: printBackToTop; 
# +-------------------------------------+
# | Desc: print "back to top" link 
# +-------------------------------------+
# | Args: lexical fh 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printBackToTop
{
  my ($fh) = @_; 
  print $fh qq(<br> <a href="#top"><font class="backToTop">[back to top]</font></a></font> <br> ); 

}#END: printBackToTop


# +-------------------------------------+
# | sub: printDiv 
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: lexical FH, CSS class, divID, hidden (y/n) 
# | valid classes: 
# | 
# | divItemTitle
# | divSection 
# | printDivItem
# | 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printDiv
{
  my ($fh, $type, $divID, $hide) = @_;
  if (length($divID))
  {
    if ($hide eq 'y') 
    {
      print $fh qq(<div class="$type" id="$divID" style="display:none">);
    }
    elsif($type eq 'divItemDBOBJ') 
    {
      print $fh qq(<div class="$type" id="$divID" style="display:block">);
    }
    else 
    {
      print $fh qq(<div class="$type" id="$divID">);
    }
  }
  elsif ($type eq 'end')
  {
    print $fh qq(\n</div>\n);
  }
  else
  {
    print $fh qq(<div class="$type">);
  } 

}#END: printDiv

# +-------------------------------------+
# | sub: printTable
# +-------------------------------------+
# | Desc: prints html table
# | start tags, headings, end tags 
# +-------------------------------------+
# | Args: 
# | 
# | my ($fh, $mode, $numCols, $rows) = @_; 
# | lexical fh 
# | $mode = start|end, headings, row
# | 
# | 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printTable
{
  my ($fh, $mode, $numCols, $rows) = @_;
  #$headings is array ref 
  
  if ($mode eq 'start') 
  {
    print $fh qq(\n<table class="table1">\n <tbody>\n); 
  } 

  if ($mode eq 'headings')
  {
    print $fh qq(  <tr>\n); 
    for (my $i = 0; $i != $numCols; $i++) 
    {
      print $fh qq(   <th>$$rows[$i]</th>\n); 
    }
    print $fh qq(  </tr>\n);
  }
  
  if ($mode eq 'end') 
  {
    print $fh qq(\n </tbody>\n</table>);
  } 
  
  if ($mode eq 'row') 
  {
    print $fh qq(  <tr>\n); 
    for (my $i = 0; $i != $numCols; $i++) 
    {
      print $fh qq(   <td>$$rows[$i]</td>\n); 
    }
    print $fh qq(  </tr>\n); 
    
  }

}#END: printTable


# +-------------------------------------+
# | sub: printDivItemTitle
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printDivItemTitle
{
  my ($fh, $title, $hiddenID) = @_;
  
  print $fh qq( 
    <div class="divItemTitle">
    <a class="detail" href="javascript:;" onclick="displayItem(this, '$hiddenID');">&#9654; $title</a>
    </div>
    ); 


}#END: printDivItemTitle

# +-------------------------------------+
# | sub: printExpand
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: 
# | 1) lexical FH to write to 
# | 2) the ID of the hidden DIV which will expand on click
# | 3) the link text to display that the user clicks on 
# | 4) the link ID for the <a> tag 
# | 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printExpand
{
  my ($fh, $idToExpand, $linkText, $linkId) = @_;
  
  print $fh qq(<a id="$linkId" class="detail" href="javascript:;" onclick="displayItem(this, '$idToExpand');">&#9654; $linkText </a>);

}#END: printExpand


# +-------------------------------------+
# | sub: printSectionTOC
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printSectionTOC
{

  my ($fh, $tocList) = @_; 
  
  print $fh qq(
<script type="text/javascript">
    var a=document.getElementById("toccontent2");
    a.style.display = "block";
      a.innerHTML = '<div class="divItemTitle">In This Section</div><table class="toctable" border="0" width="90%" align="center" cellspacing="0" cellpadding="0"><tr class="toctable">); 
      
      #$anch == unique href anchor
      #$$tocList{$anch} = description of TOC item 
      foreach my $anch (keys %$tocList) 
      {
        
        my $prt = '<td><a href="#' . $anch . '">' . $$tocList{$anch} . '</td>'; 
        print "prt is $prt \n"; <STDIN>;
        print $fh qq($prt); 
        
      }
  print $fh qq(</tr></table>'; </script>);
}#END: printSectionTOC

# +-------------------------------------+
# | sub: printDivSectionTitle
# +-------------------------------------+
# | Desc: 
# | NOTE: Creates all it's own </divs> 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printDivSectionTitle
{
  my ($fh, $sectTextTitle, $sectID, $helpID) = @_; 

  my $ID = 'sect_title' . $sectID; #ex: sect_title1
  my $secTitle = 'sect' . $sectID; #ex: sect1 

  #contains it's own close-div 
    print $fh qq(
    <div class="divSectionTitle" id="$secTitle">
    <div class="left"  id="$ID" font style="font-weight: bold; font-size: x-large;" align="left" color="#FFFFFF">$sectTextTitle
    </font>
    
    <a class="help" href="javascript:;" onclick="displayItem(this, '$helpID');">
    [Help?]</a>
    
    </div>
      <div class="clear"></div>
    </div><br>
    ); 
}#END: printDivSectionTitle


# +-------------------------------------+
# | sub: printFileEndTags
# +-------------------------------------+
# | Desc: print end tags for the HTML file 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printFileEndTags
{
  my ($fh) = @_; 
  print $fh qq( 
</BODY></HTML>\n); 
}#END: printFileEndTags

# +-------------------------------------+
# | sub: printTitle
# +-------------------------------------+
# | Desc: prints the report title output 
# +-------------------------------------+
# | Args: 
# | 1) The Title of the tool
# | 2) tool version (200.xx) 
# | 3) A lexical filehandle to write to 
# | 4) The docID where the DOWNLOAD attachment lives (to get the tool) 
# | 5) The gif name of the "latest version" gif 
# +-------------------------------------+
# | Returns: nebytiye
# +-------------------------------------+
sub printTitle
{
  my ($title, $ver, $fh, $docID, $gif) = @_; 
  my $date = (strftime "%d-%b-%Y", localtime);
  
  print $fh qq(<!----------------- Title ----------------->
<title>$title</title>
<div class="TitleBar">
<!-- <div class="TitleImg"><a href="https://support.oracle.com/rs?type=doc%5C&amp;id=432.1" target="_blank"><img src="https://blogs.oracle.com/ebs/resource/Proactive/PSC_Logo.jpg" title="Click here to see other helpful Oracle Proactive Tools" alt="Proactive Services Banner" border="0" height="60" width="180"></a></div> --> 
    <div class="Title1">$title: $ENV{CONTEXT_NAME}</div>
    
    <!-- COMMENTED 9:01 AM 5/26/2017 AS LATEST VERS ICON LINKS ON BLOGS.ORACLE.COM ARE BROKEN <div class="Title2">Generated on $date, using version: $ver | Latest version: <a href="https://support.oracle.com/oip/faces/secure/km/DownloadAttachment.jspx?attachid=$docID:DOWNLOAD">
<img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/$gif" title="Click here to download the latest version of Analyzer" alt="Latest Version Icon"></a></div> 

    -->
    <!-- the following line / div is temporary until the latest version issue is resolved --> 
    <div class="Title2">Generated on $date, using version: $ver</div> 


</div>  


<br>
<!------------------ TOC ------------------>\n); 
  return(); 
}#END: _printTitle 

# +-------------------------------------+
# | sub: printReportInfo 
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: 
# | 
# | 
# | 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printReportInfo
{
  my ($fh, $appsVer, $desc, $scriptVer) = @_; 
  my $date = (strftime "%d-%b-%Y %H:%M:%S", localtime);
  use Net::Domain qw(hostdomain); 
  use Sys::Hostname; 
  my $fqhn = hostname . '.' . hostdomain;

  #requires: Apps Version (from context file) 
  # "s_apps_version"
  
  #desc, ex: The Concurrent Processing Analyzer (<a href="https://support.oracle.com/rs?type=doc\&id=1411723.1" target="_blank">1411723.1</a>) is a self-service proactive health-check script that reviews the overall footprint, analyzes current configurations and settings for the environment and provides feedback and recommendations on best practices. Your application data is not altered in any way when you run this analyzer. 
  
  
  print $fh qq( 
<div class="divItem" id="runinfo"><div class="divItemTitle">Report Information</div>
<!-- <span class="legend">Legend: &nbsp;&nbsp;<img class="error_ico"> Error &nbsp;&nbsp;<img class="warn_ico"> Warning &nbsp;&nbsp;<img class="check_ico"> Passed Check</span> --> 
<table width="100%" class="graph"><tbody>
      <tr class="top"><td width="30%"><p>
      <a class="detail" href="javascript:;" onclick="displayItem(this,'RunDetails');"><font color="#0066CC">
      &#9654; Execution Details</font></a></p>
      <table class="summaryTable" id="RunDetails" style="display:none">
      <tbody>
<tr><th class="rep">Apps Version</th><td>$appsVer</td></tr>
<tr><th class="rep">Description</th><td>$desc</td></tr>
<tr><th class="rep">Execution Date</th><td>$date</td></tr>
<tr><th class="rep">File Name</th><td>$0</td></tr>
<tr><th class="rep">File Version</th><td>$scriptVer</td></tr>
<tr><th class="rep">Host</th><td>$fqhn</td></tr>
<tr><th class="rep">Instance</th><td>$ENV{TWO_TASK}</td></tr>
</tbody></table></td>
<td width="30%">
  <p><a class="detail" href="javascript:;" onclick="displayItem(this,'Parameters');"><font color="#0066CC">&#9654; Command Line Parameters</font></a></p>
    <table class="summaryTable" id="Parameters" style="display:none">
    <tbody>); 
    
    my $i; 
    foreach (@ARGV) 
    {
      $i++; 
      print $fh qq(<tr><th class="rep">Parameter $i</th><td>&quot;<strong>$_   </strong>&quot;</td></tr>);
      
      if ($_ =~ /target/i)
      {
        print $fh qq(\n<tr><td colspan="2"><b>Time Window:</b> ); 
        print $fh qq(\n<br><br><b>From:</b> ), strftime '%d-%b-%Y %H:%M:%S', localtime $main::min;
        print $fh qq(\n<br><b>To:&nbsp;&nbsp;</b> ),strftime '%d-%b-%Y %H:%M:%S', localtime $main::max;
        print $fh qq(\n</td></tr>); 
      }
    }
    if (scalar @ARGV == 0) 
    {
      print $fh qq(<tr><td>[No Command Line Parameters]</td></tr>)
    }
    
    print $fh qq( 
    </tbody>
    </table>
</td>
<!--<td width="30%"><p>
    <div id="ExecutionSummary1">
    <a class="detail" href="javascript:;" onclick="displayItem(this,'ExecutionSummary2');">
    <font color="#0066CC">&#9654; Execution Summary</font></a> </div>
    <div id="ExecutionSummary2" style="display:none"> </div>
</td>--></tr></table>
</div> 

    <br/>
<div class="divItem" id="toccontent"><div class="divItemTitle">Sections In This Report</div></div>
  <div align="center">
<a class="detail" onclick="opentabs();" href="javascript:;"><font color="#0066CC"><br>Show All Sections</font></a> &nbsp;&nbsp;/ &nbsp;&nbsp;
<a class="detail" onclick="closetabs();" href="javascript:;"><font color="#0066CC">Hide All Sections</font></a>
</div>
<!--------------- ### END printReportInfo() ###--------------> 


); 

}#END: printReportInfo


# +-------------------------------------+
# | sub: printButtons 
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: $buttons: hashRef 
# | $hash{1}-{NAME} = 'string'; text for the 
# |                    button (goes on the button) 
# | $hash{1}-{ICON} = 'error_ico'; (warn_ico, 
# |                    error_ico, check_ico) 
# | $fh = the open file handle to write to 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printButtons
{
  my ($buttons, $fh) = @_; 
  #we need to know the button descriptions / icons in hash format: 
  # $hash{1}-{NAME} = 'string'; 
  # $hash{1}-{ICON} = 'error_ico';
  # $hash{}->{ECOUNT} = '3'; int to count # of errors/warnings for that particular page
  # $hash{}->{WCOUNT} = '3'; int to count # of errors/warnings for that particular page
  # $hash{2}-{NAME} = 'string'; 
  # $hash{2}-{ICON} = 'warn_ico'; 
  
  
  print $fh q(
  <script type="text/javascript">
  var auxs;
  auxs = document.getElementById("toccontent").innerHTML;
  document.getElementById("toccontent").innerHTML = auxs +);
  
  my $page; 
  foreach my $i (sort { $a <=> $b} keys %$buttons)
  {
    $page = 'page' . $i;
    print $fh qq("<button class='btn' OnClick=activateTab\('$page'\)>$$buttons{$i}->{NAME}" +
  " <img class='$$buttons{$i}->{ICON}'>" +
  "</button>" + );
  }

  print $fh q(
  "</div>";
  activateTab('page1'););
  
  my $sectTitle; 
  foreach my $i (sort { $a <=> $b} keys %$buttons)
  {
    my $totErrors = $$buttons{$i}->{ECOUNT} + $$buttons{$i}->{WCOUNT};
    $sectTitle = 'sect_title' . $i;
    print $fh qq(auxs = document.getElementById\("$sectTitle"\).innerHTML;
          document.getElementById\("$sectTitle"\).innerHTML = auxs +
   "<img class='$$buttons{$i}->{ICON}'> ";); 
   # print $fh qq(auxs = document.getElementById\("$sectTitle"\).innerHTML;
    # document.getElementById\("$sectTitle"\).innerHTML = auxs +
   # "$totErrors <img class='$$buttons{$i}->{ICON}'> ";); 
  } 
  
  #EXEC Summary Content 
  
  
  #EXEC summary title section --------------------------------------------+ 
  #this only runs / displays once. 
  # we need to get a total of all COUNT's from the hash foreach 
  # hash element 
  # exec summary.. title with icons and counts in the title 
  # ExecutionSummary1 is the title div, ExecutionSummary2 is the table content div 
  my $totEs = 0; 
  my $totWs = 0; 
  
  #total up all the errors among all button areas 
  foreach my $i (keys %$buttons)
  {
    $totWs = $totWs + $$buttons{$i}->{WCOUNT};
    $totEs = $totEs + $$buttons{$i}->{ECOUNT}; 
  }
  
  print $fh qq(
  auxs = document.getElementById("ExecutionSummary1").innerHTML;
  document.getElementById("ExecutionSummary1").innerHTML); 
  #  = auxs +
  #"($totEs <img class='error_ico'> $totWs <img class='warn_ico'>)";);
  #END EXEC summary title section --------------------------------------------+
  
 #exec summary hidden / expand collapse content / table: 

  #static (no vars) table Headers: 
  print $fh qq( 
  auxs = document.getElementById("ExecutionSummary2").innerHTML;
        document.getElementById("ExecutionSummary2").innerHTML = auxs +
" <table width='100%' class='table1'><TR><TH class='rep'><B>Section</B></TH><TH class='rep'><B>Errors</B></TH><TH class='rep'><B>Warnings</B></TH></TR>"+); 

  #table rows, 1 per each button section / page 
  my $page2; 
  foreach my $i (keys %$buttons)
  {
    if (! $$buttons{$i}->{ECOUNT} > 0) 
    {
      $$buttons{$i}->{ECOUNT} = 0; 
    }
    if (! $$buttons{$i}->{WCOUNT} > 0) 
    {
      $$buttons{$i}->{WCOUNT} = 0; 
    }
    
    $page2 = 'page' . $i;
    print $fh qq("<TR><TH class='rep'><A class=detail onclick=activateTab('$page2'); href='javascript:;'>$$buttons{$i}->{NAME}</A> "+
    "<img class='$$buttons{$i}->{ICON}'>"+
    "</TH><TD>$$buttons{$i}->{ECOUNT}</TD><TD>$$buttons{$i}->{WCOUNT}</TD></TR>"+);
  }   

  print $fh qq(
  " </TABLE></div>"; 
  
function openall()
  {
    var txt = "restable";
    var i;
    var x=document.getElementById('restable1');
    for (i=0;i<=34;i++)
    {
    x = document.getElementById(txt.concat(i.toString(),'b'));
         if (!(x == null ))
        {x.innerHTML = x.innerHTML.replace(String.fromCharCode(9654),String.fromCharCode(9660));
           x.innerHTML = x.innerHTML.replace("Show SQL","Hide SQL");
       }
    x=document.getElementById(txt.concat(i.toString()));
      if (!(x == null ))
      {document.getElementById(txt.concat(i.toString())).style.display = ''; }
    }
  }

  function closeall()
  {
    var txt = "restable";
    var txt2 = "tbitm";
    var i;
    var x=document.getElementById('restable1');
    for (i=0;i<=34;i++)
    {
      x=document.getElementById(txt2.concat(i.toString()));
         if (!(x == null ))
        {document.getElementById(txt2.concat(i.toString())).style.display = 'none';}
      x = document.getElementById(txt2.concat(i.toString(),'b'));
         if (!(x == null ))
        {x.innerHTML = x.innerHTML.replace("Hide SQL","Show SQL");}

      x = document.getElementById(txt.concat(i.toString(),'b'));
         if (!(x == null )){x.innerHTML = x.innerHTML.replace(String.fromCharCode(9660),String.fromCharCode(9654)); }

      x=document.getElementById(txt.concat(i.toString()));
         if (!(x == null )){document.getElementById(txt.concat(i.toString())).style.display = 'none';}
    }
  } //end closeall() 


    function opentabs() 
    {
      var tabCtrl = document.getElementById('tabCtrl');
      for (var i = 0; i < tabCtrl.childNodes.length; i++) 
      {
        var node = tabCtrl.childNodes[i];
        if (node.nodeType == 1 && node.toString() != '[object HTMLScriptElement]') 
        { /* Element */
          node.style.display =  'block' ;
        }
      }
   } //end opentabs() 

    function closetabs() 
    {
      var tabCtrl = document.getElementById('tabCtrl');
      for (var i = 0; i < tabCtrl.childNodes.length; i++) 
      {
        var node = tabCtrl.childNodes[i];
        if (node.nodeType == 1) 
        { /* Element */
          node.style.display =  'none' ;
        }
      }
    }
    </script> 
    
<!--------------- ### END printButtons() ###--------------> 
    ); 


}#END: printButtons 


# +-------------------------------------+
# | sub: printEOFHelp
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: nebytiye
# | $fh: lexical, open FH 
# | $commThreadID: The thread ID for the MOSC 
# |                 Comm. thread 
# | $title: Tool Title  
# | 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printEOFHelp
{
  my ($fh, $commThreadID, $title) = @_;

  print $fh qq(
  <br><hr> 
  <strong>Questions or Suggestions?</strong><br><br>
  <a href="https://community.oracle.com/message/$commThreadID" target="_blank">
  <img border="0" src="https://blogs.oracle.com/ebs/resource/Proactive/Feedback_75.gif" title="Click here to provide feedback">
  </a><br><span class="regtext">
  Click the button above to ask questions or provide feedback on the $title. Share your recommendations for enhancements and help us make this even more useful!
  <hr> 
  </span>
  <!--------------- ### END printEOFHelp() ###--------------> 
); 

}#END: printEOFHelp

# +-------------------------------------+
# | sub: printTabCtrl
# +-------------------------------------+
# | Desc: start tabCtrl Div where 
# | "meat" of content is .. inside the 
# | tabCtl divs is where the pages go for the 
# | buttons to manipulate. This is needed once 
# | per HTML output. 
# +-------------------------------------+
# | Args: lexical FH 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printTabCtrl
{
  my ($fh) = @_; 

  print $fh q( <br><br>
<div id="tabCtrl">
  ); 

}#END: printTabCtrl


# +-------------------------------------+
# | sub: printHelpDiv 
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printHelpDiv
{

my ($fh, $helpText, $helpID) = @_; 

print $fh qq(
<div class='divItem' id='$helpID' style="display:none">

$helpText 

</div> 
); 



}#END: printHelpDiv


# +-------------------------------------+
# | sub: printNewPage
# +-------------------------------------+
# | Desc: the page container div for a single
# | button 
# +-------------------------------------+
# | Args: lexical FH + page # 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub printNewPage
{
  my ($fh, $pgNum) = @_; 

  $pgNum = 'page' . $pgNum; 
  print $fh qq(
<div id="$pgNum" style="display: block;">
); 

}#END: printNewPage

# +-------------------------------------+
# | sub: genRandString
# +-------------------------------------+
# | Desc: 
# |       Gen a random string for use as a 
# |       unique DIV tag (not guaranteed to be unique 
# |       but very probable-enuf to be. 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: 9 char random hex 
# +-------------------------------------+
sub genRandString 
{
  my $rs; 
  $rs = join "", map { unpack "H*", chr(rand(256)) } 1..5; 
  return(uc($rs));
}#END: genRandString 


"The End.";

__END__ 

+===========================================================================+
 FILENAME: WriteHTML.pm

 PLATFORM: Unix Generic

 NOTES: 
 Writes HTML content to a given lexical filehandle 

 HISTORY: 
 --200.0 BETA (20-DEC-2016)
 --200.2 Changed some references from "table1" to "tableSummary" 
         to address some CSS formatting issues. 
+===========================================================================+