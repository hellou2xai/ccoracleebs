# $Id: CorePSD.pm 200.2 10:00 AM 11/01/2022 amlepe kjharris $
# +===========================================================================+
# |  Copyright (c) 2016 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services   
# +===========================================================================+
# | See end of file for complete details / history  
# +===========================================================================+
 
sub processZip
{
  my ($action, $zipOutputFile, $file) = @_;

  #print "\n action: $action";
  #print "\n zipOutputFile $zipOutputFile";
  #print "\n file $file";

  if ($action eq '')
  {
    return (0);
  }

  if ($action eq 'open')
  {
    $zipOutputFile = 'output/' . "WLSU_" .  (strftime "%d-%b-%Y_%Hh%Mm%Ss", localtime) . '.zip';
    return $zipOutputFile;
  }

  if ($action eq 'add')
  {
    system("zip -q $zipOutputFile $file");
    return (0);
  }

  if ($action eq 'close')
  {
    print "\n\n  INFO: Done Zipping files. \n";
    my $size = qx($du $zipOutputFile);
    $size = $+ if $size =~ /(.+?)\s/; 
    move($zipOutputFile, "zips\/$zipOutputFile");
    print BOLD WHITE ON_BLUE "\n   Files zipped into: $zipOutputFile [$size]", RESET, "\n\n";
    return(0);
  }
}

# +---------------------------+
# | sub: zipLogs 
# +---------------------------+
# | Desc: zips up all logs found to have errors 
# | during the parsing of a main (adpatch/adadmin) log 
# +---------------------------+
# | Args: n/a 
# +---------------------------+
# | Returns: n/a 
# +---------------------------+
# | Originally from patchParser (parse.pl) 
# +---------------------------+
sub zipLogs
{
  #my $zipOutputFile = 'output/' . "WLSU_" .  (strftime "%d-%b-%Y_%Hh%Mm%Ss", localtime) . '.zip';
  my ($zipOutputFile) = @_;
  open (my $fh, '<', '.tmp/zipManifest.lst' ) || warn "  ERROR: zipLogs(): Cannot open \".tmp/zipManifest.lst\": $! \n"; 
  my @list = <$fh>; 
  close $fh; 
  my $du; my $units; 
  if ($^O eq 'linux') 
  { $du = "du -h"; } 
  else 
  { 
    $du = "du -m";  
    $units = "M"; 
   } 
  
  if ($#list < 0) 
  {
    print "  INFO: zipLogs(): No logs to zip! \n";
    return(1); 
  }
  
  my $testZip = system("which zip > /dev/null 2>&1");
  my $status; 
  if ($testZip == 0) 
  {
    print "\n  INFO: Zipping logs.. please wait.. \n  Number of files zipped: ";
    my $count = 0; 
    until (scalar @list < 1) 
    {
      my $file = shift @list; 
      #chomp($file); 
      #if the file still exists in the list, we can skip it (vs adding multiple times) 
      next if grep{ $_ eq $file } @list;
      next if length($file) < 5;
      $count++; 
      print "$count "; 
      #system("zip -q $zipOutputFile $file");
      
      processZip('add',$zipOutputFile,$file);
    }
    #system("zip -q $zipOutputFile $main::Log");
    processZip('add',$zipOutputFile,$main::Log);
    print "\n\n  INFO: Done Zipping logs. \n"; 
    my $size = qx($du $zipOutputFile);
    $size = $+ if $size =~ /(.+?)\s/; 
    #move($zipOutputFile, "zips\/$zipOutputFile");
    print BOLD WHITE ON_BLUE "\n   Logs zipped into: $zipOutputFile [$size$units]", RESET, "\n\n";
    return(0); 
  }
  else 
  {
    print "   ERROR: Unable to Zip files. \"which zip\" failed with status: $testZip \n";
    return(1); 
  }
  return; 
}

# +-------------------------------------+
# | sub:  getToolVer
# +-------------------------------------+
# | Desc: gets the version from $0 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: version
# +-------------------------------------+
sub getToolVer
{
  my $ver;
  my $ln;
  open (my $fh, '<', $0 ) || die " getToolVer():  open \"$0\": $! \n";
    $ln = <$fh> until $ln =~ /^\#\s\$Id\:/;
  close $fh;
  $ver = $+ if $ln =~ /(200\.\d+)\s/;
  return ($ver);

}#END: getToolVer
 
# +-------------------------------------+
# | sub: getFileVer
# +-------------------------------------+
# | Desc: gets a file version using adident 
# +-------------------------------------+
# | Args: full path to file 
# +-------------------------------------+
# | Returns: file version 
# +-------------------------------------+
sub getFileVer
{
  my ($file) = @_;
  my $ver;
  
  if (! -f $file)
  {
    print "\n  ERROR: getFileVer(): $file was not found \n  press [Enter] to Continue:"; 
  }
  else
  {
    my (@a) = `adident Header $file`; 
    foreach my $ln (@a) 
    {
      ($ver) = $ln =~ /Header:*\s.+?\.\w{3}\s(\d{3}\..+?)\s\d{4}\//;
    }
  }

  if ($ver)
  { 
    return $ver; 
  }
  else 
  {
    return("NO_VER_FOUND"); 
  } 

}#END: getFileVer

# +-------------------------------------+
# | sub: compareVers
# +-------------------------------------+
# | Desc: compares 2 versions 
# | and returns the higher one, then lower 
# +-------------------------------------+
# | Args: 2 file versions 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub compareVers
{
  my ($verA, $verB) = @_; 
  
  if ($verA =~ /[a-z]/i || $verB =~ /[a-z]/i)
  {
    print "  compareVers(): ERROR: Invalid Version Passed: $verA, $verB \n"; 
    print "  press [Enter] to Continue: "; 
    <STDIN>;
    return(1); 
  }
  
  #in most cases, versions should match 
  if ($verA eq $verB) 
  {
    return('equal'); 
  }
  
  my ($Aver1, $Aver2, $Aver3, $Aver4) = split('\.', $verA);
  my ($Bver1, $Bver2, $Bver3, $Bver4) = split('\.', $verB);

  if ($Aver1 > $Bver1 || $Bver1 > $Aver1)
  {
    return ($verA, $verB) if $Aver1 > $Bver1;
    return ($verB, $verA) if $Bver1 > $Aver1;
  }
  elsif ($Aver2 > $Bver2 || $Bver2 > $Aver2)
  {
    return ($verA, $verB) if $Aver2 > $Bver2; 
    return ($verB, $verA) if $Bver2 > $Aver2; 
  }
  elsif ($Aver3 > $Bver3 || $Bver3 > $Aver3)
  {
    return ($verA, $verB) if $Aver3 > $Bver3; 
    return ($verB, $verA) if $Bver3 > $Aver3; 
  }
  elsif ($Aver4 > $Bver4 || $Bver4 > $Aver4)
  {
    return ($verA, $verB) if $Aver4 > $Bver4; 
    return ($verB, $verA) if $Bver4 > $Aver4; 
  }

}#END: compareVers

# +-------------------------------------+
# | sub: getMaxHashID
# +-------------------------------------+
# | Desc: gets the max ID KEY from a hash 
# +-------------------------------------+
# | Args: hash ref 
# +-------------------------------------+
# | Returns: the max ID Key $$hash{ID}
# +-------------------------------------+
sub getMaxHashID
{
  my ($hash) = @_;
  my $max = 0;
  for my $id (sort { $$hash{$a} <=> $$hash{$b} } keys %$hash)
  {
    if ($id > $max)
    {
      $max = $id;
    }
  }
  return ($max);
}#END: getMaxHashID

# +-------------------------------------+
# | sub: cls  
# +-------------------------------------+
# | Desc: clear screen 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub cls 
{
  system("clear"); 
}#END: cls 

# +-------------------------------------+
# | sub:  getRelVer
# +-------------------------------------+
# | Desc: 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: 11i/12.0.x/12.1.x/12.2.x 
# |  from the context file 
# +-------------------------------------+
sub getRelVer
{
  my $contextFile = $ENV{"CONTEXT_FILE"};
  my $relVer;
  open my $fh, '<', $contextFile or die "   ERROR: Could not open $contextFile: $!";

  while (<$fh>) 
  {
    $relVer = $1 if $_ =~ /s_apps_version\">(\d{2}.+)<\/config_option\>/;
    last if defined $relVer;
  }
  close $fh;

  #Validate Release Version 
  die "   ERROR: Unable to determine Release Version from Context File\n" if $relVer !~ /^11\.5|^12\.0|^12\.1|^12.2/;

  #11i bugFix: 
  $relVer = '11i' if $relVer =~ /^11/;
  return ($relVer);
}#END:getRelVer

# +------------
# | sub trim
# |
# + -----------
sub trim
{
  my ($v) = @_;
  chomp($v);
  $v =~ s/^\s+//g;
  $v =~ s/\s+$//g;
  return $v;
}



"The End."; 
__END__ 

+===========================================================================+
 FILENAME: CorePSD.pm

 PLATFORM: Unix Generic 

 NOTES: 
 -Store Core PSD Perl Subs 
 
 HISTORY

 200.0 Creation (08-AUG-2016) 
 200.2 Added sub processZip (01-NOV-2022), Andres.
+===========================================================================+
