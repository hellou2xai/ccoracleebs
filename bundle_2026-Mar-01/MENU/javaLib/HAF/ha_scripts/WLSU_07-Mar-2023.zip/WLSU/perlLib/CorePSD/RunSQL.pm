# $Id: SQL.pm 200.0 2016/07/19 13:10:44 kjharris $
# *===========================================================================+
# |  Copyright (c) 2016 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# | See end of file for complete details / history 
# +===========================================================================+
package CorePSD::RunSQL;

use strict;
use POSIX;
use POSIX qw(strftime);
use Term::ANSIColor qw(:constants);
 $Term::ANSIColor::AUTORESET='1';
use Exporter qw(import);

#exports 
our @EXPORT = qw(getUserPass testSQLConnection runSQL);
 
# +-------------------------------------+
# | sub: getUserPass
# +-------------------------------------+
# | Desc: prompt user for apps & system 
# | credentials 
# +-------------------------------------+
# | Args: user name (either APPS or SYSTEM) 
# +-------------------------------------+
# | Returns: user name / pass of requested 
# | user  
# +-------------------------------------+
sub getUserPass
{
	my ($user) = @_;
	my ($un, $pw);
	my $conn = 99;#0 if connection worked  
	my $attempt = 0;
	$user = uc($user); 
	if ($user eq 'APPS')
	{
		if (! $main::csApps)
		{
			until ($conn == 0 || $attempt == 3)
			{
				$attempt++;
				print "\n\n  Enter your APPS username [APPS]: ";
				chomp($un = <STDIN>);
				$un = 'APPS' if length($un) == 0;
				print "\n  Enter $un\'s password: ";
				system('stty','-echo');
				chomp($pw = <STDIN>);
				system('stty','echo');
				$conn = testSQLConnection($un . '/' . $pw);
			}
		}
		else
		{
			return($main::csApps); 
		}
	}
	elsif ($user eq 'SYSTEM')
	{
		until ($conn == 0 || $attempt == 3) 
		{
			print "\n  Enter your SYSTEM username [SYSTEM]: ";
			chomp($un = <STDIN>);
			$un = 'SYSTEM' if length($un) == 0;
			print "\n  Enter $un\'s password: ";
			system('stty','-echo');
			chomp($pw=<STDIN>);
			system('stty','echo');
			$conn = testSQLConnection($un . '/' . $pw);
		}
	}
	else 
	{
		until ($conn == 0 || $attempt == 3) 
		{
			$un = $user; 
			print "\n  Enter $user\'s password: ";
			system('stty','-echo');
			chomp($pw=<STDIN>);
			system('stty','echo');
			$conn = testSQLConnection($un . '/' . $pw);
			$attempt++;
		}
	}
	
	if ($conn == 0)
	{
		return ($un . '/' . $pw);
	}
	else 
	{
		print "  INFO: Unable to obtain database connection for \'$un\' user. \n   Press [Enter].\n\n";
		<STDIN>; 
		return (1);
	}

}#END: getUserPass


# +-------------------------------------+
# | sub: testSQLConnection 
# +-------------------------------------+
# | Desc: test SQL connection 
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub testSQLConnection
{
	my ($cs) = @_; 
	my $status = 99;

	unlink ('.tmp/out') if -f '.tmp/out';
	
	#create .tmp/testConn.sql 
	open (my $fh, '>', '.tmp/testConn.sql') || die "  ERROR: testSQL(): Cannot open .tmp/testConn.sql: $! \n";
	print $fh qq(
	SET VERIFY OFF
	SET ECHO OFF
	exit;
	);
	close $fh;

	print "\n  INFO: Testing SQL Connectivity.. \n";
	my $pid = fork();
	if ($pid > 0)
	{
		eval
		{
			local $SIG{ALRM} = sub {kill 9, -$pid;die "  testSQLConnection() ERROR: TIMEOUT!"};
			alarm 3;
			waitpid($pid, 0);
			alarm 0;#end fork 
		};
	}
	elsif ($pid == 0)
	{
		setpgrp(0,0);
		system("sqlplus $cs @.tmp/testConn.sql > .tmp/out 2>&1");
		exit(0);#end fork 
	}

	open (my $fh, '<', '.tmp/out') || die "  ERROR: testSQLConnection(): Cannot open \'.tmp/out\' $! \n";
	my @out = <$fh>;
	close $fh;
	
	if (grep(/Connected\sto:/,@out))
	{
		print "  INFO: SQL Connection: Success! \n";
		return 0;
	}
	elsif (grep(/ORA-01017/,@out))
	{
		print "  testSQLConnection(): ERROR: ORA-01017: invalid username/password; logon denied \n";
		return 1;
	}
	else 
	{
		print "  testSQLConnection(): ERROR: Unknown SQL Connection Error: \n";
		print "  $_ \n" foreach @out;
		print "  Press [Enter] to Continue: ";
		<STDIN>;
		return 2;
	}
}

# +-------------------------------------+
# | sub: runSQL
# +-------------------------------------+
# | Desc: runs a SQL script (not any) 
# +-------------------------------------+
# | Args: script to run, user to run as, 
# | script args 
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub runSQL
{
	my ($script, $user, $args, $dir, $cs) = @_;
	my $status;
	my $runCmd;
	my $prodTop;
	my $subDir;
	my $fullPath;
	
	if (uc($user) eq 'APPS')
	{
		if ($dir =~ /^\w+?_\w+?/) #the dir should always be a PROD_TOP
		{
			# $prodTop = $+ if $dir =~ /^(\w+?\_\w+?)\//;
			($prodTop) = $dir =~ /^(\w+?\_\w+?)\//;
			# $subDir = $+ if $dir =~ /^\w+?(\/.+)$/;
			($subDir) = $dir =~ /^\w+?(\/.+)$/;
			$fullPath = $ENV{$prodTop} . $subDir;
			$script = $fullPath . '/' . $script;
		}
		$runCmd = "sqlplus -s $main::csApps \@$script $args";
	}
	#if we passed a connect string into runSQL 
	elsif (length($cs) > 0) 
	{
		$runCmd = "sqlplus -s $cs \@$script $args";
	}
	# elsif ($user eq 'SYSTEM') #cannot currently see where this would be useful 
	# {
		# if ($dir)
		# {
			
		# }
		# $runCmd = "sqlplus -s $main::csSystem \@$script";
	# }
	
	print "\n  INFO: runSQL() running: sqlplus -s ****/**** \@$script\n\n";
	
	#make sure the script exists and return if not 
	if (-f $script)
	{
		$status = system($runCmd);
	}
	else #failed to find file 
	{
		$status = 2;
	}

	#error catching 
	if ($status == 0)
	{
	  print "  INFO: runSQL(): $script succeeded! \n\n"; 
	}
	elsif ($status == 2)
	{
		print "  ERROR: runSQL(): unable to find file: $script\n  Press [Enter]:";
		<STDIN>; 
	}
	else 
	{
		print "  ERROR: runSQL(): unable to run file: $script\n  ACTION: Check the content of the script or try running the SQL manually for more info.\n  Press [Enter]:";
		<STDIN>; 
	}
	
	return $status;
}#END: runSQL


"The End."; 

__END__ 

+===========================================================================+
FILENAME: RunSQL.pm

PLATFORM: Unix Generic

NOTES


HISTORY
--200.0 BETA (19-JUL-2016)
# +===========================================================================+

