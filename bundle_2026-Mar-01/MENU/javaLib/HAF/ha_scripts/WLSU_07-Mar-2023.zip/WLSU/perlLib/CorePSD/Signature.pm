# $Id: Signature.pm 200.1 12:47 PM 1/12/2018 kjharris $
# +===========================================================================+
# |  Copyright (c) 2017 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services
# +===========================================================================+
# |
# | FILENAME: Signature.pm
# |
# | Creates an analyzer object out of an analyzer SQL so that the attribs of 
# | the analyzer can be easily accessed 
# | 
# | PLATFORM
# |   Unix Generic 
# |
# | NOTES
# |
# | HISTORY
# | 200.0 Creation (8:34 AM 5/9/2017) 
# | See __END__ for complete history 
# +===========================================================================+

package CorePSD::Signature; 

sub sig
{
	my $class = shift;
	my ($file) = @_; 
	my $sigName; 
	my $count = 0; 
	
	open (my $fh, '<', $file ) || die "  Signature.pm: unable to open XML: $file $! \n"; 
		my @file = <$fh>;
	close $fh;

	my (@startTags) = grep{ $file[$_] =~ /<sig\sname/ } 0.. $#file; 
  
	foreach my $k (@startTags)
	{
    my $currLn = $k; 
    until ($file[$currLn] =~  /\<\/sig\>/)
    {
        my $l = $file[$currLn]; 
        next if ($l =~ /\<\/sig\>/); 
        $l = trim($l);
        if ( $l =~ /^<sig\sname/ ) 
        {
          ($sigName) = $l =~ /<sig\sname\=\"(.+?)\"/;
          $id = $sigName;
        }
        elsif ( $l =~ /^<log/ ) 
        {
          my ($var) = $l =~ /<log\s.+?>(.+?)</;
          push @{$sig{$id}->{LOGS}}, $var;
        }
        elsif ( $l =~ /^<error/ ) 
        {
          my ($var) = $l =~ /<error\s.+?>(.+?)</;
          push @{$sig{$id}->{ERRORS}}, $var;
        }
        elsif ( $l =~ /^<tsformat/ ) 
        {
          my ($var) = $l =~ /<tsformat\s.+?>(.+?)<\/tsformat/;
          push @{$sig{$id}->{TSFORMAT}}, $var;
        }
        elsif ( $l =~ /^<message/ ) 
        {
          ($sig{$id}->{MESG}) = $l =~ /<message>(.+?)<\/message\>/;
        }
        elsif ( $l =~ /^<docid/ ) 
        {
          ($sig{$id}->{DOCID}) = $l =~ /<docid>(.+?)<\/docid>/;
        }
        elsif ( $l =~ /^<global/ )
        {
          if ( $l =~ /=OSCMD_OP/ )
          {
            my $cmd = $l;
            $cmd =~ s/<global\s+id="\d+">(.+)<\/global>/$1/g;
            my @spl = split('=OSCMD_OP', $cmd );

            #print "cmd $cmd\n"; <STDIN>; #debug
            #print "spl 0: $spl[0]\n"; #debug
	    #print "spl 1: $spl[1]\n"; #debug
            if ( $spl[0] ne '' ) {
	      #print "global found: $spl[0]\n"; #debug
              if (! exists $main::globals{$spl[0]} ) {
                $main::globalCmds{$spl[0]} = $spl[1];
                $main::globals{$spl[0]} = 'Y';
              }
              else
              {
                logger("Global exists already: sig $id: $spl[0]");
              }
            }
          }
#else
#{
  #print "NO ENTRO\n"; #debug
#}
        }
        elsif ( $l =~ /^<condition/ )
        {
          my ($var) = $l =~ /<condition\s.+?>(.+?)<\/condition/;
          push @{$sig{$id}->{CONDITIONS}}, $var; 
        }

      $currLn++; 
     }#end currLn;
	}

		 #use Data::Dumper; 
                 #print "sig dump\n"; #debug
		 #print Dumper(%sig); <STDIN>; 
                 #print "globals dump\n"; #debug
		 #print Dumper(%main::globals); <STDIN>; #debug
                 #print "globalCmds dump\n"; #debug
		 #print Dumper(%main::globalCmds); <STDIN>;  #debug
		# print "==============\n"; 
		# bless $sig, $class; 
		return bless { %sig }, $class;
}#end sub sig 


# +-------------------------------------------------------------------+
# | sub: trim 
# +-------------------------------------------------------------------+
# | Desc: trims leading & trailing whitespace 
# +-------------------------------------------------------------------+
# | Args: line to trim 
# +-------------------------------------------------------------------+
# | Returns: trimmed line
# +-------------------------------------------------------------------+
sub trim
{
	my ($ln) = @_; 
	$ln =~ s/^\s+//; 
	$ln =~ s/\s$//; 
	return($ln);
}#END: trim 


1;

__END__ 

+===========================================================================+
 FILENAME: Signature.pm

 PLATFORM: Unix Generic 

 NOTES: 
 -Code to process signature XML for WLSU 
 
 HISTORY

 200.0 Creation (08-AUG-2016) 
 200.1: KJHARRIS: Updated loop as last sig was getting left out, not iterating as expected. 
                 
+===========================================================================+
