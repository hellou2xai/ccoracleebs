# $Id: WLSD.pm 200.6 11:39 AM 1/11/2018 kjharris $
# *===========================================================================+
# |  Copyright (c) 2016 Oracle Corporation, Redwood Shores, California, USA  
# |  All rights reserved 
# |  Created by Oracle Support Proactive Services  
# +===========================================================================+
# | See end of file for complete details / history 
# +===========================================================================+


# +---------------------------------------------------------------------------+
# | sub: logger
# +---------------------------------------------------------------------------+
# | Desc:  
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub logger
{
  my ($mesg) = @_;
  open(my $fh, ">>", $main::Log ) || die cluck "  ERROR: sub logger(): Unable to open \"$main::Log\": $! \n"; 
  print $fh "\n####<",(strftime "%b %d, %Y %H:%M:%S %Z", localtime), ">##\n";
  print $fh qq($mesg \n####END OF MESG\n\n); 
  close $fh; 
  return(); 
}#END: logger

# +---------------------------------------------------------------------------+
# | sub: wlslog
# +---------------------------------------------------------------------------+
# | Desc: mimic wlslog.sh 
# | will also mash-up logs together in 
# | order in which errors occured, across all 
# | *.log's found 
# | in the $EBS_DOMAIN_HOME 
# +---------------------------------------------------------------------------+
# | Args: the outFile to write to 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub wlslog 
{
  #fh to write the output to (HTML out) 
  my ($fh) = @_; 
  my %logs; 
  my %logs2; #store printable output 
  my %OHSLogs; #store error_log / access_log 
  my %select; #store epoch-date correlation
  my %noErrors; 
  my $cnt = 0; 
  my $cntOHS = 0; 
  my $exCnt = 0; 
  my $totErr = 0; 
  my $epoc = time();;

  #######
  # managed server logs 
  ####################################

  my %allLogs; #this hash gets passed to the signature checking sub

  my $searchDirX = $ENV{EBS_DOMAIN_HOME};
  
  $searchDirX = $main::searchDir if length($main::searchDir) > 1;

  find (sub 
  {
    #return unless $_ =~ /\.log\d*$/ && -f $_; 
    return unless $_ =~ /^(?:(?!access).)*(log|out)\d*$/ && -f $_; 
    my $sb = stat($File::Find::name);
    my $mtime = scalar $sb->mtime;

    my $fAgeSec = $epoc - $mtime;
    #if ($fAgeSec<= $main::mtime_max ) # last 48 hours only
    #picks file modified only 2 days prior to main::min to optimize search
    if ($mtime >= $main::min - (2*86400) ) {
      #print "FOUND: $File::Find::name, $fAgeSec\n"; <STDIN>;

      my $ck = checkForTS($_); 
      if ($ck == 0) {
        $cnt++;
        $logs{$cnt}->{LOG} = $File::Find::name; 
        $allLogs{$cnt}->{LOG} = $File::Find::name;
      }
    }
  }, $searchDirX);


  foreach my $i (sort {$a <=> $b} keys %logs) 
  {
    use Time::HiRes qw(time);
    my $t = time;
    my $ts = strftime "%Y-%m-%d %H:%M:%S", localtime $t;
    $ts .= sprintf ".%03d", ($t-int($t))*1000; 
  
    (my $bn = $logs{$i}->{LOG}) =~ s/$ENV{EBS_DOMAIN_HOME}/\$EBS_DOMAIN_HOME/; 
    print qq(  

  +---------------$ts----------------------------------+
   INFO: wlslog(): working on:\n   $bn
  +------------------------------------------------------------------------+\n); #<STDIN>;
    logger("wlslog(): Found Log $bn"); 
    my @arr;
    my @arrEx;
    
    #getTimeSlice gets all the log lines within the given time frame
    my ($slice) = getTimeSlice($logs{$i}->{LOG});
    #if $slice = 1, the .log is not a recognized log.. skip it 
    if ($slice == 1) 
    {
      print "  INFO: Skipping $logs{$i}->{LOG} (no usable timestamps found)\n";
      logger("wlslog(): SKIPPED Log $bn (no usable timestamps found)"); 
      delete($logs{$i}->{LOG}); 
      delete($allLogs{$i}->{LOG}); 
      next;
    }

    #narrow the lines from the slice to those that have errors 
    my (@indx) = grep{ ${$slice}[$_] =~ /\<Error\>|\<Critical\>|\<Alert\>|\<Emergency\>|\[ERROR\]/ } 0..$#{$slice};  
    #get the indices for the exceptions: 
    my @indxEx = grep{ ${$slice}[$_] =~ /exception/i } 0..$#{$slice};

    #we know the index for the errors because of the grep ^, now we can pull the exact 
    #line from the @file array, check the ep time and store if a good ep time: 
    foreach my $i (@indx)
    {
      my ($lnNo, $ln) = split('::',$$slice[$i]);
      push @arr, qq([LINE#$lnNo]&nbsp;$ln);
    }
    undef @indx; 
    
    my $indxExLarge = 0; 
    my $exCountNow = scalar @indxEx; 
    if (scalar @indxEx > 25) 
    {
      my @indxEx25 = @indxEx[($#indxEx - 25) .. $#indxEx];
      undef @indxEx; 
      @indxEx = @indxEx25; 
      $indxExLarge = 1; 
    }

    # 10:04 AM 5/24/2017: 
    # If we have more than 25 exceptions, print the following message: 
    if ($indxExLarge) 
    {
      push @arrEx, qq(  INFO: $0: More than 25 exceptions found. [Total Exceptions Found: $exCountNow]<br><br>Showing <b>only</b> the last 25 found. Check the log for all exceptions.); 
    }
    
    foreach my $i (@indxEx) 
    {
      my ($lnNo, $ln) = split('::',$$slice[$i]);
      push @arrEx, qq([LINE#$lnNo]&nbsp;$ln);
    }
    undef @indxEx;
    
    #print the mesg twice at the start /end of the table. 
    if ($indxExLarge) 
    {
      push @arrEx, qq(  INFO: $0: More than 25 exceptions found. [Total Exceptions Found: $exCountNow]<br><br>Showing <b>only</b> the last 25 found. Check the log for all exceptions.);  
    }
    
    $exCnt = $exCnt + scalar(@arrEx); 
    $totErr = $totErr + scalar(@arr); 

    if ($#arrEx > -1) # exceptions 
    {
      $logs{$i}->{EX_COUNT} = scalar @arrEx; 
      @{$logs{$i}->{ARREX}} = @arrEx; 
    }
    if ($#arr > -1) # error-critical-alert-emergency 
    {
      $logs{$i}->{ERROR_COUNT} = scalar @arr; 
      @{$logs{$i}->{ARR}} = @arr;
    }
    #if there's no errors found, delete %logs entry 
    # if ($#arr2 == -1 && $#arr == -1) 
    if ($#arr == -1 && $#arrEx == -1) 
    {
      $noErrors{$i}->{LOG} = $logs{$i}->{LOG}; 
      delete($logs{$i});
    }
    else 
    {
      foreach my $ln (@arr) 
      {
        next if length($ln) < 5; 
        my $ep; 
        my $date; 
        if ( $ln =~ /####<\w{3}\s{1,2}\d{1,2},/ )
        {
          $ep = getEpochManagedServerLog($ln);
          ($date) = $ln =~ /(\w{3}\s\d{1,2}\,\s\d{4}\s\d{1,2}\:\d{2}\:\d{2}\s\w{2}\s\w{3})/;
        }
        elsif ( $ln =~ /\[\d{4}-\d{2}-\d{2}T\d{2}/ ) 
        {
          $ep = getEpochErrorLog($ln);
          # ($date) = $ln =~ /^\[(\d{4}-\d{2}-\d{2}.+?)\]/;
          $date = reformatDate($ln); 
        }

        $ln = "[Log: $logs{$i}->{LOG}]" . "::[Date: $date]::" . $ln; 
        push @{$logs2{$ep}}, $ln;
        $select{$ep} = $date; #this is for drop down Time "from" "to" HTML inputs 
      }
    }
    undef @arr; 
    undef @arrEx; 
    #print "PERF TIME2:\n-----\n", strftime('%d-%b-%Y %H:%M:%S', localtime()), "\n------\n"; 
  }#END foreach (process WLS managed logs and WLS diagnostic logs 
  
  #get the latest access_log & error_log
  #to be sure we got the right error log, we need the exact log name 
  # get the context value for "s_ohs_component"
  my $cnt = 0; 
  my $errorLog = quotemeta(getContextValue('s_ohs_component') . '.log');
  
  $searchDirX = $ENV{IAS_ORACLE_HOME} . '/instances/';
  $searchDirX = $main::searchDir if length($main::searchDir) > 1;
  
  #get the error_log: 
  find (sub 
  {
    return unless $_ =~ /^$errorLog$/ && -f $_;
    #return unless $_ =~ /log(\.\d+)?$/ && -f $_;
    #return unless $_ =~ /^(?:(?!access).)*(log|out)\d*$/ && -f $_; 
#    my $sb = stat($File::Find::name);
#    my $mtime = scalar $sb->mtime;

#    my $fAgeSec = $epoc - $mtime;
#if ( $File::Find::name =~ /opmn\.log/ ) {
#    print "FOUND: $File::Find::name, fAgeSec:$fAgeSec, epoc:$epoc, mtime:$mtime\n";
#<STDIN>;
#}
    #if ($fAgeSec<=86400) { # last 48 hours only
      $OHSLogs{ERROR_LOG} = $File::Find::name;
    #}
  }, $searchDirX);

  #get all access_logs within a time range. 
  #find the time range based off the managed server logs 

  #don't need this anymore since we are using a time window 8:51 AM 3/9/2017 
  # my ($startTime, $endTime) = getMaxMinEPTime(\%logs2); 
  
  my ($access_logs) = getAccessLogs();
  
  print "  INFO: Found: ", scalar @$access_logs, " access_logs within the specified time window.\n";
  my $cnt; 
  foreach my $i (@$access_logs) 
  {
    $cnt++;
    $OHSLogs{$cnt} = $i;
  }

  my $elCnt = 0; #error log count 
  my $alCnt = 0; #access log count 

  foreach my $i (keys %OHSLogs) 
  {
    my @accessLogErrs; 
    my ($slice) = getTimeSlice($OHSLogs{$i});
    if ( $#{$slice} > -1 && basename($OHSLogs{$i}) =~ /^access_log/ )
    {
      (@accessLogErrs) = grep { ${$slice}[$_] =~ /\s[45]\d{2} -$/ } 0..$#{$slice};
      $alCnt = $alCnt + (scalar @accessLogErrs); 
      foreach my $k (@accessLogErrs) 
      {
        (my $err = $$slice[$k]) =~ s/(\s[45]\d{2}) -$/<font color='red'>$+<\/font>/;
        # print "ln is $$slice[$i] \n"; 
        my $j = $k + 1; #lnNo 
        $err =~ s/\d+?:://g; 
        my $ep = getEpochAccessLog($$slice[$k]);
        push @{$OHSLogs{$i}->{ACCESS_LOG}}, qq(<tr><td><font class="al_line">[LINE#$j]<span class="ttt">OHS Access Log</span></font>&nbsp;$$slice[$k]</td></tr>\n);
        push @{$logs2{$ep}}, qq(<tr id="$ep" class="access_log"><td><font class="al_line">[LINE#$j]<span class="ttt">OHS Access Log</span></font>&nbsp;$err</td></tr>\n); 
      }
    }
    elsif ( $#{$slice} > -1 && basename($OHSLogs{$i}) =~ /^EBS_/ )
    {
      #all lines in @slice are errors in regards to the error_log
      $elCnt = $elCnt + (scalar @{$slice}); 
      foreach my $ln (@{$slice}) 
      {
        next if length($ln) < 10; 
        my $lnNo; 
        ($lnNo, $ln) = split('::', $ln); 
        my $ep = getEpochErrorLog($ln); 
        if ($ln =~ /\[ERROR\:/)
        {
          $elCnt++; 
          push @{$logs2{$ep}}, qq(<tr id="$ep" class="error_log"><td><font class="el_line">[LINE#$lnNo]<span class="ttt">OHS Error Log: $errorLog</span></font>&nbsp;$ln</td></tr>\n);
        }
        else 
        {
          push @{$logs2{$ep}}, qq(<tr id="$ep" class="error_log"><td><font class="el_line">[LINE#$lnNo]<span class="ttt">OHS Error Log: $errorLog</span></font>&nbsp;$ln</td></tr>\n);
        }
      }
    }
  }

  adrLogsToManifest();

  #this is the logical place to check for sigs as all the errors 
  # which fit into the time window are in @{$logs2{$ep}} 
  #
  
  ###########
  ## check sigs against @{$logs2{$ep}} 
  ########################################
  #this can create a .tmp file which we can pull into the 
  # right tab later 
  
  #send in lists of logs (OHS Error / Access / Managed Server) 
  #%logs is: the list of managed server logs 
  #%OHSLogs: access_logs + error_log 
  #%logs2 is sorted output.. we don't need to send that.
  checkSigs(\%allLogs, \%OHSLogs);
  # use Data::Dumper; 
  # open(my $fh2, '>', 'dump');
    # print $fh2 Dumper(%select);
  # close $fh2;

  ##################################################################
  ##################################################################
  ##################################################################
  # Summary 
  
  #could add some pop-ups here for help about where these logs came from / what they are..
  # https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_tooltip 

  print "  INFO: Printing HTML report.. \n"; 
  
  ######
  ## start sub-buttons 
  #####################
  print $fh qq(
  <div class="divItem">
  &nbsp;<input type="button" onclick="displayWLSLogTable(this,'logTable_1');" value="Logs Summary"><br><br>
  &nbsp; 
  <input type="button" onclick="displayWLSLogTable(this, 'logTable_4');" value="Chronological View of Logs">
  &nbsp; 
  <input type="button" onclick="displayWLSLogTable(this, 'logTable_2');" value="Errors|Alerts">
  &nbsp; 
  <input type="button" onclick="displayWLSLogTable(this, 'logTable_3');" value="Exceptions Found">
  &nbsp; 
  <input type="button" onclick="displayWLSLogTable(this, 'logTable_5', 'show');" value="OHS Error Log">
  &nbsp;
  
  ); 
  
  #11:50 AM 1/11/2018 changed behaivor to print access log info always 
  # print $fh qq(<input type="button" onclick="displayWLSLogTable(this,'logTable_6');" value="OHS Access Log Errors (400/500 Codes)">) unless ($main::target eq 'y'); 
  print $fh qq(<input type="button" onclick="displayWLSLogTable(this,'logTable_6');" value="OHS Access Log Errors (400/500 Codes)">); 
  
  
  print $fh qq(\n</div> ); 
  #printing the first one like this so it's not hidden:
  #summary table 
  print $fh qq(
  <div id="logTable_1" class="divItem" style="display:block"> 
  <table style="display:block">
  <tbody>
    <tr><th>Error Type</th><th>Count</th></tr>
    <tr><td>Exceptions [WLS Managed Server Logs]</td><td>$exCnt</td></tr>
    <tr><td>&quot;&lt;ERROR&gt;&quot;, &quot;&lt;CRITICAL&gt;&quot;, &quot;&lt;ALERT&gt;&quot;, &quot;&lt;EMERGENCY&gt;&quot; Messages [WLS Managed Server Logs]</td><td>$totErr</td></tr>
    <tr><td>OHS Errors [OHS Error Log] - Lines containing &quot;[ERROR:]&quot; </td><td>$elCnt</td></tr>
    <tr><td>Access Error Codes [OHS Access Log] - Lines with 400/500 series HTTP codes</td><td>$alCnt</td></tr>
  </tbody>
  </table><br> 
    ); 
  
  #here print log meta data 
  if (keys %logs)
  {
    my $cnt = keys %logs; 
    print $fh qq(
  <table>
   <tbody> 
    <tr><th>Managed Server Logs Found With Errors or Exceptions [$cnt]</th><th>Error Count</th><th>Exception Count</th><th>Log Last Modified</th></tr>);
    foreach my $i (sort {$logs{$b}->{ERROR_COUNT} <=> $logs{$a}->{ERROR_COUNT}} keys %logs) 
    {
      my $ts = getLogMetaData($logs{$i}->{LOG}); 
      $logs{$i}->{EX_COUNT} = 0 if ! length($logs{$i}->{EX_COUNT}); 
      $logs{$i}->{ERROR_COUNT} = 0 if ! length($logs{$i}->{ERROR_COUNT}); 
      print $fh qq(<tr><td>$logs{$i}->{LOG}</td><td>$logs{$i}->{ERROR_COUNT}</td><td>$logs{$i}->{EX_COUNT}</td><td>$ts</td></tr>);
    }
    print $fh qq(
   </tbody> 
   </table><br><!-- END managed server logs --> 
    
    ); 
  }
  else
  {
    print $fh qq(
    <table>
    <tbody>
     <tr><th>[No Logs Found With Errors or Exceptions]</th></tr>
    </tbody>
    </table><br> 
     
     );
  }
  
  if (keys %noErrors)
  {
    my $cnt = keys %noErrors;
    print $fh qq(
    <table>
     <tbody> 
    <tr><th>Managed Server Logs Found <strong>Without</strong> Errors [$cnt]</th><th>Log Last Modified</th></tr>);
    foreach my $i (sort {$a <=> $b} keys %noErrors) 
    { 
      my $ts = getLogMetaData($noErrors{$i}->{LOG}); 
      print $fh qq(      <tr><td>$noErrors{$i}->{LOG}</td><td>$ts</td></tr>); 
    } 
    print $fh qq(
     </tbody>
    </table><br><!-- END Managed Server Logs without errors --><br> 
    ); 
  }
  else 
  {
    print $fh qq(
   <table>
    <tbody>
     <tr><th>[No Logs Found Without Errors]</th></tr>
    </tbody>
   </table><br>); 
  }
  
  print $fh qq(</div>\n\n   <!-- END log_Table1 -->); 
  #end summary table 
  
  print "..."; 
  
##############
## <error><alert><critical><emergency>
########################################
  
  ##### Section 2: Errors | Alerts ##### 
  printHiddenTable($fh, 'logTable_2', 'start'); 
  #rows for errors 
  # if we have some errors 
  
  if ($totErr > 0)
  {
    print $fh qq(<tr><td>[Search for Occurrences of: &quot\;[ERROR]&quot\;, &quot\;&lt\;Error&gt\;&quot\;, &quot\;&lt\;Critical&gt\;&quot\;,&quot\;&lt\;Alert&gt\;&quot\;,&quot\;&lt\;Emergency&gt\;&quot\; ]</td></tr>); 
    #check log error count, if yes then print <TH> for 
    # log name, then print the errors in <TD>
    foreach my $i (sort {$logs{$b}->{ERROR_COUNT} <=> $logs{$a}->{ERROR_COUNT}} keys %logs) 
    {
      print $fh qq(\n<tr><th>$logs{$i}->{LOG}</th></tr>\n); 
      if (scalar @{$logs{$i}->{ARR}} > 0)
      {
        foreach my $ln (@{$logs{$i}->{ARR}})
        {
          $ln =~ s/>/&gt;/g; 
          $ln =~ s/</&lt;/g; 
          $ln =~ s/(\[ERROR\]|&lt;Error&gt;|&lt;Critical&gt;|&lt;Alert&gt;|&lt;Emergency&gt;)/<font color="red"><b>$+<\/b><\/font>/ig; 
          $ln =~ s/(\[LINE#\d+?\])/<b>$+<\/b>/g;
          $ln = qq(<tr class='managed_log'><td>$ln</td></tr>);
          print $fh qq(\n$ln\n); 
        }
      }
      else 
      {
        print $fh qq(<tr><td>[No Occurrences of: &quot\;[ERROR]&quot\;, &quot\;&lt\;Error&gt\;&quot\;, &quot\;&lt\;Critical&gt\;&quot\;,&quot\;&lt\;Alert&gt\;&quot\;,&quot\;&lt\;Emergency&gt\;&quot\; ]</td></tr>); 
      }
    }
  }
  else 
  {
    print $fh qq(<tr><th>[NO LOGS WITH ERRORS for the time window targeted]<br>[No Occurrences of: &quot\;[ERROR]&quot\;, &quot\;&lt\;Error&gt\;&quot\;, &quot\;&lt\;Critical&gt\;&quot\;,&quot\;&lt\;Alert&gt\;&quot\;,&quot\;&lt\;Emergency&gt\;&quot\; ]</th></tr>); 
  }
  printHiddenTable($fh,'','end'); 
  print "...."; 
######
## Start of Table 3 
## Exceptions 
#######################

  printHiddenTable($fh, 'logTable_3', 'start'); 
  ###### Section 3: Exceptions ######## 
  if ($exCnt > 0)
  {
    #check log error count, if yes then print <TH> for 
    # log name, then print the errors in <TD>
    foreach my $i (sort {$logs{$b}->{EX_COUNT} <=> $logs{$a}->{EX_COUNT}} keys %logs) 
    {
      if (scalar @{$logs{$i}->{ARREX}} > 0)
      {
        print $fh qq(<tr><th>$logs{$i}->{LOG}</th></tr>);
        foreach my $ln (@{$logs{$i}->{ARREX}})
        {
          if ($ln =~ /INFO:/)
          {
            #in the case that the we had more than 25 execptions, then "info" line
            # is the line we print in the HTML to let the user know we 
            # didn't print all the lines 
            print $fh qq(<tr><td class="hlt">$ln</td></tr>); 
            next; 
          }
          my ($errs) = _checkErrors($ln, $logs{$i}->{LOG});
          $ln =~ s/>/&gt;/g; 
          $ln =~ s/</&lt;/g; 
          $ln =~ s/(exception)/<font color="red"><b>$+<\/b><\/font>/ig; 
          $ln =~ s/(\[LINE#\d+?\])/<b>$+<\/b>/g; 
          print $fh qq(<tr><td>$ln); 
          #print hidden / expandable DIV if we have more lines to show 
          if (scalar @$errs > 0) 
          {
            #print a link to expand more errors 
            # <a class="detail" href="javascript:;" onclick="displayItem(this, 'AE154EE4CF');">APPS.FFP56053_01012000 [PACKAGE BODY]</a>
            my $rs = genRandString(); 
            print $fh qq(<a id='a_$rs' class="detail" href="javascript:;" onclick="displayMore(this, '$rs');">[Show More Lines]</a>); 
            printHiddenTable($fh, $rs, 'start'); 
            print $fh qq(<tr><td>$_</td></tr>\n) foreach @$errs; 
            print $fh qq(<tr><td><a class="detail" href="javascript:;" onclick="displayMore('a_$rs', '$rs', 'HIDE');">[Hide]</a></tr></td>\n); 
            printHiddenTable($fh, $rs, 'end'); 
          }
          print $fh qq(\n</td></tr>); 
        }
      }
      # else 
      # {
        # print $fh qq(<tr><td>[NO EXCEPTIONS]</td></tr>); 
      # }
    }
  }
  else 
  {
    print $fh qq(<tr><th>[NO EXCEPTIONS]</th></tr>); 
  }
  printHiddenTable($fh,'','end'); 
######
## Start of Table 4 
## Chronological Table  
#######################
  print "...."; 
  #SECTION 4 Chronological Log Mash up 
  printHiddenTable($fh, 'logTable_4', 'start');
  print $fh qq( <tr class='toolBar' style="display: block"><td>
  
  <a class="filterHelp" href="javascript:;" onclick="displayItem(this, 'filterHelp1');">[Help?]</a>

  <!-- ################################################### --> 
  <!-- <input type="text" id="SearchErrorLogs" style="color: rgb(136, 136, 136);" value="  [search]  " onfocus="inputFocus(this)" onblur="inputBlur(this)" onkeyup="findRow('logTable_4','.logRow','SearchErrorLogs');">
  
  <input type="button" onclick="resetSearch('logTable_4','.logRow','SearchErrorLogs');" value="Clear Search">
  &nbsp;&nbsp; Toggle Logs:&nbsp; -->
  <!-- ################################################### --> 
  ); 
  
    #print the row for the filters 
  _printFilterRow($fh);
  
  print $fh qq( 
 <br> <hr> <br> 
 <strong>Toggle Logs:&nbsp;</strong> 
 <input id="accessLogButton" type="button" onclick="filterTable(this);" value="Show Access Log Lines">
 &nbsp; &nbsp; 
 <input id="errorLogButton" type="button" onclick="filterTable(this);" value="Show OHS Error Log Lines">
 <br> <hr> <br> 
 <input id="resetAllButton" type="button" onclick="filterTable(this);" value="Reset All Filters">
 </td></tr>
 <!-- To be added later: 4:31 PM 3/4/2017
 <span>Currently Showing: <span id="CurrShow_logTable4">ALL Error Rows</span></span> 
 </td></tr>
 updating WLSD_2017-03-03_211533.html to show a count of how many rows are being displayed --> 

  );
  
  _printFilterRowHelp($fh);

  my $detect = 0; 
  foreach my $ep (sort {$a <=> $b} keys %logs2) 
  {
    $detect = scalar(@{$logs2{$ep}}) + $detect; 
  } 
  
  if ($detect == 0)
  {
    push @{$logs2{1}}, qq(
    <tr class='managed_log' id='1' style="display: table-row"><td><strong>INFO: </strong>[No Managed Log Errors Found]</td></tr>); 
  }

  my @errorLog; #store the error_log lines for use in logTable_5 in the next section 
  foreach my $ep (sort {$a <=> $b} keys %logs2) 
  {
    $alt++; 
    foreach my $ln (@{$logs2{$ep}})
    {
      #if ln =~ :: we have a managed server log 
      # else we have an access_log or error_log 
      if ($ln =~ /::/)
      {
        # use Data::Dumper; 
        # print Dumper(%logs2); <STDIN>; 
        my ($log, $date, $ln1) = split('::', $ln);
        #check for more errors
        my $passLog; 
        $passLog = $+ if $log =~ /^\[Log:\s(.+)\]$/;
        my ($errs) = _checkErrors($ln1, $passLog);
        print $fh qq(\n<tr class='managed_log' id='$ep' style="display: table-row"><td>\n);
        print $fh qq(\n<hr><strong>$log</strong><hr><br>\n); 
        print $fh qq(\n$date\n); 
        $ln1 =~ s/>/&gt;/g; 
        $ln1 =~ s/</&lt;/g; 
        $ln1 =~ s/(&lt;Error&gt;|&lt;Critical&gt;|&lt;Alert&gt;|&lt;Emergency&gt;)/<font color="red"><b>$+<\/b><\/font>/ig; 
        $ln1 =~ s/(\[LINE#\d+?\])/<br><br><b>$+<\/b>/g;
        print $fh qq($ln1<br>); 
        #print hidden / expandable DIV if we have more lines to show 
        if (scalar @$errs > 0) 
        {
          my $rs = genRandString(); 
          print $fh qq(<a id='a_$rs' class="detail" href="javascript:;" onclick="displayMore(this, '$rs');">[Show More Lines]</a>); 
          printHiddenTable($fh, $rs, 'start'); 
          print $fh qq(<tr><td>$_</td></tr>\n) foreach @$errs; 
          print $fh qq(<tr><td><a class="detail" href="javascript:;" onclick="displayMore('a_$rs', '$rs', 'HIDE');">[Hide]</a></tr></td>\n); 
          printHiddenTable($fh, $rs, 'end'); 
        }
        print $fh qq(</td></tr>\n\n);
      }
      else 
      {
        #just print, access_log & error_log should be pre-formated
        push @errorLog, $ln if $ln =~ /el_line/; 
        print $fh qq($ln); 
      }
    }
    delete($logs2{$ep}); 
  }    
  printHiddenTable($fh,'','end'); 
  #END Mash up 
  print "....."; 
######
## Start of Table 5: 
## error_log 
###################
  printHiddenTable($fh, 'logTable_5', 'start');

  print $fh qq(<tr><td><b>TIP: </b>Lines are Filtered by the targeted time window. Complete Log is included in the WLSU Zip File. </td></tr>); 
  print $fh qq(<tr><th>Line from $OHSLogs{ERROR_LOG}</th></tr>);
  
  foreach my $ln (@errorLog) 
  {
    #print pre-formatted error_log lines 
    print $fh $ln; 
  }
  if (scalar @errorLog == 0) 
  {
    print $fh qq(<tr><td colspan="2">[No Error Log Entries in the targeted time window: ); 
    print $fh strftime '%d-%b-%Y %H:%M:%S', localtime $main::min;
    print $fh qq( to: ); 
    print $fh strftime '%d-%b-%Y %H:%M:%S', localtime $main::max;
    print $fh qq(]</td></tr>);
  }

  undef @errorLog; 
  printHiddenTable($fh,'','end'); 
  print "......";
######
## End Table 5 
##################

######
## Start of Table 6: 
## access_log 
###################

  printHiddenTable($fh, 'logTable_6', 'start'); 
  foreach my $i (keys %OHSLogs) 
  {
    next unless $OHSLogs{$i} =~ /access_lo.+/; 
    print $fh qq(<tr><th>$OHSLogs{$i}</th></tr>);
    foreach my $ln (@{$OHSLogs{$i}->{ACCESS_LOG}}) 
    {
      print $fh $ln; #line is pre-formatted for HTML 
    }

    if (scalar @{$OHSLogs{$i}->{ACCESS_LOG}} == 0)
    {
      print $fh qq(<tr><td colspan="2">[No Access Log Errors within targeted time window: ); 
      print $fh strftime '%d-%b-%Y %H:%M:%S', localtime $main::min;
      print $fh qq( to: ); 
      print $fh strftime '%d-%b-%Y %H:%M:%S', localtime $main::max;
      print $fh qq(]</td></tr>);
    }
  }
  printHiddenTable($fh,'','end'); 
  print "......\n";
######
## End Table 6
##################


#################
## end of logs / log_tables 
##########################
  
  printBackToTop($fh);
  my @zips; 
  foreach my $i (sort {$a <=> $b} keys %logs)
  {
    push @zips, $logs{$i}->{LOG};
  } 
  foreach my $i (sort {$a <=> $b} keys %noErrors)
  {
    push @zips, $noErrors{$i}->{LOG};
  }
  foreach my $i (sort {$a <=> $b} keys %OHSLogs)
  {
    push @zips, $OHSLogs{$i};
  } 

  printToManifest('',\@zips); 
  
  return($totErr); 
##### 
## Private Subs 
#####################

# +---------------------------------------------------------------------------+
# | sub: _checkErrors
# +---------------------------------------------------------------------------+
# | Desc: Check a log to see if there's more errors 
# +---------------------------------------------------------------------------+
# | Args: a log line in the following format: 
# |
# | [Log: [[ full path to log ]] 
# |   [Date: Jan 26, 2017 4:41:32 PM EST]
# | 
# | [LINE#8]####<Jan 26, 2017 4:41:32 PM EST> <Error>   [[ Error Text ]] 
# | 
# +---------------------------------------------------------------------------+
# | Returns: array
# +---------------------------------------------------------------------------+
sub _checkErrors 
{
  my ($errLn, $log) = @_;
  my @errors; 
  my $lnNo = $+ if $errLn =~ /\[LINE\#(\d.+?)\]/; 
  my $fh3; 
  open ($fh3, '<', $log ) || die cluck "  ERROR: _checkErrors() Cannot open \"$log\": $! \n"; 
  my $ln; 
  while ($ln = <$fh3>) 
  {
    next until $. == ($lnNo + 1);
    #if we come in and have a line with ^#####, then the next 5 lines is sufficient 
    # for context. But if we have a non "#####" line, we *probably* have an 
    # excep of some kind, so keep showing lines until we finish the error stack 
    if ($ln =~ /^####/)
    { 
      $ln = htmlF($ln);
      push @errors, "<span>[Showing 5 lines of log]</span><br>";
      for (my $i = 0; $i < 5; $i++) 
      { 
        push @errors, "<strong>[LINE#$.]</strong>" . $ln;
        $ln = <$fh3>;
        $ln = htmlF($ln);
        # last if EOF($fh3);
      }
      close $fh3; 
      return (\@errors); 
    }
    else 
    {
      while ($ln !~ /^####|^\[\d{4}/ && length($ln)) 
      {
        push @errors, "<strong>[LINE#$.]</strong>" . $ln;
        $ln = <$fh3>;
        $ln = htmlF($ln);
        last if eof($fh3);
      }
      close $fh3;
      return (\@errors);
    }
  }#end While

}#END: _checkErrors


# +---------------------------------------------------------------------------+
# | sub: htmlF (htmlFriendly) 
# +---------------------------------------------------------------------------+
# | Desc: scrubs out symbols that are problematic to print in HTML code
#         turns "<" into &lt; ..">" into "&gt;" 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub htmlF
{
  my ($ln) = @_; 
      $ln =~ s/>/&gt;/g; 
      $ln =~ s/</&lt;/g; 
  return($ln); 
}#END: htmlF


# +---------------------------------------------------------------------------+
# | sub: 
# +---------------------------------------------------------------------------+
# | Desc: 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub _printFilterRow 
  {
    my ($fh) = @_; 
    
  #Loop thru rows, printing out epoch time to "value", print out 
  # real time to the display text 
  #we want to skip printing the latest time in the first drop down
  # and skip printing the earliest time in the 2nd drop down 
  # which will avoid user error by selecting params resulting in zero rows 
  
  #print first list: 
  my $max = getMaxHashID(\%select); 
  print $fh qq(<!-- <tr><td class="toolBar"> --> 
  
  <strong>Apply Time Filter View:</strong><br><br> 
  <span><strong>&nbsp;Earliest:&nbsp;</strong></span><select id="startTime" name="startTime"> \n); 
  
  print $fh qq(<option value="0">ALL</option>\n); 
  
  foreach my $ep (sort {$a <=> $b} keys %select) 
  { 
    print $fh qq(\n <option value="$ep">$select{$ep}</option>\n) unless $ep == $max; 
  } 
  print $fh qq(\n </select>

  <span>&nbsp;<strong>To:</strong>&nbsp;</span>
  <select id="endTime" name="endTime">
  <option value="9999999999">ALL</option>
    );
   
  foreach my $ep (sort {$a <=> $b} keys %select) 
  {
    # $cnt++; 
    # next if $cnt == 1; 
    print $fh qq(\n <option value="$ep">$select{$ep}</option>\n); 
  }
  print $fh qq(\n </select>\n); 
  print $fh qq(
  &nbsp;<input id="createFilterButton" type="button" onclick="filterTable(this);" value="Apply Time Filter">
  &nbsp;<input id="clearFilterButton" type="button" onclick="filterTable(this);" value="Clear Time Filter">\n);
  }#END: _printFilterRow

# +---------------------------------------------------------------------------+
# | sub: _printFilterRowHelp
# +---------------------------------------------------------------------------+
# | Desc: prints a tr of help for the chrono tab / filter buttons 
# +---------------------------------------------------------------------------+
# | Args: file handle of the html output 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub _printFilterRowHelp 
  {
    my ($fh) = @_; 
    print $fh qq(
  <!-- Filter Row Help --> 
  <tr id="filterHelp1" class="helpRow" style="display: none"><td>
  
  <a class="filterHelp" href="javascript:;" onclick="displayItem(this, 'filterHelp1');">[Hide]</a>
  <ul>
    <li>Apply Time Filter View:
      <br>
      Allows filtering of logs by a start and end time. If there is no list of values in the drop down, then no errors were found in the WLS Managed Server Logs.<br>
      Please note that the value in the left hand "Earliest" drop-down must be earlier than the right "To" list of values when selected. 

    </li> 
    <li>&quot;Show Access Log Lines&quot; button: <br> 
    Toggles on/off lines from any access_logs which occurred in the same time window for which the utility was run. These will be shown in the chronological order in which they occurred, relative to other logs and entires. 
    </li> 
    <li>&quot;Show OHS Error Log Lines &quot; button: <br> 
    Toggles on/off lines from the error log which occurred in the same time window for which the utility was run. These will be shown in the chronological order in which they occurred, relative to other logs and entires. 
    </li> 
    <li>&quot;Reset All Filters &quot; button: <br> 
    Resets the view to the default view when the page was loaded. 
    </li> 
  
  </ul> 
  
  
  </td></tr> 
  <!-- END FILTER HELP ROW --> \n);
  return(); 
  }#END: _printFilterRowHelp  
  
}#END: wlslog

sub adrLogsToManifest
{
  #my $adrlogs = $_[0];
  my @adrlogs;

  my $searchDirX = $ENV{EBS_DOMAIN_HOME};

  find (sub
  {
    #return unless $_ =~ /^(?:(?!access).)*(log|out)\d*$/ && -f $_;
    return unless $File::Find::dir =~ /^.+\/adr\/diag\/ofm\/EBS_domain_[^\/]+\/\w+\/incident\/incdir_\d+/ && -f $_;

    my $sb = stat($File::Find::name);
    my $mtime = scalar $sb->mtime;

    # picks adr incident files in last 10 days
    if ($mtime >= $main::min - (10*86400) ) {
    #print "FOUND: $File::Find::name, $fAgeSec\n"; <STDIN>;

      push @adrlogs, $File::Find::name;
    }
  }, $searchDirX);
    
  find (sub
  {
    return unless $File::Find::dir =~ /^.+\/EBS_domain_[^\/]+\/sysman\/log/ && -f $_;

    my $sb = stat($File::Find::name);
    my $mtime = scalar $sb->mtime;

    if ($mtime >= $main::min - (10*86400) ) {

      push @adrlogs, $File::Find::name;
    }
  }, $searchDirX);
    
  printToManifest('',\@adrlogs);
}

# +---------------------------------------------------------------------------+
# | sub: checkSigs 
# +---------------------------------------------------------------------------+
# | Desc: check for error signatures 
# +---------------------------------------------------------------------------+
# | Args: $msl hashref for managed server logs 
# |       $ohsl hashref for ohs logs 
# +---------------------------------------------------------------------------+
# | Returns: nebytiye
# +---------------------------------------------------------------------------+
sub checkSigs
{
  my ($msl, $ohsl) = @_;
  my %allLogs;
  my $confirmedSigMatch = 0; 
  #combine into single hash: 
  my $z = 0;
  
  foreach my $i (keys %$msl) 
  {
    $z++; 
    $allLogs{$z}->{LOG} = $$msl{$i}->{LOG}; 
  }
  foreach my $i (keys %$ohsl) 
  {
    $z++; 
    $allLogs{$z}->{LOG} = $$ohsl{$i}; 
  }

  # use Data::Dumper; 
  # print Dumper(%allLogs); exit; 
  require CorePSD::Signature; 
  # my ($xml) = buildHashfromXML();
  my ($sigXML) = sig CorePSD::Signature('template/ebsWLSSigs.xml');

  #get global values
  gl_runCommands();
  #print "\tAFTEr runCOmmands, globalValues:\n"; #debug
  #print Dumper(%main::globalValues); <STDIN>; #debug

  #track total matches: 
  #clear the .tmp file, open it 
  open(my $CS, '>', '.tmp/checkSigs.tmp') || die cluck "  ERROR: checkSigs() Unable to open: \".tmp/checkSigs.tmp\": $! \n"; 
  
  #loop thru the logs mentioned in the XML sigs file 
  logger("checkSigs(): Matching Signatures"); 
  print "  INFO: Matching Error Signatures.. \n";
  foreach my $i (keys %$sigXML)
  {
    print "  INFO: checkSigs(): Working on Signature - conditions: \"$i\" \n";
    my $conditionsMet = cond_assessAll( @{ $sigXML->{$i}->{CONDITIONS} } );
    #print "result from assessAll: $conditionsMet\n"; <STDIN>; #debug

    if ( $conditionsMet )
    {
    print "  INFO: checkSigs(): Working on Signature - logs: \"$i\" \n";
    logger("checkSigs(): Working on Signature: \"$i\""); 
    #reset match for each sig loop. If we fail to match the first <error> in a given sig, we can 
    # stop the loop .. (ie, if match == 0, kill the loop) 
    my $match = 0;
    # print "  INFO: checking signature.. $i  [match is $match] \n";
    #if we get past the first log and didn't find any matches, we can move onto the next sig
    # $i is an ID, starting at 1 for each signature 
    #loop the embedded array in the %xml hash;
    my $lastLog = 0; 
    for (my $j = 0; $j != (scalar @{$sigXML->{$i}->{LOGS}}); $j++) 
    {
      #dont check error2 if error1 didn't match.. 
      next if ($j > 0 && $match == 0);
      
      #loop thru the Managed Server Logs:
      foreach my $id (sort {$a <=> $b} keys %allLogs)
      {
        my $file = basename($allLogs{$id}->{LOG});
        my $log = ${$sigXML->{$i}->{LOGS}}[$j];
        
        #if the base filename matches the XML sig log name..
        my $slice; 
        if ( $file =~ /$log/ ) 
        {
          #my $err = quotemeta(${$sigXML->{$i}->{ERRORS}}[$j]);
          my $err = ${$sigXML->{$i}->{ERRORS}}[$j];
          #print "LOG                log file MATCHED: $file\nerror: $err\n"; #debug

          $err = gl_replaceGlobals($err);
          #print"AFTER gl_replace,\t\terror: >$err<\n"; <STDIN>; #debug
          ${$sigXML->{$i}->{ERRORS}}[$j] = $err;

          #get the log slice which matches the time window
          #we can skip getting the a new slice if the log is the same as the last pass 
          if ( $lastLog == 0 ) 
          {
            ($slice) = getTimeSlice($allLogs{$id}->{LOG}, ${$sigXML->{$i}->{TSFORMAT}}[$j]);
            $lastLog = ${$sigXML->{$i}->{LOGS}}[$j]; 
          }
          elsif ( $lastLog ne ${$sigXML->{$i}->{LOGS}}[$j] ) 
          {
            ($slice) = getTimeSlice($allLogs{$id}->{LOG}, ${$sigXML->{$i}->{TSFORMAT}}[$j]);
          }
          #print "regex to try: $err\n"; #debug
          if ( my (@arr) = grep( /$err/, @$slice ) )
          {
            $match++; 
            $sigXML->{$i}->{MATCH}++;
            #get the line no from the matched errors in the slice 
            # the lineNo has been prepended to the line 774::error line 
            my ($lnNo) = $arr[0] =~ /^(\d+?)::/; 
            #array to hold Log, Line #, Error Matched
            push (@{$sigXML->{$i}->{LOGMATCH}}, qq(
     <li>Log: $allLogs{$id}->{LOG}</li>
     <li>LineNo: $lnNo </li>
     <li>Error Matched:<font color="red">${$sigXML->{$i}->{ERRORS}}[$j]</font></li>)); 

            #if we matched all errors in a signature, print to a .tmp file 
            if ( $sigXML->{$i}->{MATCH} == (scalar @{$sigXML->{$i}->{ERRORS}}) ) 
            {
              #confirmedSigMatch is used for the Exec Summary Section 
              $confirmedSigMatch++; 
              print "   INFO: Error Signature Match! [ $i ]\n\n";
              logger("checkSigs(): Error Signature Match! [ $i ]"); 
              print $CS qq(  <div>\n   <h3>Error Signature Match [ $i ] </h3> 
     <ul> 
       <li>$sigXML->{$i}->{MESG}</li>
       <li><a target="_blank" href="https://support.oracle.com/epmos/faces/DocumentDisplay?parent=ANALYZER&sourceId=2230225.1&id=$sigXML->{$i}->{DOCID}">Doc ID $sigXML->{$i}->{DOCID}</a></li>
);
              foreach my $ln (@{$sigXML->{$i}->{LOGMATCH}}) 
              {
                print $CS qq(     $ln<br>); 
              }
              print $CS qq(\n     </ul>\n  </div><hr>\n\n); 
            }
          }
        }
        #else
         #{ print "  INFO: log file NoT Matched: $file\n"; }
      }
      # print "\n*****\nxml_END: $log \n*****\n"; 
    }
    }
  }
  #close the filehandle 
  close $CS;
  
  logger("checkSigs(): END");
  
}#END: checkSigs 

sub cond_assessAll
{
  my @conditions = @_;
  my $len = scalar(@conditions);
  #print "array length: $len\n"; #debug
  #print Dumper(@conditions); <STDIN>; #debug
  
  my $ret=1;

  foreach my $cond (@conditions)
  {
    #print "Assess condition: >$cond<\n"; <STDIN>; #debug
    $ret = cond_assess($cond);

    if (! $ret ) { last };
  }

  #print "assessAll condition value: $ret\n"; <STDIN>; #debug
  return $ret;
}

sub cond_assess
{
  my $cond = $_[0];
  my $ret=0;

  #print "cond_assess(): condition: $cond\n"; #debug
  if ( $cond =~ /^FVERSION/ ) 
  {
    my @spl = split ('\s+', $cond);

    #print "split variable spl:\n"; #debug
    #print Dumper(@spl);  #debug

    my $fileVer=getEBSFileVersion($spl[1]);
    my $fileVerFull = getFversionFull($fileVer);
    my $fileVerTarget = getFversionFull($spl[3]);

    #print "fileVer: $fileVer\n"; #debug
    #print "op 1: $fileVerFull\n"; #debug
    #print "op 2: $fileVerTarget\n"; <STDIN>; #debug

    my $op = $spl[2];
    if ( $op eq ">" )
    {
      if ( $fileVerFull gt $fileVerTarget ) {
        $ret = 1;
      }
     }
    elsif ($op eq ">=" ) 
    {
      if ( $fileVerFull ge $fileVerTarget ) {
        $ret = 1;
      }
    }
    elsif ($op eq "<" ) 
    {
      if ( $fileVerFull lt $fileVerTarget ) {
        $ret = 1;
      }
    }
    elsif ($op eq "<=" ) 
    {
      if ( $fileVerFull le $fileVerTarget ) {
        $ret = 1;
      }
    }
  }

  #print "ASSESS condition value: $ret\n"; <STDIN>; #debug
  return($ret);
}

sub getFversionFull
{
  my $txt  = $_[0];
  my $ret='X';
  my @spl = split('\.', $txt);
  my $i=0;
  
  #print "getFversionFull parameter: $txt\n"; #debug
  #print "getFversionFull spit var: \n"; #debug
  #print Dumper(@spl); <STDIN>; #debug

  foreach my $k (@spl)
  {
    my $seg = sprintf("%.12d", $k);

    if ( $ret eq "X")
    {    
      $ret = $seg; 
    }
    else
    {
      $ret = $ret . "." . $seg; 
    }
    $i++;
  }
   
  for(my $j=$i ; $j < 6; $j++ ) {
    $ret = $ret . ".000000000000";
  }
  
  return($ret);
}

sub getEBSFileVersion
{
  my $filename = $_[0];
  my $cmd = "adident Header " . $filename . " |tail -1 | awk '{print \$3}' |tr -d '\\n'";
  my $ret = getOSCmdOp($cmd);

  return $ret;
}

sub gl_replaceGlobals
{
  my ($txt) = @_;
  my $ret=$txt;
  my $ln1 =  $txt;
  my $aux=$txt;

  #print "REPLACE\t\tin gl_replaceGlobals(), param: >$txt<\n"; #debug
  while ( $ln1 =~ /##:##(.+)##/g ) {
#print "\tin gl_replaceGlobals(), in the WHILE loop\n"; #debug
    my $global = $&;
    $global =~ s/##:##//;
    $global =~ s/##//;

  #print "\t\tREPLACEGLObALS(): global: $global\n"; #debug
  #print "\t\twith value: $main::globalValues{$global}\n"; #debug
    if ( exists $main::globalValues{$global} ) {
      #print "replacing $global with $main::globalValues{$global}\n"; #debug
      $ret =~ s/##:##$global##/$main::globalValues{$global}/g;
    }
  }

  #print "\t\tREPLACEGLObALS(): return: $ret\n"; <STDIN>; #debug
  return($ret);
}

sub gl_runCommands
{
  my $fshell= cwd() . "/.tmp/global.sh";

  #print "\tin gl_runCommands()\n"; #debug
  foreach my $k (keys %main::globalCmds)
  {
    #print "\tin gl_runCommands(), in the FOREACH loop\n"; #debug

    open (my $fh, '>', $fshell ) || die cluck "  ERROR: test(): Cannot open $fshell $! \n";
    print $fh $main::globalCmds{$k};
    close $fh;

    my $osg = `bash $fshell`;
    #print "running cmd for $k, value: $osg\n"; <STDIN>; #debug

    $main::globalValues{$k} = $osg;
  }
}

sub getOSCmdOp
{
  my $oscmd = $_[0];
 
  my $fshell= cwd() . "/.tmp/cmd.sh";
  open (my $fh, '>', $fshell ) || die cluck "  ERROR: getOSCmdOp(): Cannot open $fshell $! \n";
  print $fh $oscmd;
  close $fh;

  my $ret = `bash $fshell`;

  return $ret;
}


# +---------#------------------------------------------------------------------+
# | sub: writeHTMLFile
# +---------------------------------------------------------------------------+
# | Desc: writes the tabbed content of the HTML report 
# +---------------------------------------------------------------------------+
# | Args: lexical fh 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub writeHTMLFile 
{
  #import all WriteHTML subs 
  require CorePSD::WriteHTML;

  my ($file) = @_; 
  my $pageId; 
  logger("writeHTMLFile(): START"); 
  open (my $fh, '>>', $file ) || die cluck "  ERROR: writeHTMLFile(): Cannot open $file $! \n"; 

  #############################
  ################################
  # 10:05 AM 3/26/2017 
  # each page calls it's own sub to do the work of generating the 
  # data for that page. In order to generate the Execution Summ. 
  # details, we need to pass in the buttons hash and return it 
  # with the error / warnings count from each of these subs. 
  ###################################################################
  #####################################################################
  
  my %buttons; 
  
  ########
  # Page 1: WLS Status & INfo 
  ####################################
  
  if (! $main::searchDir) #dont run if in "support" mode 
  {
  
    logger("writeHTMLFile(): Printing Page 1: WLS Status"); 
    $buttons{1}->{NAME} = 'WLS Status & Info';
    #start a new page:
    $pageId = 1; 
    printNewPage($fh, 1); 
    printDiv($fh, 'divSection'); 
    my $helpID = genRandString(); 
    my $helpText = getHelp($pageId);
    printDivSectionTitle($fh,'WLS Status &amp; Info', $pageId, $helpID);
    printHelpDiv($fh, $helpText, $helpID); 
    #printDiv($fh, 'divItem');
    ($buttons{1}->{WCOUNT}, $buttons{1}->{ECOUNT}) = printWLSStatusFile($fh);
    #print $fh qq" <p>DEBUG - NO CONTENT </p> \n"; 
    # printDiv($fh,'end'); 
    printDiv($fh,'end'); 
    printDiv($fh,'end');
  }

  ########################  END PAGE 1     ###################################
  ############################################################################
    
    
  ########
  # Page 2: Thread Dump 
  ####################################
  if (! $main::searchDir) #dont run if in "support" mode 
  {
    logger("writeHTMLFile(): Printing Page 2: Thread Dump"); 
    #start a new page:
    $buttons{2}->{NAME} = 'Thread Dump';
    $buttons{2}->{WCOUNT} = '[N/A]';
    $buttons{2}->{ECOUNT} = '[N/A]';
    $pageId = 2; 
    printNewPage($fh, $pageId); 
    printDiv($fh, 'divSection'); 
    my $helpID = genRandString(); 
    my $helpText = getHelp($pageId);
    printDivSectionTitle($fh,'Thread Dump', $pageId, $helpID);
    printHelpDiv($fh, $helpText, $helpID); 
    printDiv($fh, 'divItem');
      printWLSTThreadDump($fh); 
    printDiv($fh,'end'); 
    printDiv($fh,'end'); 
    printDiv($fh,'end'); 
  }
  
  ########################  END PAGE 2     ###################################
  ############################################################################

  ########
  # Page 3: LOGS 
  ####################################
  logger("writeHTMLFile(): Printing Page 3: Logs");
  #start a new page:
  $buttons{3}->{NAME} = 'Logs'; 
  $pageId = 3; 
  printNewPage($fh, $pageId); 
  printDiv($fh, 'divSection'); 
  my $helpID = genRandString(); 
  my $helpText = getHelp($pageId);
  printDivSectionTitle($fh,'Logs', $pageId, $helpID);
  printHelpDiv($fh, $helpText, $helpID); 
  $buttons{3}->{ECOUNT} = wlslog($fh); 
  $buttons{3}->{WCOUNT} = 0; 
  printDiv($fh,'end'); 
  printDiv($fh,'end'); 
  #printDiv($fh,'end'); 
  
  ########################  END PAGE 3     ###################################
  ############################################################################
    
  ########
  # Page 4: Known Issues 
  ####################################
  logger("writeHTMLFile(): Printing Page 4: Known Issues");
  #start a new page:
  $buttons{4}->{NAME} = 'Known Issues'; 
  $pageId = 4; 
  printNewPage($fh, $pageId); 
    printDiv($fh, 'divSection'); 
      my $helpID = genRandString(); 
      my $helpText = getHelp($pageId);
      printDivSectionTitle($fh,'Known Issues', $pageId, $helpID);
      printHelpDiv($fh, $helpText, $helpID); 
      printDiv($fh, 'divItem');
        ($buttons{4}->{WCOUNT}, $buttons{4}->{ECOUNT}) = printSignatures($fh); 
      printDiv($fh,'end'); 
    printDiv($fh,'end'); 
  printDiv($fh,'end'); 
  
  ########################  END PAGE 4     ###################################
  ############################################################################
    
  ########################  END Pages     #################################### 
  ############################################################################
  
  #close up tabCtrl div
  print $fh '<!---- end of tabCtrl ---->'; 
  printDiv($fh,'end'); 
  
  #we track all the ID's from printDivItem, then print TOC 
  #we'll need an array or hash to pass in to printTOC 
  # 3:30 PM 12/22/2016 hash is not created .. 
  # how to create it? 
  printSectionTOC($fh, \%hash); 
  
  #end for printTabCtrl 
  printDiv($fh,'end'); 

  ########
  #
  ####################################
  
  #printButtons / exec summary info
  printButtons(\%buttons, $fh);
  printEOFHelp($fh, 14297656, "WebLogic Server Utility");
  #close tags 
  printFileEndTags($fh); 
  #close orig file handle 
  close $fh;
  printToManifest($file, ''); 
  logger("writeHTMLFile(): END"); 
  
}#END: writeHTMLFile

# +---------------------------------------------------------------------------+
# | sub: printSignatures
# +---------------------------------------------------------------------------+
# | Desc: prints the error sig section from the .tmp/checkSigs.tmp file 
# +---------------------------------------------------------------------------+
# | Args: filehandle of the main HTML report  
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub printSignatures
{
  my ($fh) = @_; 
  my $size = (stat ".tmp/checkSigs.tmp")[7];
  if (-f '.tmp/checkSigs.tmp' && $size > 0) 
  {
    open(my $cs, '<', '.tmp/checkSigs.tmp' ) || die cluck "  ERROR: printSignatures() Unable to open: \".tmp/checkSigs.tmp\": $! \n"; 
    
    while (my $ln = <$cs>) 
    {
      print $fh $ln; 
    }
    close $cs; 
  }
  elsif (! -f '.tmp/checkSigs.tmp') 
  {
    print $fh qq(<div> No HTML Output was generated. [WLSU may have failed]. Please use the "Feedback" button on Doc ID <a href="https://support.oracle.com/rs?type=doc\&id=2230225.1" target="_blank">2230225.1</a> to report this issue. </div>); 
  }
  else 
  {
    print $fh qq(<div> No matching error signatures found. </div>); 
  }

}#END:  printSignatures
  
# +---------------------------------------------------------------------------+
# | sub: printToManifest
# +---------------------------------------------------------------------------+
# | Desc: prints a file name to the zipManifest 
# +---------------------------------------------------------------------------+
# | Args: file 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub printToManifest
{
  my ($f, $arr) = @_;
  open(my $fh, '>>', '.tmp/zipManifest.lst'); 
  if ( scalar(@$arr) > 0 )
  {
    foreach (@$arr) 
    {
      print $fh "$_ \n"; 
    }
  }
  else 
  {
    print $fh "$f \n";
  }
  close $fh; 
  return(); 
}#END: printToManifest

# +---------------------------------------------------------------------------+
# | sub: runWLST
# +---------------------------------------------------------------------------+
# | Desc: 
# | creates Thread_Dump_AdminServer.txt & ebsWLS.log output files in python dir 
# | 
# | 
# | 
# +---------------------------------------------------------------------------+
# | Args: $py = python script for WLST to run 
# +---------------------------------------------------------------------------+
# | Returns: nebytiye
# +---------------------------------------------------------------------------+
sub runWLST
{
  use Cwd; 
  my ($py) = @_;
  
  logger("runWLST(): START runWLST");  
  
  #set WLST env with FMW_HOME/oracle_common/common/bin/setWlstEnv.sh
  my $WLST = $ENV{FMW_HOME} . '/oracle_common/common/bin/wlst.sh'; 
  my $EBS_DOMAIN_HOME = $ENV{"EBS_DOMAIN_HOME"}; 
  
  open (my $fh, '>', '.tmp/runWLST.sh' ) || die cluck "Cannot open \'.tmp/runWLST.sh\' $! \n";
  
   # $EBS_DOMAIN_HOME/bin/setDomainEnv.sh and then run java weblogic.WLST test.py weblogic welcome1 t3://celprovm020.us.oracle.com:7051 EBS_domain_VIS AdminServer"
  
  print $fh "#!/bin/bash\n"; 
  print $fh ". \$EBS_DOMAIN_HOME/bin/setDomainEnv.sh\n";
  
  my $url = 't3://' . getContextValue('s_wls_admin_host') . '.' . getContextValue('s_wls_admin_domain') . ':' . getContextValue('s_wls_adminport'); 
  my $testConn = qq(java weblogic.Admin -url $url -username [user] -password [pass] ping 3 100);
  
  my ($connStrg) = getUserCreds($testConn);
  #_getUserCreds will either die or return user/spass
  
  my $pyMainLog = cwd() .'/' . $main::Log; 
  
  my $cmd = 'java weblogic.WLST ' . cwd() . "/python/$py " . $connStrg . ' ' . $url . ' ' . $ENV{EBS_DOMAIN_HOME} . ' AdminServer' . ' ' . $pyMainLog; 
  print $fh "\n$cmd";
  $cmd =~ s/\sweblogic\s.+?\s/ ****** ******* /; 
  # 
  # "weblogic user name:(wl user):
  # password for ^ user: 
  # celprovm020.us.oracle.com:7051 = from Context file, maybe 2 parts (admin server URL + weblogic domain + weblogic adminserver port) 
  # EBS_domain_VIS  = web logic domain 
  # AdminServer = hardcoded 
  #java weblogic.WLST", cwd() . "/python/test.py weblogic welcome1 t3://celprovm020.us.oracle.com:7051 EBS_domain_VIS AdminServer\n";  
  
  close $fh; 
  chmod 0755, ".tmp/runWLST.sh";
  logger("runWLST(): Running WLST with $py\nCMD: $cmd");
  print "  INFO: Running WLST with $py in the background.. please wait.. \n"; 
  # my $status = system(".tmp/runWLST.sh > /dev/null;");
  my $status = system(".tmp/runWLST.sh;");
  print "  INFO: Done running WLST \n"; 
  # unlink (".tmp/runWLST.sh");
  
  if ($status > 0)
  {
    logger("runWLST(): java command exited with status: $status"); 
    print qq(
  
  ERROR: runWLST() java command exited with status: $status
         [Some sections of the HTML output may not be available] 
  
  Press [Enter] to Continue:); 
  <STDIN>; 
  }
  
  print "\n\n  INFO: runWLST() java command exited with status: $status \n"; 
  
  #move logs to local wlst diag directory 
  my $logsDir = cwd() . '/python/logs/';

  find(sub{return unless /Thread\_Dump.+?\.txt$|WLSU.+?\.log$/; move($File::Find::name, $logsDir);},$ENV{EBS_DOMAIN_HOME});
  
  logger("runWLST(): END runWLST");
  return($status); 
  
}#END: runWLST 

# +---------------------------------------------------------------------------+
# | sub: printWLSTThreadDump 
# +---------------------------------------------------------------------------+
# | Desc: check for logs under python/logs/ 
# |       thread dumps, status file WLS-status.log 
# +---------------------------------------------------------------------------+
# | Args: HTML output filehandle (lexical FH) 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub printWLSTThreadDump
{
  my ($HOF) = @_;
  my @logs; 
  my $logsDir = cwd() . '/python/logs/';
  
  find(sub{return unless -f; push @logs, $logsDir . $_;}, $logsDir);
  
  logger("printWLSTThreadDump(): START"); 
  
  if (scalar(@logs) == 0) 
  {
    print $HOF qq(<p>No logs found. (WLST failure?)</p>); 
    logger("printWLSTThreadDump(): No logs found. END"); 
    return(); 
  }
    
  my $ID;
  #set to 10 because we are using the same jscript function which the
  #logs tab uses 
  my $i = 10;
  my %logsH; 
  #loop thru logs to print buttons
  #create a table columns wide 
  
  #thread dump count for how many buttons we'll need 
  my $tdc = scalar @logs;
  my $cols = 4; 
  $cols = 6 if ($tdc/6 >= 1); 

  print $HOF qq( <table class="table1">\n  <tbody>\n); 
  my $colCnt = $cols;
  foreach my $l (@logs)
  {
    $colCnt = $cols if $colCnt == 0; 
    print $HOF qq(  <tr>) if ($colCnt == $cols);  #new row 
    my $lb = basename($l); 
    $ID = $+ if $lb =~ /(.+?)\.\w{3}$/; 
    $i++;
    print $HOF qq(\n   <td><input type="button" onclick="displayWLSLogTable(this,'logTable_$i');" value="$ID"></td>\n);

    #store so we can recall
    $logsH{$i}->{LOG} = $l;
    $colCnt--; 
    print $HOF qq(  </tr>\n) if ($colCnt == 0);
  }
  if ($colCnt > 0)
  {
    print $HOF qq(\n   <td><!--DEBUG--></td>\n) for 1 .. $colCnt;
    print $HOF qq(  </tr>); 
  }
  print $HOF qq( \n  </tbody>\n </table>\n\n); 
  ### ^ Done with buttons for thread dumps^ 
  
  foreach my $k (keys %logsH)
  {
    #printing the first one like this so it's not hidden: 
    if ($k == 11) #ensure the 1st pass prints block style 
    {
      print $HOF qq(<table class="table1" id="logTable_$k" style="display:block">\n<tbody>\n);
    }
    else
    {
      printHiddenTable($HOF, "logTable_$k", 'start'); 
    }
    
    #table headings: 
    print $HOF qq(<tr><th>Line#</th><th>Line</th></tr>);
    open (my $fh1, '<', $logsH{$k}->{LOG}) || warn "  ERROR: runWLST() Cannot open \"$logsH{$i}->{LOG}\": $! \n"; 
    while (my $ln = <$fh1>)
    {
      print $HOF qq(<tr><td>[Line#$.]</td><td>$ln</td></tr>);
    }
    close $fh1; 
    printTable($HOF, 'end'); 
  }

  #clean up logs
  unlink($_) foreach @logs; 
  logger("printWLSTThreadDump(): END"); 

}#END: printWLSTThreadDump

# +---------------------------------------------------------------------------+
# | sub: getUserCreds
# +---------------------------------------------------------------------------+
# | Desc: get and validate WLS credentials 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: return($user . ' ' . $pass); 
# +---------------------------------------------------------------------------+
sub getUserCreds
{
  my ($testConn) = @_; 
  my ($cnt, $cnt2) = (0,0);
  my ($user, $pass); 
  my $status = 999; 
  
  my $testConnOG = $testConn; 
  
  until ($status == 0 || $cnt2 > 2)
  {
    $testConn = $testConnOG; 
    $cnt2++; 
    until (length($user) > 2 || $cnt > 2) 
    {
      cls(); 
      print "\n\n  Enter your \'weblogic\' username\n  [Press [Enter] for default \"weblogic\"]: "; 
      chomp($user=<STDIN>);
      $user = 'weblogic' if length($user) == 0; 
      $cnt++; 
    }
    $cnt = 0; 
    until (length($pass) > 0 || $cnt > 2) 
    {
      print "\n  Enter $user\'s password: ";
      system('stty','-echo');
      chomp($pass=<STDIN>);
      system('stty','echo');
      $cnt++;
      die "  ERROR: User failed to enter password after $cnt attempts \n" if $cnt > 2; 
    }
    
    print "\n";
    $testConn =~ s/\[user\]/$user/; 
    $testConn =~ s/\[pass\]/$pass/; 

    open (my $fh, '>', '.tmp/testWLS.sh') || warn "  _getUserCreds(): Cannot open \".tmp/testWLS.sh\": $! \n"; 
    print $fh "#!/bin/bash\n"; 
    print $fh ". \$EBS_DOMAIN_HOME/bin/setDomainEnv.sh\n";
    print $fh $testConn, "\nexit"; 
    close $fh; 
    chmod 0755, ".tmp/testWLS.sh"; 
    $status = system(".tmp/testWLS.sh > /dev/null");
    
    if ($status > 0 && $cnt2 <= 2) 
    {
      print "\n\n  INFO: WLS credentials check, attempt $cnt2 of 3, failed. Try again \n  Press [Enter]:";
      <STDIN>; 
      $cnt = 0; 
      $user = ''; 
      $pass = ''; 
    }
  }

  if ($status == 0) 
  {
    unlink(".tmp/testWLS.sh"); 
    print "  INFO: WLS Credentials Validated Successfully!\n"; 
    return($user . ' ' . $pass); 
  }
  else 
  {
    unlink(".tmp/testWLS.sh"); 
    die "\n\n  ERROR: Failed to validate weblogic user credentials \n\n"; 
  }

}#END: getUserCreds

# +---------------------------------------------------------------------------+
# | sub: testURL 
# +---------------------------------------------------------------------------+
# | Desc: 
# +---------------------------------------------------------------------------+
# | Args: file to print to 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub testURL 
{
  my ($outFile) = @_; 
  use LWP::Simple;
  my $url = getContextValue('s_login_page'); 

  open (my $fh, '>>', $outFile ); 
  
  print $fh "\n+------------------------------------------------------------------------------+\n"; 
  print $fh "                    START OF HTTP CHECK                             "; 
  print $fh "\n+------------------------------------------------------------------------------+\n";
  
  if (head($url)) 
  {
    print $fh "\nHTTP ping of $url was SUCCESSFUL\n";
  } 
  else 
  {
    print $fh "\nHTTP ping of $url FAILED\n";;
  }

  print $fh "\n+------------------------------------------------------------------------------+\n"; 
  print $fh "                    END OF HTTP CHECK                             "; 
  print $fh "\n+------------------------------------------------------------------------------+\n"; 
  
  close $fh; 
  
}#END: testURL 

# +---------------------------------------------------------------------------+
# | sub: getEpochErrorLog 
# +---------------------------------------------------------------------------+
# | Desc: error_log EBS_web_<SID>.log, line format: 
# | [2017-01-26T16:47:59.0773-05:00] 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub getEpochErrorLog
{
  my ($ln) = @_; 
  my ($SS, $MM, $HH, $dd, $mm, $yyyy); 
  my $date; 
  $date = $+ if $ln =~ /\[(\d{4}-\d{2}-.+?)\]/;
  return(1) if length($date) < 1; 
  my ($S,$T) = split('T', $date);
  my $dump; 
  ($T,$dump) = split('\.', $T);
  ($HH, $MM, $SS) = split(':', $T); 
  ($yyyy,$mm,$dd) = split('-', $S); 
    
  #take a month off the month for timelocal uses 0-11 for months 
  $mm = $mm - 1;
  return(timelocal($SS,$MM,$HH,$dd,$mm,$yyyy)); 
}#END: getEpochErrorLog

# +---------------------------------------------------------------------------+
# | sub: getEpochAccessLog 
# +---------------------------------------------------------------------------+
# | Desc: 
# | access_log format: 
#   127.0.0.1 - - [04/Mar/2017:19:00:07 -0500] "HEAD  /index.html HTTP/1.1" 200 -
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub getEpochAccessLog
{
  my ($ln) = @_; 
  my ($SS, $MM, $HH, $dd, $mm, $yyyy); 
  my $date; 
  $date = $+ if $ln =~ /\[(.+?)\]/;
  return(1) if length($date) < 1; 
  # my ($S, $T) = split(/\d{4}:\d{2}/,$date); 
  my $S; my $dump; 
  ($S, $HH, $MM, $SS) = split(/:/,$date); 
  ($SS, $dump) = split('\s', $SS); 
  ($dd, $mm, $yyyy) = split('/', $S);
  $mm = convertMonth($mm);  
  return(timelocal($SS,$MM,$HH,$dd,$mm,$yyyy)); 
}#END: getEpochAccessLog

# +---------------------------------------------------------------------------+
# | sub: getEpochManagedServerLog 
# +---------------------------------------------------------------------------+
# | Desc: get epoch from a time stamped line 
# +---------------------------------------------------------------------------+
# | Args: line containing TS in format: 
# |       MMM DD, YYYYY HH:MM:SS (12 clock) 
# |       EX: Jan 26, 2017 5:34:44 PM EST 
# +---------------------------------------------------------------------------+
# | Returns: secs since epoch 
# +---------------------------------------------------------------------------+
sub getEpochManagedServerLog
{
  use Time::Local;
  my ($ln) = @_; 

  # my %months = ('JAN' => '00', 'FEB' => '01', 'MAR' => '02', 'APR' => '03', 'MAY' => '04', 'JUN' => '05', 'JUL' => '06', 'AUG' => '07', 'SEP' => '08', 'OCT' => '09', 'NOV' => '10', 'DEC' => '11');
  my ($date) = $ln =~ /(\w{3}\s\d{1,2}\,\s\d{4}\s\d{1,2}\:\d{2}\:\d{2}\s\w{2}\s\w{3})/; 
  return 1 if (length($date) < 1); 
  #split it up
  #date is Jan 26, 2017 4:41:32 PM EST
  my ($mmm, $dd, $yyyy, $HHMMSS, $AMPM, $TZ) = split(' ', $date);
  $dd =~ s/,//; 
  my ($HH, $MM, $SS) = split(':', $HHMMSS); 
  if (uc($AMPM) eq 'PM')
  {
    $HH = $HH + 12 if ($HH != 12); 
  }
  if (uc($AMPM) eq 'AM' && $HH == 12) 
  {
    $HH = '00'; 
  }
  $mmm = convertMonth($mmm); 
  
  return(timelocal($SS,$MM,$HH,$dd,$mmm,$yyyy));
}#END: getEpochManagedServerLog

# +---------------------------------------------------------------------------+
# | sub: convertMonth 
# +---------------------------------------------------------------------------+
# | Desc: 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub convertMonth
{
  my ($arg) = @_; 
  my %months; 
  if ($arg =~ /^\d/) 
  {  
    %months = ('00' => 'Jan', '01' => 'Feb', '02' => 'Mar', '03' => 'Apr', '04' => 'May', '05' => 'Jun', '06' => 'Jul', '07' => 'Aug', '08' => 'Sep', '09' => 'Oct', '10' => 'Nov', '11' => 'Dec'); 
    return($months{$arg});
  }
  
  if ($arg =~ /^\w/) 
  {
    %months = ('JAN' => '00', 'FEB' => '01', 'MAR' => '02', 'APR' => '03', 'MAY' => '04', 'JUN' => '05', 'JUL' => '06', 'AUG' => '07', 'SEP' => '08', 'OCT' => '09', 'NOV' => '10', 'DEC' => '11');
    return($months{uc($arg)});
  }

}#END: convertMonth

# +---------------------------------------------------------------------------+
# | sub: getContextValue
# +---------------------------------------------------------------------------+
# | Desc: get a value for a context var 
# +---------------------------------------------------------------------------+
# | Args: context var value to retrieve (ex: s_web_port) 
# +---------------------------------------------------------------------------+
# | Returns: value of context var 
# +---------------------------------------------------------------------------+
sub getContextValue
{
  my ($var) = @_; 
  $var = quotemeta($var); 
  my $contextFile = $ENV{"CONTEXT_FILE"};
  
  if (! -f $contextFile) 
  {
    warn "ERROR: getContextValue(): Unable to find Context File based on \n\$CONTEXT_FILE environment variable\n"; 
    return(1); 
  }
  else 
  {
    open (my $fh, '<', $contextFile ) || warn "getContextValue(): Cannot open $contextFile $! \n"; 
    my @file = <$fh>; 
    close $fh; 
    my ($val) = grep(/$var/i, @file); 
    $val = _getTag($val); 
    return($val); 
  }
  
  sub _getTag 
  {
    my ($ln) = @_; 
    my $val = $+ if $ln =~ /\>(.+?)\</; 
    return($val); 
  }

}#END: getContextValue

# +---------------------------------------------------------------------------+
# | sub: getTag
# +---------------------------------------------------------------------------+
# | Desc: return the value in between an XML or HTML tag <tag>value</tag> 
# +---------------------------------------------------------------------------+
# | Args: the file and lineNo 
# | <the lineNo is req'd because the tag could span multiple lines> 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub getTag 
{
  my ($tag, $file, $lnNo) = @_;
  my $ln; 
  my $val;
  my @tmp; 
  open (my $fh, '<', $file ) || die cluck "  ERROR: getTag() Cannot open \"$file\": $! \n";
  $ln = <$fh> until ($. == ($lnNo - 1));

  until (eof($fh)) 
  {
    $ln = <$fh>; 
    if ($ln =~ /$tag/) 
    {
      until ( $ln =~ /\<\// )
      {
        push(@tmp, $ln); 
        $ln = <$fh>; 
      }
      push(@tmp, $ln); 
      last; 
    }
  } 
  close $fh; 
  #concat the line 
  my $one; 
  if ($#tmp > 1) 
  {
    foreach my $l (@tmp)
    {
      $one = $one . $l;
      chomp($one); 
    }
    
    $val = $+ if $one =~ /\>(.+?)\</; 
    $val =~ s/\s{2,}/ /g; 
    return($val); 
  }
  else #just single line 
  {
    $val = $+ if $tmp[0] =~ /\>(.+?)\</; 
    $val =~ s/\s{2,}/ /g;
    return($val); 
  }

}#END: getTag 

# +---------------------------------------------------------------------------+
# | sub: getHelp
# +---------------------------------------------------------------------------+
# | Desc: 
# +---------------------------------------------------------------------------+
# | Args: page# to retrieve help for 
# +---------------------------------------------------------------------------+
# | Returns: nebytiye
# +---------------------------------------------------------------------------+
sub getHelp
{
  my ($page) = @_; 
  my $text; 
  if ($page == 1)
  {
    $text = qq(
    <h3>WLS Status &amp; Info Help</h3>
    <hr> 
    <p> The content on this page is generated from the WLST Java/Jython Program. 
    <ul>
    <li>The Source Code can be found under python/ directory, "ebsWLS.py"</li> 
    <li>If you have a suggestion on data shown here,you may post a request on the WLS Utility Community Thread</li> 
    <li>..more..</li> 
    </ul> 
    
    <hr>); 
  }
  elsif ($page == 2)
  {
    $text = qq(
    <h3>Thread Dump Help</h3><hr>
    <p>
      This tab shows Thread Dump Information generated from running WLST. WSLT commands used:<br>
      <ul>
      <li>threadDump()</li>
      <li>threadDump(serverName='oacore_server1')</li> 
      </ul>
      
      The files which are shown here are generated dynamically during the running of $0 and are deleted after their content is moved into the HTML output file. 
    </p> <hr>); 
  }
  elsif ($page == 3)
  {
    $text = qq(
    <h3>Logs Help</h3><hr> 
    <ul>
      <li>Logs shown here are also zipped in the &quot;output/&quot; directory</li>
      <li>Logs Summary:
        <p>Shows a summary of errors found in the WLS and OHS logs. </p>
      </li>
      <li>Chronological View:
        <p>WLS logs along with OHS (access_log and the error log) sorted in decending chronological order from earlest time to latest time. This view allows the user to see across all logs at once as events and errors occurred in the chronological order in which they occurred.</p> 
      
      </li>
      <li>Errors|Alerts: 
        <p>
          Errors, Alerts, Warnings and Emergency messages from the WLS logs. 
        </p> 
      </li>
      <li>Exceptions Found:
        <p>
          Any occurances of &quot;exception&quot; across the WLS logs. 
        </p> 
      </li>
      <li>OHS Error Log: 
        <p>
          The OHS error log \(EBS_web_&lt;SID&gt;.log\) from \$IAS_ORACLE_HOME/. 
        </p> 
      
      </li>
      <li>Latest Access Log: 
      <p>The latest access_log from \$IAS_ORACLE_HOME. \(This button is not shown if the command line option &quot;target&quot; was used.\) </p> </li> 
    </ul> 
    <hr>); 
  }  
  elsif ($page == 4)
  {
    $text = qq(
    <h3>Know Issues Help</h3><hr>
    <p>
      This tab shows shows information generated by checking an error signature from ebsWLSSigs.xml against <strong>all</strong> logs found. <br><br> 
      An error signature is created by Oracle Support. It is a single or collection of key error lines which, when grouped together indicate a strong likelihood of a known issue. 
    </p> <hr>); 
  }
  # elsif ($page == 1)
  # {
    # $text = qq(
    # <h3>"Summary Of Invald Objects" Help</h3><hr> 
    # <p>
      # This tab shows a summary of invalid objects, grouped by schema, in the database. 
    # </p>  <hr>); 
  # }

  return ($text); 

}#END: getHelp

# +---------------------------------------------------------------------------+
# | sub: getAccessLogs
# +---------------------------------------------------------------------------+
# | Desc: get all access logs within a given time range. 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub getAccessLogs
{
  my %accessLogs;
  my $accessCnt;
  my @match;
  
  $searchDirX = $ENV{IAS_ORACLE_HOME} . '/instances/'; 
  $searchDirX = $main::searchDir if length($main::searchDir) > 1;
  
  my ($min, $max); 
  $min = $main::min - 3*43200; # increased collect window to 2 days
  $max = $main::max + 43200; 
  
  find (sub
  {
    return unless $_ =~ /^access_lo.+?$/ && -f $_; 
    if ($_ =~ /^access_lo.+?/) 
    {
      $accessCnt++;
      $accessLogs{$accessCnt} = $File::Find::name; 
    };
  }, $searchDirX);

  foreach my $i (sort {$a <=> $b} keys %accessLogs) 
  {
    #my $ep = (stat($accessLogs{$i}))[9];
    my $sb = stat($accessLogs{$i});
    my $ep = scalar $sb->mtime;

    #ep / modified time on access_log is outside of the time 
    #window by the time we get here. So doing it this way: 
    # 10:06 AM 3/28/2017
    # if ($accessLogs{$i} =~ /access_log$/ && $main::target ne 'y' ) 
    # 9:29 AM 1/11/2018 changed behavior to get access_log associated with time slice. 
    
    #commented the following 4 lines 9:54 AM 1/11/2018 
    # I don't see the value in these lines if we're always capturing access_logs 
    # for the given time range 
    
    # if ($accessLogs{$i} =~ /access_lo.+/ )
    # {
    
      # push @match, $accessLogs{$i}; 
    # }
    # if ($ep >= $main::min && $ep <=  $main::max) 
    if ($ep >= $min && $ep <=  $max) 
    {
      push @match, $accessLogs{$i};
    }
  }
  return(\@match); 
}#END: getAccessLogs

# +---------------------------------------------------------------------------+
# | sub: printWLSStatusFile
# +---------------------------------------------------------------------------+
# | Desc: print ./python/WLS-status.log to HTML 
# +---------------------------------------------------------------------------+
# | Args: an open lexical FH 
# +---------------------------------------------------------------------------+
# | Returns: nebytiye
# +---------------------------------------------------------------------------+
sub printWLSStatusFile
{
  my ($HOF) = @_;
  my $statusLog = 'python/logs/WLSUstatusInfo.log'; 
  #error count, warning count for return to print 
  my ($eC, $wC) = (0,0); 
  #HOF is assumed open for writing 
  if (! -f $statusLog)
  {
    print $HOF qq(
  <h3>$0 could not locate the WLST Output File.</h3> 
  <p>Try re-running $0 and check for errors.
  <br> 
  ERROR: Unable to locate $statusLog 
  </p> 
  
    ); 
    return(0,0); 
  }
  
  open (my $fh2, '<', $statusLog ) || warn "  ERROR: getWLSStatusFile() Cannot open \$statusLog\": $! \n"; 
  chomp(my @file = <$fh2>); 
  close $fh2; 
  
  my $od = 0; #openDiv 
  my $cd = 0; #closeDiv 

  foreach my $ln (@file)
  {
    my $c = () = $ln =~ /<div.+?/ig;
    $od = $od + $c; 
    my $c = () = $ln =~ /<\/div>/ig;
    $cd = $cd + $c;
  }

  foreach my $ln (@file)
  {
    $eC++ if $ln =~ /error_ico/;
    $wC++ if $ln =~ /warn_ico/;
    print $HOF qq($ln); 
  }

  #add an extra </div> if we're uneven on DIV's.
  #usually due to a failure in WLST 
  if ($od > $cd)
  {
    my $diff = $od - $cd;

    for (my $i = 0; $i < $diff; $i++) 
    {
      print $HOF qq(</div>); 
    }
  }

  unlink($statusLog); 
  return($wC,$eC); 
}#END: printWLSStatusFile

# +---------------------------------------------------------------------------+
# | sub: timeMachine 
# +---------------------------------------------------------------------------+
# | Desc: displays a menu of the last 30 days to choose a range 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub timeMachine
{
  my ($mode) = @_;
  my $hours = 0; 
  my ($SS,$MM,$HH,$dd,$mm,$yyyy) = split('::',strftime('%S::%M::%H::%d::%m::%Y',localtime()));
  my $currTime = strftime('%S::%M::%H::%d::%m::%Y',localtime());
  
  if ($mode eq 'default') 
  {
    $mm = $mm -1; #timelocal takes 0-11 for months 
    my $currEp = timelocal($SS,$MM,$HH,$dd,$mm,$yyyy); 
    #1/2 day from current (.5 day = 43200 secs) 
    #return(($currEp - 43200), $currEp);
    #2023-mar-08: now, 2 days from current 
    return(($currEp - $main::mtime_max), $currEp);
  }
  elsif ($mode eq 'target') 
  {
    #prompt for a time
    my $us;
    my $hhmm; 
    my $ampm; 
    my $ep; 
    my $cnt; 
    until (_checkIsValid($us, $hhmm, $ampm))
    {
      $cnt++; 
      if ($cnt > 1 && $us == 0)
      {
        print "  INVALID DATE: $us\n"; 
        sleep 3;
      }

      cls(); 
      print qq(
  INFO: Command Line Argument "target" used. This allows the user to specify 
  a target date. The program will gather logs from the target date, 
  +/- 48 hours (4 day window.) 

  Enter a date [format: DD-MMM-YYYY, ex: "15-JAN-2017"]
   (Type "abort" to quit)
   =>);
      chomp ($us = <STDIN>);
      exit if $us =~ /^abort/i;
      
        print qq(
  Enter hours:minutes [12 hour format: HH:MM, ex: "12:44"]
   (Type "abort" to quit)
   =>);
      chomp ($hhmm = <STDIN>);
      exit if $hhmm =~ /^abort/i;
      
        print qq(
  Enter AM or PM [ex: "PM"]
   (Type "abort" to quit)
   =>);
      chomp ($ampm = <STDIN>);
      exit if $ampm =~ /^abort/i;
    }
      $ep = _checkIsValid($us, $hhmm, $ampm); 
      #173K seconds is 200 seconds longer than 2 days. 
      #3:10 PM 4/25/2017 OLD: (+/- 2 days return(($ep - 173000), ($ep + 173000));  
      #NEW as of 3:11 PM 4/25/2017: (+/- 3 hours, 6 hour window) 
      return(($ep - 10800), ($ep + 10800));  
    
      ## private sub 
      sub _checkIsValid 
      {
        my ($us, $hhmm, $ampm) = @_;
        return (0) if ! $us || ! $hhmm; 
        my ($dd, $MMM, $yyyy) = split('-', $us);
        my ($HH, $MM) = split(':',$hhmm); 
        
        if (uc($ampm) eq 'PM')
        {
          $HH = $HH + 12 if ($HH != 12);
        }
        if (uc($ampm) eq 'AM' && $HH == 12)
        {
          $HH = '00';
        }

        my $SS = 0; 
        my $mm; #2 digit month, timelocal takes \d{2}
        
        if ( $dd !~ /\d{1,2}/ || $MMM !~ /\w{3}/ || $yyyy !~ /\d{4}/ ) 
        {
          print "  INFO: Bad date: \"$us \"";
          sleep 3; 
          return (0);
        }
        elsif ( $HH !~ /\d{1,2}/ || $MM !~ /\d{1,2}/ ) 
        {
          print "  INFO: Bad time: \"$hhmm\"";
          sleep 3; 
          return (0);
        }
        #convert month to \d{2}, minus 1 (mnthFromDig does the minus 1 automatically) 
        $mm = convertMonth($MMM);
        if ($mm !~ /\d{2}/) 
        {
          print "  ERROR: Month input is invalid: \"$MMM\"\n"; 
          print "  Press Enter:"; <STDIN>; 
          return(0); 
        }
        #check day 
        my $ep; 
        eval
        { 
          $ep = timelocal($SS,$MM,$HH,$dd,$mm,$yyyy); 
        } or warn "  INFO: Bad date: \"$us\"";
        
        if ($ep > 0)
        {
          return ($ep);
        }
        else 
        {
          sleep 3; 
          return(0);
        }
      }
  }
}#END: timeMachine


# +---------------------------------------------------------------------------+
# | sub: reformatDate
# +---------------------------------------------------------------------------+
# | Desc: reformats date from: [2017-01-26T16:41:24.394-05:00] 
# |                      to: Jan 26, 2017 04:41:24 PM EST 
# +---------------------------------------------------------------------------+
# | Args: ln containing date in format above 
# +---------------------------------------------------------------------------+
# | Returns: reformated date 
# +---------------------------------------------------------------------------+
sub reformatDate
{
  my ($oldDate) = @_; 
  my $ep = getEpochErrorLog($oldDate);
  return(strftime('%b %e, %Y %r %Z', localtime($ep))); 
}#END:  reformatDate 

# +---------------------------------------------------------------------------+
# | sub: checkForTS
# +---------------------------------------------------------------------------+
# | Desc: checks a log to see if it has 1 of 2 timestamps for
# | either a WLS Managed Server log or a WLS Managed Diagnostic Log 
# +---------------------------------------------------------------------------+
# | Args: nebytiye
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub checkForTS
{
  my ($file) = @_; 
  open (my $fh, '<', $file ) || warn "  WARN: checkForTS(): unable to open file: $file: $! \n"; 
    my @fileArr = <$fh>; 
  close $fh;
  my $TS; 
    
  #check the first 40 lines 
  for ( my $i = 0 ; $i < 40; $i++ ) 
  {
    if ( $fileArr[$i] =~ /^####<\w{3}\s{1,2}/ )
    {
      $TS = '####<%b\s%e,\s%Y\s{1,2}%l\:\d{2}\:\d{2}\s%p'; 
    }
    elsif ( $fileArr[$i] =~ /\[\d{4}-\d{2}-\d{2}T\d{2}/ ) 
    {
      $TS = '^\[%Y-%m-%dT%H';
    }
    last if $TS; 
  }
  
  if (! $TS) 
  {
    return(1); #failed to find TS 
  }
  else 
  {
    return(0); #found TS 
  }

}#END: checkForTS



# +---------------------------------------------------------------------------+
# | sub: getTimeSlice
# +---------------------------------------------------------------------------+
# | Desc: get a slice of a file into an array 
# +---------------------------------------------------------------------------+
# | Args: file, $mode 
# | mode can be either 'managed' or 'diagnostic' 
# | managed = WLS Managed Server Log 
# | diagnostic = WLS diagnostic log 
# | The timestamps in each of those 2 logs is different 
# +---------------------------------------------------------------------------+
# | Returns: nada
# +---------------------------------------------------------------------------+
sub getTimeSlice
{
  my ($file, $TSFormat) = @_; 
  my ($logMin, $logMax);
  #first/last line of the time slice 
  my ($startLine, $endLine) = (-99,-99);
  #arrays to hold the results of grepping the file contents for a date 
  my (@startLines, @endLines);
  #take the file into an array, close the fh 
  open (my $fh, '<', $file ) || warn "  WARN: getTimeSlice(): unable to open file: $file: $! \n"; 
    my @fileArr = <$fh>; 
  close $fh;
  
  if (! $TSFormat) #if we passed it in, don't check for it.. 
  {
    #determine TS of the file 
    for ( my $i = 0 ; $i < $#fileArr; $i++ ) 
    {
      if ( $fileArr[$i] =~ /^####<\w{3}\s{1,2}/ )
      {
        $TSFormat = '####<%b\s%e,\s%Y\s{1,2}%l\:\d{2}\:\d{2}\s%p';
      }
      elsif ( $fileArr[$i] =~ /\[\d{4}-\d{2}-\d{2}T\d{2}/ )
      {
        $TSFormat = '^\[%Y-%m-%dT%H';
      }
      elsif ( basename($file) =~ /^access_log/ )
      {
        $TSFormat = '%d/%b/%Y:%H.+?';
      }
      last if $TSFormat;
    }
    if (! $TSFormat) 
    {
      return(1); 
    }
  }
  
  $logMin = strftime($TSFormat, localtime($main::min)); 
  $logMax = strftime($TSFormat, localtime($main::max)); 

  $logMin =~ s/\s//g;
  $logMax =~ s/\s//g;

  # print "logMin: $logMin [$main::min] \n";
  # print "logMax: $logMax [$main::max] \n";
  
  my $time = $main::min; 
  my $dontCheck = 0; 

##### get START LINE ##### 
  while ($#startLines == -1)
  {
    @startLines = grep{ $fileArr[$_] =~ /$logMin/ } 0..$#fileArr;
    # print "here1\n", $#startLines, "\n----\n$logMin\n----\n"; 
    if ($#startLines == -1) 
    {
      $time = ($time + 3600);
      # print "time is now $time [min: $main::min, max: $main::max]\n"; 
      # <STDIN>; 

      #add 1 hour to min time to check if we have entries now: 
      $logMin = strftime($TSFormat, localtime($time)); 
      $logMin =~ s/\s//g; 
      
      if ($time > $main::max) 
      {
        # << we checked the entire time frame if this happens >>
        #dontcheck is so we don't even bother checking for an endline
        # the log doesn't contain any matching timestamps 
        $dontCheck = 1; 
        last; 
      }
    }
  }

  #if the above loop didn't find a start line, we will try the 1st line 
  # of the file to check the epoch time specifically 
  # if it did find a line, we'll set the startLine eq to the first line 
  # found by the grep $startLines[0];
  if ($#startLines == -1) 
  {
    #check the 1st line of the file and see if the 1st timestamp found 
    # is within the min-max times
    my $ep; 
    if ( $TSFormat =~ /^#/ ) #WLS managed logs 
    {
      $ep = getEpochManagedServerLog($fileArr[0]);
      $dontCheck = 1 if $ep == 1; 
    }
    elsif( basename($file) =~ /^access_log/ ) #access logs 
    {
      $ep = getEpochAccessLog($fileArr[0]);
      $dontCheck = 1 if $ep == 1; 
    }
    else ##error log + diagnostic log use this format [2017-01-26T16:47:59.0774-05:00]
    {
      $ep = getEpochErrorLog($fileArr[0]);
      $dontCheck = 1 if $ep == 1; 
    }
    
    # print "  DEBUG: getTimeSlice() ep: $ep for $fileArr[0]\n"; 
    
    if ($ep >= $main::min && $ep <= $main::max)
    {
      $startLine = 0;
      $dontCheck = 0; 
    }
    else
    {
      $dontCheck = 1; 
    }
  }
  else #if we have data in @startLines.. set startLine to the first item found: 
  {
    $startLine = $startLines[0];
  }

#### END GET START LINES ###### 


  # print "DEBUG: startLine: $startLine \ndontcheck: $dontCheck"; <STDIN>; 

  #reset $time
  $time = $main::max; 

#### GET End Line ###### 

  if ($dontCheck == 0) 
  {
    while ($#endLines == -1) 
    {
      @endLines = grep{ $fileArr[$_] =~ /$logMax/ } 0..$#fileArr;
      # print "here2\n", $#endLines, "\n----\n$logMax\n----\n"; 
      if ($#endLines == -1) 
      {
        $time = ($time - 3600); 
        #add 1 hour to min time to check if we have entries now: 
        $logMax = strftime($TSFormat, localtime($time));
        $logMax =~ s/\s//g;
        
        # print "time is now $time [min: $main::min, max: $main::max]\nlogMax: $logMax\n"; 
        # <STDIN>; 
      }
      #if the time has been subtracted from so much that it's now earlier than the start time ..
      # then we can conclude EITHER: 
      # 1) The only hour for which the problem occurs is during the same hour which it started 
      # 2) The log ends 
      if ($time < $main::min)
      {
        $dontCheck = 1;
        last; 
      }
    }

    if ($#endLines == -1) 
    {
      #if the start line is defined, but not the end line, probably
      # the file ends before the end time 
      my $ep; 
      if ($TSFormat =~ /^#/) 
      {
        $ep = getEpochManagedServerLog($fileArr[0]);
        last if $ep == 1; 
      }
      else
      {
        $ep = getEpochErrorLog($fileArr[0]);
        last if $ep == 1; 
      }
      
      if ($ep >= $main::min && $ep <= $main::max)
      {
        $endLine = $#fileArr;
      }
      else #we have a startline, but didn't find an endline and the last line in the file is NOT 
      #within the timeframe, so the startline and endline both occurred during the same hour 
      {
        #grep the array for the starttime again, but take the last elem 
        @endLines = grep{ $fileArr[$_] =~ /$logMin/ } 0..$#fileArr;
        $endLine = $endLines[$#endLines];
      }
    }
    else
    {
      #last line of the array is the line we want 
      $endLine = $endLines[$#endLines];
    }
  }# if ($dontCheck == 0)  

  my @slice; 
  if ($startLine > -1 && $endLine > -1) 
  {
    foreach my $i ($startLine .. $endLine) 
    {
      push @slice, ($i+1) . "::$fileArr[$i]"; 
    }
    # @slice = @fileArr[$startLine .. $endLine];
  }
  # else 
  # {
    # print "  INFO: File:\n   =>$file\n  No matching entries for the time frame provided. \n"; 
  # }
  
  # use Data::Dumper; 
  # print Dumper(@slice); 
  # <STDIN>; 
    # print "\n----------------\n"; 
    # print "START: $startLine END: $endLine \n"; 
    # print "\n----------------\n"; 
  
  # print "\n***********\nfor log: $file \n start|end: $startLine | $endLine \n**********\n";
  return (\@slice);  
}#END: getTimeSlice  

# +-------------------------------------------------------------------------+
# | sub: getDir 
# +-------------------------------------------------------------------------+
# | Desc: gets a dir for use with the "support" 
# |       option 
# +-------------------------------------------------------------------------+
# | Args: nebytiye
# +-------------------------------------------------------------------------+
# | Returns: nada
# +-------------------------------------------------------------------------+
sub getDir
{
  my $dir;

  cls();
  my $cnt = 0; 
  until (1 == 2) 
  {
    print "\n  Please Enter a Directory to search for logs:";
    chomp($dir = <STDIN>);
    if (-d $dir) 
    {
      print "Directory is valid: \n   => \"$dir\"\n ";
      return($dir);
    }
    else 
    {
      print BOLD WHITE ON_RED "Invalid Directory, try again. \n";
      sleep 3;
      $cnt++;
      exit if $cnt > 2;
    }
  } 

}#END: getDir 


# +-------------------------------------+
# | sub: getLogMetaData
# +-------------------------------------+
# | Desc:  
# +-------------------------------------+
# | Args: nebytiye
# +-------------------------------------+
# | Returns: nada
# +-------------------------------------+
sub getLogMetaData
{
  my ($log) = @_; 

  my $ep = (stat($log))[9];
  return(localtime($ep)); 

}#END: getLogMetaData

"The End."; 
__END__ 

+===========================================================================+
 FILENAME: WLSU.pm

 PLATFORM: Unix Generic 

 NOTES: 
 -EBS Web Logic Server Util Core Perl Code 
 
 HISTORY

 200.0 Creation (08-AUG-2016) 
 
 3:39 PM 9/14/2017
 200.4: $searchDir is the same as $main::searchDir changed $searchDir to 
        "$searchDirX" which was preventing the logs from zipping
 200.5: added sub getLogMetaData to get log modify times 
 200.6: updated getAccessLogs to always get access logs (previously would not if using arg "target" 
                 
+===========================================================================+




